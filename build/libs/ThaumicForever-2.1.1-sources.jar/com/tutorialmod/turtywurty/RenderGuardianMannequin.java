package com.tutorialmod.turtywurty;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;

public class RenderGuardianMannequin extends RenderLiving<EntityGuardianMannequin> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("thaumicforever:textures/entity/guardian_mannequin.png");

    public RenderGuardianMannequin(RenderManager renderManager) {
        super(renderManager, new CustomModel(), 0.5F);  // Використовуємо вашу модель
        this.func_177094_a(new LayerBipedArmor(this) {
            @Override
            protected void func_177177_a() {
                this.field_177189_c = new ModelBiped(0.5F);
                this.field_177186_d = new ModelBiped(1.0F);
            }
        });

        // Додаємо кастомний шар для рендеру предметів у руках
        this.func_177094_a(new LayerHeldItemCustom(this));
    }

    @Override
    protected ResourceLocation func_110775_a(EntityGuardianMannequin entity) {
        return TEXTURE;  // Повертаємо текстуру моба
    }

    @Override
    protected void func_77041_b(EntityGuardianMannequin entitylivingbaseIn, float partialTickTime) {
        GlStateManager.func_179152_a(1.0F, 1.0F, 1.0F);  // Можливо, потрібна зміна масштабування
    }

    // Кастомний клас для рендеру предметів у руках
    private static class LayerHeldItemCustom implements LayerRenderer<EntityGuardianMannequin> {
        private final RenderGuardianMannequin render;

        public LayerHeldItemCustom(RenderGuardianMannequin render) {
            this.render = render;
        }

        @Override
        public void func_177141_a(EntityGuardianMannequin entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            ItemStack itemstack = entity.func_184614_ca();

            if (!itemstack.func_190926_b()) {
                GlStateManager.func_179094_E();

                // Позиціюємо предмет у руці
                if (this.render.func_177087_b() instanceof CustomModel) {
                    CustomModel model = (CustomModel) this.render.func_177087_b();
                    model.getMainRenderer().func_78794_c(0.0625F);  // Використовуємо геттер для bb_main
                }
                
                // Змінюємо позицію та масштабування залежно від моделі
                // Відповідально за позицію
                // GlStateManager.translate(0.35F, -0.75F, 0.0F);  // Налаштуйте значення для правильного позиціонування
                
                // // Відповідально за обертання
                // GlStateManager.rotate(90F, 1F, 0F, 0F);   // Поворот на 90 градусів по осі X
                // GlStateManager.rotate(180F, 0F, 0F, 1F); // Поворот на 180 градусів у зворотному напрямку по осі Y

                // GlStateManager.scale(1.0F, 1.0F, 1.0F);  // Налаштуйте масштабування предмета, якщо він занадто великий або маленький

                // Рендер предмету
                renderItem(entity, itemstack, EnumHandSide.LEFT);

                GlStateManager.func_179121_F();
            }
        }

        private void renderItem(EntityLivingBase entity, ItemStack stack, EnumHandSide handSide) {
            GlStateManager.func_179094_E();
            Minecraft.func_71410_x().func_175597_ag().func_187462_a(entity, stack, handSide == EnumHandSide.LEFT ? ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND : ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, handSide == EnumHandSide.LEFT);
            GlStateManager.func_179121_F();
        }

        @Override
        public boolean func_177142_b() {
            return false;
        }
    }
}
