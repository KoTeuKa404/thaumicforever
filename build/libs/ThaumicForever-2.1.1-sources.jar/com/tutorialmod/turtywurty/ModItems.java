package com.tutorialmod.turtywurty;


import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.registries.IForgeRegistry;
@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ModItems {

    public static final Item LEAD_INGOT = new Item().func_77655_b("lead_ingot").setRegistryName("lead_ingot").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item SILVER_INGOT = new Item().func_77655_b("silver_ingot").setRegistryName("silver_ingot").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item TIN_INGOT = new Item().func_77655_b("tin_ingot").setRegistryName("tin_ingot").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item COPPER_INGOT = new Item().func_77655_b("copper_ingot").setRegistryName("copper_ingot").func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item LEAD_NUGGET = new Item().func_77655_b("lead_nugget").setRegistryName("lead_nugget").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item SILVER_NUGGET = new Item().func_77655_b("silver_nugget").setRegistryName("silver_nugget").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item TIN_NUGGET = new Item().func_77655_b("tin_nugget").setRegistryName("tin_nugget").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item COPPER_NUGGET = new Item().func_77655_b("copper_nugget").setRegistryName("copper_nugget").func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item AQUAREIA_GEM = new Item().func_77655_b("aquareia_gem").setRegistryName("aquareia_gem").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item CLUSTER = new ItemCluster().func_77655_b("cluster").setRegistryName("cluster").func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item PRIMAL_CHARM = new ItemPrimalCharm().func_77637_a(ThaumicForever.CREATIVE_TAB); // Тут вже не потрібно викликати setRegistryName
    public static final Item RING_VERDANT = new ItemRingVerdant().func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item RING_RUNIC_CHARGE = new ItemRingRunicCharge().func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item FOCUS_COMPLEX = new ItemFocusComplex().func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item FOCUS_4 = new ItemFocus4().func_77637_a(ThaumicForever.CREATIVE_TAB);

    // public static final Item ItemTimeFreezeProjectile = new ItemTimeFreezeProjectile().setCreativeTab(ThaumicForever.CREATIVE_TAB);
    public static final Item IRONRING = new IronRing().func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item ItemVoidGear = new ItemVoidGear().func_77655_b("void_gear").setRegistryName("void_gear").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item ItemThaumiumGear = new ItemThaumiumGear().func_77655_b("thaumium_gear").setRegistryName("thaumium_gear").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item ItemBrassGear = new ItemBrassGear().func_77655_b("brass_gear").setRegistryName("brass_gear").func_77637_a(ThaumicForever.CREATIVE_TAB);

    public static final Item ItemZombieHeart = new ItemZombieHeart().func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item ZOMBIE_HEART_AMULET = new ItemZombieHeartAmulet().func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item BROKEN_AMULET = new ItemBrokenAmulet().func_77637_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Item AMULET_DEATH = new ItemAmuletDeath();
    public static final Item mechanism_improved = new Item().func_77655_b("mechanism_improved").setRegistryName("mechanism_improved").func_77637_a(ThaumicForever.CREATIVE_TAB);
    public static final Item MAGIC_DUST = new magic_dust().func_77637_a(ThaumicForever.CREATIVE_TAB);



    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        IForgeRegistry<Item> registry = event.getRegistry();
        registry.registerAll(
            LEAD_INGOT,
            SILVER_INGOT,
            TIN_INGOT,
            COPPER_INGOT,
            LEAD_NUGGET,
            SILVER_NUGGET,
            TIN_NUGGET,
            COPPER_NUGGET,
            AQUAREIA_GEM,
            CLUSTER,
            PRIMAL_CHARM,
            RING_VERDANT,
            RING_RUNIC_CHARGE,
            FOCUS_COMPLEX,
            FOCUS_4,
            IRONRING,
            ItemVoidGear,
            ItemThaumiumGear,   
            ItemBrassGear,
            ItemZombieHeart,
            ZOMBIE_HEART_AMULET,
            BROKEN_AMULET,
            AMULET_DEATH,
            mechanism_improved,
            MAGIC_DUST
            // ItemTimeFreezeProjectile

            
            

        );
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ModItems.LEAD_INGOT, 0, new ModelResourceLocation(ModItems.LEAD_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.SILVER_INGOT, 0, new ModelResourceLocation(ModItems.SILVER_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.TIN_INGOT, 0, new ModelResourceLocation(ModItems.TIN_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.COPPER_INGOT, 0, new ModelResourceLocation(ModItems.COPPER_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.LEAD_NUGGET, 0, new ModelResourceLocation(ModItems.LEAD_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.SILVER_NUGGET, 0, new ModelResourceLocation(ModItems.SILVER_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.TIN_NUGGET, 0, new ModelResourceLocation(ModItems.TIN_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.COPPER_NUGGET, 0, new ModelResourceLocation(ModItems.COPPER_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.AQUAREIA_GEM, 0, new ModelResourceLocation(ModItems.AQUAREIA_GEM.getRegistryName(), "inventory"));
        // Нові предмети - кластери
        for (int i = 0; i < ItemCluster.CLUSTER_TYPES.length; i++) {
            ModelLoader.setCustomModelResourceLocation(ModItems.CLUSTER, i, 
                new ModelResourceLocation(ModItems.CLUSTER.getRegistryName() + "_" + ItemCluster.CLUSTER_TYPES[i], "inventory"));
        }        
        ModelLoader.setCustomModelResourceLocation(ModItems.PRIMAL_CHARM, 0, new ModelResourceLocation(ModItems.PRIMAL_CHARM.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.RING_VERDANT, 0, new ModelResourceLocation(ModItems.RING_VERDANT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.RING_RUNIC_CHARGE, 0, new ModelResourceLocation(ModItems.RING_RUNIC_CHARGE.getRegistryName(), "inventory"));
        
        ModelLoader.setCustomModelResourceLocation(ModItems.FOCUS_COMPLEX, 0, new ModelResourceLocation(ModItems.FOCUS_COMPLEX.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.FOCUS_4, 0, new ModelResourceLocation(ModItems.FOCUS_4.getRegistryName(), "inventory"));
        
        // ModelLoader.setCustomModelResourceLocation(ModItems.ItemTimeFreezeProjectile, 0, new ModelResourceLocation(ModItems.ItemTimeFreezeProjectile.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.IRONRING, 0, new ModelResourceLocation(ModItems.IRONRING.getRegistryName(), "inventory"));

        ModelLoader.setCustomModelResourceLocation(ModItems.ItemVoidGear, 0, new ModelResourceLocation(ModItems.ItemVoidGear.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.ItemThaumiumGear, 0, new ModelResourceLocation(ModItems.ItemThaumiumGear.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.ItemBrassGear, 0, new ModelResourceLocation(ModItems.ItemBrassGear.getRegistryName(), "inventory"));
        
        ModelLoader.setCustomModelResourceLocation(ModItems.ItemZombieHeart, 0, new ModelResourceLocation(ModItems.ItemZombieHeart.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.ZOMBIE_HEART_AMULET, 0, new ModelResourceLocation(ModItems.ZOMBIE_HEART_AMULET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.BROKEN_AMULET, 0, new ModelResourceLocation(ModItems.BROKEN_AMULET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.AMULET_DEATH, 0, new ModelResourceLocation(ModItems.AMULET_DEATH.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.mechanism_improved, 0, new ModelResourceLocation(ModItems.mechanism_improved.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.MAGIC_DUST, 0, new ModelResourceLocation(ModItems.MAGIC_DUST.getRegistryName(), "inventory"));
     
    } 

}

