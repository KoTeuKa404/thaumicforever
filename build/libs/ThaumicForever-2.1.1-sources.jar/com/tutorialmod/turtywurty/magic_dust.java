package com.tutorialmod.turtywurty;

import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class magic_dust extends Item {
    public magic_dust() {
        this.func_77655_b("magic_dust");
        this.setRegistryName("magic_dust");
            }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE; // Встановлення рідкості на EPIC
    }
}
    