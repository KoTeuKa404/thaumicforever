package com.tutorialmod.turtywurty;

import java.util.Random;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenHilltopStones implements IWorldGenerator {

    // Луттейбл для звичайного сундука
    public static final ResourceLocation HILLTOP_STONES_LOOT_TABLE = new ResourceLocation("thaumicforever", "chests/hilltop_stones");

    // Метод для реєстрації луттейблів
    public static void registerLootTables() {
        // Реєструємо луттейбл, якщо він ще не зареєстрований
        if (!net.minecraft.world.storage.loot.LootTableList.func_186374_a().contains(HILLTOP_STONES_LOOT_TABLE)) {
            net.minecraft.world.storage.loot.LootTableList.func_186375_a(HILLTOP_STONES_LOOT_TABLE);
        }
    }

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.field_73011_w.getDimension() == 0) { // Генерація тільки в Overworld
            // Шанс генерації структури (1 з 4)
            if (random.nextInt(400) == 0) {  
                int x = chunkX * 16 + random.nextInt(16);
                int z = chunkZ * 16 + random.nextInt(16);
                int y = world.func_189649_b(x, z);

                BlockPos pos = new BlockPos(x, y, z);

                // Перевірка висоти, відкритого неба та правильного ґрунту
                if (y >= 65 && isSkyOpen(world, pos) && isValidGround(world, pos.func_177977_b())) {
                    // Перевірка, чи є достатньо вільного місця для структури
                    if (canPlaceStructureHere(world, pos, 8, 8, 8)) {  // Розмір структури 8x8x8 (можна налаштувати)
                        TemplateManager templateManager = world.func_72860_G().func_186340_h();
                        Template template = templateManager.func_186237_a(world.func_73046_m(), new ResourceLocation("thaumicforever", "hilltop_stones"));

                        if (template != null) {
                            template.func_186253_b(world, pos, new PlacementSettings().func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE));

                            // Генерація лута в звичайних сундуках
                            generateLootInChests(world, pos);

                         } 
                    }  
                }  
            }
        }
    }

    // Генерація лута в звичайних сундуках після генерації структури
    private void generateLootInChests(World world, BlockPos pos) {
        for (int x = -5; x < 5; x++) {  // Діапазон залежить від розміру структури
            for (int y = 0; y < 5; y++) {
                for (int z = -5; z < 5; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    TileEntity tileEntity = world.func_175625_s(checkPos);
                    
                    if (tileEntity instanceof TileEntityLockableLoot) {
                        // Призначаємо лут-таблицю звичайному сундуку
                        ((TileEntityLockableLoot) tileEntity).func_189404_a(HILLTOP_STONES_LOOT_TABLE, world.field_73012_v.nextLong());
                    }
                }
            }
        }
    }

    // Перевірка наявності відкритого неба
    private boolean isSkyOpen(World world, BlockPos pos) {
        return world.func_175678_i(pos);
    }

    // Перевірка наявності правильного ґрунту для генерації структури
    private boolean isValidGround(World world, BlockPos pos) {
        return world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150348_b
            || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150346_d
            || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150349_c
            || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150433_aE
            || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150431_aC;
    }

    // Перевірка, чи є вільне місце для генерації структури
    private boolean canPlaceStructureHere(World world, BlockPos pos, int width, int height, int depth) {
        for (int x = -width / 2; x < width / 2; x++) {
            for (int y = 0; y < height; y++) {
                for (int z = -depth / 2; z < depth / 2; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    if (!world.func_175623_d(checkPos)) {
                        return false;  
                    }
                }
            }
        }
        return true;   
    }
}
