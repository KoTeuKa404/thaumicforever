package com.tutorialmod.turtywurty;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.ThaumcraftApi;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.crafting.IngredientNBTTC;
import thaumcraft.api.items.ItemsTC;

public class InitRecipes {

    public static void initInfusionRecipes() {
        // ItemStack customTool = new ItemStack(Items.GOLDEN_SWORD);  

        // // Додаємо інфузійне зачарування до предмета
        // EnumInfusionEnchantmentTF.addInfusionEnchantment(customTool, EnumInfusionEnchantmentTF.VOIDREPAIR, 1);  

        // // Створюємо рецепт для інфузійного зачарування VOIDREPAIR
        // InfusionEnchantmentRecipeFM IECVOID = new InfusionEnchantmentRecipeFM(
        //     EnumInfusionEnchantmentTF.VOIDREPAIR, 
        //     new AspectList()
        //         .add(Aspect.ELDRITCH, 50)
        //         .add(Aspect.DARKNESS, 50)
        //         .add(Aspect.VOID, 50)
        //         .add(Aspect.MAGIC, 30),  
        //     new IngredientNBTTC(new ItemStack(ItemsTC.salisMundus)),  
        //     new ItemStack(ModItems.MAGIC_DUST) 
        // );

        // // Реєструємо рецепт у Thaumcraft API
        // ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("thaumicforever:void_repair"), IECVOID);
        ItemStack voidu = new ItemStack(Items.field_151010_B);
        EnumInfusionEnchantment.addInfusionEnchantment(voidu, EnumInfusionEnchantment.VOIDREPAIR, 1);
        InfusionEnchantmentRecipeFM IEVOIDREPAIR = new InfusionEnchantmentRecipeFM(EnumInfusionEnchantment.VOIDREPAIR, (new AspectList()).add(Aspect.ELDRITCH, 20).add(Aspect.DARKNESS, 20).add(Aspect.VOID, 50),
        new IngredientNBTTC(new ItemStack(ItemsTC.salisMundus)), new ItemStack(ModItems.MAGIC_DUST));
        ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("thaumicforever:IEVOIDREPAIR"), IEVOIDREPAIR);
        ThaumcraftApi.addFakeCraftingRecipe(new ResourceLocation("thaumicforever:IEVOIDREPAIRYFAKE"), voidu);
    }
}


        // ItemStack greedy = new ItemStack(Items.GOLDEN_SWORD);
        // EnumInfusionEnchantmentFM.addInfusionEnchantment(greedy, EnumInfusionEnchantmentFM.GREEDY, 1);
        // InfusionEnchantmentRecipeFM IEGREEDY = new InfusionEnchantmentRecipeFM(EnumInfusionEnchantmentFM.GREEDY, (new AspectList()).add(Aspect.EARTH, 20).add(Aspect.ORDER, 20).add(Aspect.ENTROPY, 50), 
        // new IngredientNBTTC(new ItemStack(ItemsTC.salisMundus)), new ItemStack(BlocksTC.hungryChest), new ItemStack(Items.EMERALD));
        // ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("forbiddenmagicre:IEGREEDY"), IEGREEDY);
        // ThaumcraftApi.addFakeCraftingRecipe(new ResourceLocation("forbiddenmagicre:IEGREEDYFAKE"), new InfusionEnchantmentRecipeFM(IEGREEDY, greedy));

