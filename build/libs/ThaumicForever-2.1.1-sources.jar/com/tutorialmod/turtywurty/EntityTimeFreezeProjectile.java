package com.tutorialmod.turtywurty;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityTimeFreezeProjectile extends EntityThrowable {

    public EntityTimeFreezeProjectile(World worldIn) {
        super(worldIn);
    }

    public EntityTimeFreezeProjectile(World worldIn, EntityLivingBase throwerIn) {
        super(worldIn, throwerIn);
    }

    @Override
    protected void func_70184_a(RayTraceResult result) {
        if (!field_70170_p.field_72995_K) {
            BlockPos hitPos = result.func_178782_a() != null ? result.func_178782_a() : new BlockPos(result.field_72308_g);
            createTimeFreezeDome(hitPos);

            // Якщо це влучання в сутність, виконаємо ефект заморожування
            if (result.field_72308_g instanceof EntityLivingBase) {
                applyFreezeEffect((EntityLivingBase) result.field_72308_g);
            }

            func_70106_y();  // Знищуємо сутність після впливу
        }
    }

    private void createTimeFreezeDome(BlockPos center) {
        // Логіка для створення купола розміром 3x3x3 з льоду
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos = center.func_177982_a(x, y, z);
                    // Тимчасово замінюємо блоки на лід
                    if (field_70170_p.func_175623_d(pos)) {  // Замінюємо тільки повітря
                        field_70170_p.func_175656_a(pos, Blocks.field_150432_aD.func_176223_P());
                    }
                }
            }
        }
    }

    private void applyFreezeEffect(EntityLivingBase entity) {
        // Ефекти заморожування для сутностей
        entity.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 200, 5, false, true));
        entity.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 200, 1, false, true));
    }
}
