package com.tutorialmod.turtywurty;

import java.util.Random;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import thaumcraft.common.entities.monster.EntityBrainyZombie;
import thaumcraft.common.entities.monster.EntityGiantBrainyZombie;

@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ZombieDropHandler {

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onEntityDrop(LivingDropsEvent event) {
        EntityLivingBase entity = event.getEntityLiving();

        // GiantBrainyZombie - шанс випадання 50%
        if (entity instanceof EntityGiantBrainyZombie) {
            if (RANDOM.nextFloat() <= 0.5) {
                event.getDrops().add(new net.minecraft.entity.item.EntityItem(
                    entity.field_70170_p,
                    entity.field_70165_t,
                    entity.field_70163_u,
                    entity.field_70161_v,
                    new ItemStack(ModItems.ItemZombieHeart)
                ));
            }
        }

        // BrainyZombie - шанс випадання 10%
        else if (entity instanceof EntityBrainyZombie) {
            if (RANDOM.nextFloat() <= 0.1) {
                event.getDrops().add(new net.minecraft.entity.item.EntityItem(
                    entity.field_70170_p,
                    entity.field_70165_t,
                    entity.field_70163_u,
                    entity.field_70161_v,
                    new ItemStack(ModItems.ItemZombieHeart)
                ));
            }
        }
    }
}
