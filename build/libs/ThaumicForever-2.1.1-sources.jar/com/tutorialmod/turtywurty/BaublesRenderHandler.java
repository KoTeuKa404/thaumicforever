package com.tutorialmod.turtywurty;

import baubles.api.BaublesApi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class BaublesRenderHandler {

    @SubscribeEvent
    public void onRenderPlayer(RenderPlayerEvent.Post event) {
        EntityPlayer player = event.getEntityPlayer();
        
        // Отримуємо амулет із слоту Baubles (слот 0 — це амулет)
        ItemStack amuletStack = BaublesApi.getBaublesHandler(player).getStackInSlot(0);

        if (!amuletStack.func_190926_b() && amuletStack.func_77973_b() instanceof ItemZombieHeartAmulet) {
            renderAmuletOnPlayer(amuletStack, player, event);
        }
    }

    // Метод для рендерингу амулета на гравцеві
    private void renderAmuletOnPlayer(ItemStack amuletStack, EntityPlayer player, RenderPlayerEvent.Post event) {
        GlStateManager.func_179094_E();

        // Позиціонуємо амулет на гравцеві (між шиєю та грудною кліткою)
        event.getRenderer().func_177087_b().field_78115_e.func_78794_c(0.0625F);

        // Зміщуємо амулет трохи вперед і вверх відносно гравця
        GlStateManager.func_179109_b(0F, 0.7F, 0.3F);

        // Отримуємо IBakedModel для амулета
        IBakedModel model = Minecraft.func_71410_x().func_175599_af().func_184393_a(amuletStack, player.field_70170_p, player);

        // Рендеримо модель амулета
        Minecraft.func_71410_x().func_175599_af().func_180454_a(amuletStack, model);

        GlStateManager.func_179121_F();
    }
}
