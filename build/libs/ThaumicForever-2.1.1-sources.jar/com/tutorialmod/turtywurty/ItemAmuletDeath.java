package com.tutorialmod.turtywurty;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public class ItemAmuletDeath extends Item implements IBauble {

    public ItemAmuletDeath() {
        func_77655_b("amulet_death");
        setRegistryName("amulet_death");
        func_77625_d(1); // Це амулет, тому лише один у стеку
        func_77637_a(ThaumicForever.CREATIVE_TAB); // Вибираємо правильну вкладку
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET; // Визначаємо, що це амулет
    }

    @Override
    public void onUnequipped(ItemStack itemstack, EntityLivingBase player) {
        // Метод, який викликається, коли амулет знято
        if (player instanceof EntityPlayer && !player.field_70170_p.field_72995_K) {
            EntityPlayer entityPlayer = (EntityPlayer) player;
            // Наносимо гравцеві смертельну шкоду
            entityPlayer.func_70097_a(DamageSource.field_76380_i, Float.MAX_VALUE);
        }
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
        // Тут можна додати логіку для роботи амулета, поки він надітий
    }

    @Override
    public boolean func_77636_d(ItemStack stack) {
        return true; // Амулет буде мати візуальний ефект (як наче він зачарований)
    }
}
