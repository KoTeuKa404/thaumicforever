package com.tutorialmod.turtywurty;

import net.minecraft.util.ResourceLocation;
import thaumcraft.api.casters.FocusEngine;

public class ModFocuses {

    public static void registerFocuses() {
        // Реєстрація фокуса Calm
        FocusEngine.registerElement(FocusEffectCalm.class, new ResourceLocation("thaumicforever", "textures/foci/calm_focus.png"), 0xFF6347);
        FocusEngine.registerElement(FocusEffectCleanse.class, new ResourceLocation("thaumicforever", "textures/foci/cleanse_focus.png"), 0x00FFD9);
        FocusEngine.registerElement(FocusModBoostPower.class, new ResourceLocation("thaumicforever", "textures/foci/boost_power_focus.png"), 10);
        FocusEngine.registerElement(FocusEffectChain.class, new ResourceLocation("thaumicforever", "textures/foci/chain.png"), 0x444444);  
        FocusEngine.registerElement(FocusEffectMindControl.class, new ResourceLocation("thaumicforever", "textures/foci/mindcontrol.png"),0x66071f);

    }
}
