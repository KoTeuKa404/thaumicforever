package com.tutorialmod.turtywurty;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerAbandonedChest extends Container {
    private final IInventory tileEntity;

    public ContainerAbandonedChest(InventoryPlayer playerInventory, IInventory tileEntity) {
        this.tileEntity = tileEntity;

        // Слоти для сундука (без лівого і правого ряду)
        int chestSlotStartX = 46;  // Зсунули на 2 слота вправо (18 пікселів * 2)
        int chestSlotStartY = 32;  // Зсуваємо слоти на 2 пікселі вниз

        for (int i = 0; i < 3; ++i) {
            for (int j = 1; j < 8; ++j) {  // Починаємо з 1 і закінчуємо на 8 (щоб пропустити перший і останній слот)
                this.func_75146_a(new Slot(tileEntity, (j - 1) + i * 7, chestSlotStartX + (j - 1) * 18, chestSlotStartY + i * 18));
            }
        }

        // Слоти інвентаря гравця
        int playerInventoryStartY = 100 + 8;  // Зсуваємо інвентар гравця ще на 10 пікселів вниз

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.func_75146_a(new Slot(playerInventory, j + i * 9 + 9, chestSlotStartX + j * 18 - 18, playerInventoryStartY + i * 18)); // зміщуємо на -18 для центрування
            }
        }

        // Слоти гарячої панелі
        int hotbarY = 160 + 6;  // Зсуваємо гарячу панель теж на 10 пікселів вниз

        for (int i = 0; i < 9; ++i) {
            this.func_75146_a(new Slot(playerInventory, i, chestSlotStartX + i * 18 - 18, hotbarY)); // зміщуємо на -18 для центрування
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return this.tileEntity.func_70300_a(playerIn);
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d()) {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();

            if (index < this.tileEntity.func_70302_i_()) {
                if (!this.func_75135_a(itemstack1, this.tileEntity.func_70302_i_(), this.field_75151_b.size(), true)) {
                    return ItemStack.field_190927_a;
                }
            } else if (!this.func_75135_a(itemstack1, 0, this.tileEntity.func_70302_i_(), false)) {
                return ItemStack.field_190927_a;
            }

            if (itemstack1.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }

            if (itemstack1.func_190916_E() == itemstack.func_190916_E()) {
                return ItemStack.field_190927_a;
            }

            slot.func_190901_a(playerIn, itemstack1);
        }

        return itemstack;
    }
}
