package com.tutorialmod.turtywurty;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class MannequinInteractionHandler {

    @SubscribeEvent
    public void onPlayerInteract(PlayerInteractEvent.EntityInteractSpecific event) {
        // Взаємодія з EntityGuardianMannequin
        if (event.getTarget() instanceof EntityGuardianMannequin) {
            EntityPlayer player = event.getEntityPlayer();
            EntityGuardianMannequin mannequin = (EntityGuardianMannequin) event.getTarget();
            ItemStack heldItem = player.func_184586_b(event.getHand());

            // Якщо предмет — броня
            if (heldItem.func_77973_b() instanceof ItemArmor) {
                ItemArmor armor = (ItemArmor) heldItem.func_77973_b();
                EntityEquipmentSlot armorSlot = armor.field_77881_a;  // Отримуємо тип слота для броні
                ItemStack currentArmor = mannequin.func_184582_a(armorSlot);

                // Міняємо броню манекена на ту, що тримає гравець
                if (currentArmor.func_190926_b()) {
                    mannequin.func_184201_a(armorSlot, heldItem.func_77946_l());
                    player.func_184611_a(event.getHand(), ItemStack.field_190927_a);
                } else {
                    player.func_184611_a(event.getHand(), currentArmor);
                    mannequin.func_184201_a(armorSlot, heldItem.func_77946_l());
                }
            }

            // Якщо предмет — зброя (меч або інструмент)
            else if (heldItem.func_77973_b() instanceof ItemSword || heldItem.func_77973_b() instanceof ItemTool) {
                EntityEquipmentSlot handSlot = EntityEquipmentSlot.MAINHAND;  // Основна рука
                ItemStack currentWeapon = mannequin.func_184582_a(handSlot);

                // Міняємо зброю манекена на ту, що тримає гравець
                if (currentWeapon.func_190926_b()) {
                    mannequin.func_184201_a(handSlot, heldItem.func_77946_l());
                    player.func_184611_a(event.getHand(), ItemStack.field_190927_a);
                } else {
                    player.func_184611_a(event.getHand(), currentWeapon);
                    mannequin.func_184201_a(handSlot, heldItem.func_77946_l());
                }
            }
        }
    }
}
