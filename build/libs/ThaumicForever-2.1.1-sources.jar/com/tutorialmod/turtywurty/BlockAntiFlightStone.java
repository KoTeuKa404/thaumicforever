package com.tutorialmod.turtywurty;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class BlockAntiFlightStone extends Block {

    // Радіус у чанках (3x3 чанки = радіус 48 блоків)
    private static final int RADIUS_BLOCKS = 48;

    public BlockAntiFlightStone() {
        super(Material.field_151576_e);
        func_149663_c("anti_flight_stone");
        setRegistryName("anti_flight_stone");
        func_149711_c(3.0F); // Можна налаштувати як камінь
        func_149647_a(ThaumicForever.CREATIVE_TAB);
        MinecraftForge.EVENT_BUS.register(this);
    }

    // Обробник подій для перевірки кожен тік
    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        World world = event.world;

        // Перебираємо всі гравців у світі
        List<EntityPlayer> players = world.field_73010_i;

        for (EntityPlayer player : players) {
            BlockPos playerPos = player.func_180425_c();

            // Перевіряємо всі блоки цього типу у світі
            for (BlockPos pos : BlockPos.func_177980_a(playerPos.func_177982_a(-RADIUS_BLOCKS, -RADIUS_BLOCKS, -RADIUS_BLOCKS),
                                                     playerPos.func_177982_a(RADIUS_BLOCKS, RADIUS_BLOCKS, RADIUS_BLOCKS))) {
                if (world.func_180495_p(pos).func_177230_c() instanceof BlockAntiFlightStone) {
                    // Якщо гравець у радіусі, вимикаємо політ
                    if (player.field_71075_bZ.field_75101_c) {
                        player.field_71075_bZ.field_75101_c = false;
                        player.field_71075_bZ.field_75100_b = false;
                        player.func_71016_p();
                    }
                }
            }
        }
    }
}
