package com.tutorialmod.turtywurty;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenObsidianTotem implements IWorldGenerator {

    // Шаблони для різних типів тотемів
    private static final ResourceLocation TOTEM_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem");
    private static final ResourceLocation TOTEM_LEED_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem_leed");
    private static final ResourceLocation TOTEM_HIGH_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem_high");

    private static final ResourceLocation TOTEM_WITH_CHEST_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem_ch");
    private static final ResourceLocation TOTEM_LEED_WITH_CHEST_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem_leed_ch");
    private static final ResourceLocation TOTEM_HIGH_WITH_CHEST_TEMPLATE = new ResourceLocation("thaumicforever", "obsidian_totem_high_ch");

    // Луттейбл для сундука
    public static final ResourceLocation BASIC_LOOT_TABLE = new ResourceLocation("thaumicforever", "chests/basic_loot");
    public static final ResourceLocation TOTEM_CHEST_TABLE = new ResourceLocation("thaumicforever", "chests/basic_loot");
    public static final ResourceLocation TOTEM_HIGH_CHEST_TABLE = new ResourceLocation("thaumicforever", "chests/basic_loot");
    public static final ResourceLocation TOTEM_LEED_CHEST_TABLE = new ResourceLocation("thaumicforever", "chests/basic_loot");

    // Метод для реєстрації луттейблів
    public static void registerLootTables() {
        LootTableList.func_186375_a(BASIC_LOOT_TABLE);
 
    }
    
    



    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.field_73011_w.getDimension() == 0 && random.nextInt(360) == 0) { // Генерація з шансом 1/360
            int x = chunkX * 16 + random.nextInt(16);
            int z = chunkZ * 16 + random.nextInt(16);
            int y = world.func_189649_b(x, z); // Знайти висоту на поверхні
            BlockPos pos = new BlockPos(x, y, z);

            // Перевіряємо, чи є під структурою твердий блок і чи вільне місце для генерації
            if (isSolidBlockBelow(world, pos.func_177977_b()) && isAreaClear(world, pos, 5, 10)) {
                // Випадковий вибір між шістьма типами тотемів
                int totemType = random.nextInt(6); // 0 - звичайний, 1 - leed, 2 - high, 3 - із сундуком, 4 - leed_ch, 5 - high_ch

                switch (totemType) {
                    case 0:
                        generateStructure(world, pos, TOTEM_TEMPLATE);
                        break;
                    case 1:
                        generateStructure(world, pos, TOTEM_LEED_TEMPLATE);
                        break;
                    case 2:
                        generateStructure(world, pos, TOTEM_HIGH_TEMPLATE);
                        break;
                    case 3:
                        generateStructureWithChest(world, pos.func_177977_b(), TOTEM_WITH_CHEST_TEMPLATE);
                        break;
                    case 4:
                        generateStructureWithChest(world, pos.func_177977_b(), TOTEM_LEED_WITH_CHEST_TEMPLATE);
                        break;
                    case 5:
                        generateStructureWithChest(world, pos.func_177977_b(), TOTEM_HIGH_WITH_CHEST_TEMPLATE);
                        break;
                }
            }
        }
    }

    // Генерація звичайної структури
    private void generateStructure(World world, BlockPos pos, ResourceLocation templateLocation) {
        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = templateManager.func_186237_a(world.func_73046_m(), templateLocation);

        if (template != null) {
            template.func_186253_b(world, pos, new PlacementSettings().func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE));
        } else {
            System.out.println("Шаблон структури " + templateLocation + " не знайдено!");
        }
    }

    // Генерація структури із сундуком
    private void generateStructureWithChest(World world, BlockPos pos, ResourceLocation templateLocation) {
        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = templateManager.func_186237_a(world.func_73046_m(), templateLocation);

        if (template != null) {
            template.func_186253_b(world, pos, new PlacementSettings().func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE));
            generateLootInChest(world, pos); // Призначення луттейбла для сундука
        } else {
            System.out.println("Шаблон структури " + templateLocation + " не знайдено!");
        }
    }

    // Призначення луттейбла для сундука
    private void generateLootInChest(World world, BlockPos pos) {
        for (int x = -5; x < 5; x++) {
            for (int y = -5; y < 5; y++) {
                for (int z = -5; z < 5; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    if (world.func_180495_p(checkPos).func_177230_c() == Blocks.field_150486_ae) {
                        TileEntity tileEntity = world.func_175625_s(checkPos);
                        if (tileEntity instanceof TileEntityLockableLoot) {
                            ((TileEntityLockableLoot) tileEntity).func_189404_a(BASIC_LOOT_TABLE, world.field_73012_v.nextLong());
                        }
                    }
                }
            }
        }
    }

    // Перевірка, чи під структурою є твердий блок (не вода)
    private boolean isSolidBlockBelow(World world, BlockPos pos) {
        Block blockBelow = world.func_180495_p(pos).func_177230_c();
        return blockBelow != Blocks.field_150355_j && blockBelow != Blocks.field_150358_i && blockBelow.func_149688_o(world.func_180495_p(pos)).func_76220_a();
    }

    // Перевірка, чи немає блоків, які заважають генерації структури
    private boolean isAreaClear(World world, BlockPos pos, int width, int height) {
        for (int x = -width / 2; x < width / 2; x++) {
            for (int y = 0; y < height; y++) {
                for (int z = -width / 2; z < width / 2; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    if (!world.func_175623_d(checkPos)) {
                        return false; // Якщо вже є блоки, не генеруємо структуру
                    }
                }
            }
        }
        return true;
    }
}
