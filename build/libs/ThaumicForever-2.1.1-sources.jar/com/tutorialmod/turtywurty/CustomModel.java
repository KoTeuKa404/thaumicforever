package com.tutorialmod.turtywurty;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;


public class CustomModel extends ModelBase {
    private final ModelRenderer bb_main;
    private final ModelRenderer leftArm;
    private final ModelRenderer rightArm;
    private final ModelRenderer leftLeg;
    private final ModelRenderer rightLeg;

    public CustomModel() {
        field_78090_t = 64;
        field_78089_u = 64;

        bb_main = new ModelRenderer(this);
        bb_main.func_78793_a(0.0F, 24.0F, 0.0F);
        bb_main.field_78804_l.add(new ModelBox(bb_main, 0, 0, -1.0F, -30.0F, -1.0F, 2, 7, 2, 0.0F, false));//Це голова
        bb_main.field_78804_l.add(new ModelBox(bb_main, 0, 26, -6.0F, -24.0F, -1.5F, 12, 3, 3, 0.0F, false));//Це верхня частина тіла
        leftArm = new ModelRenderer(this);
        leftArm.func_78793_a(5.0F, -24.0F, -1.0F);
        leftArm.field_78804_l.add(new ModelBox(leftArm, 32, 16, 0.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F, true));//ліва рука
        bb_main.func_78792_a(leftArm);
        
        rightArm = new ModelRenderer(this);
        rightArm.func_78793_a(-7.0F, -24.0F, -1.0F);
        rightArm.field_78804_l.add(new ModelBox(rightArm, 24, 0, 0.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F, false));//права рука
        bb_main.func_78792_a(rightArm);
        
        leftLeg = new ModelRenderer(this);
        leftLeg.func_78793_a(0.9F, -12.0F, -1.0F);
        leftLeg.field_78804_l.add(new ModelBox(leftLeg, 40, 16, 0.0F, 0.0F, 0.0F, 2, 11, 2, 0.0F, true));//ліва нога
        bb_main.func_78792_a(leftLeg);
        
        rightLeg = new ModelRenderer(this);
        rightLeg.func_78793_a(-3.05F, -12.0F, -1.0F);
        rightLeg.field_78804_l.add(new ModelBox(rightLeg, 8, 0, 0.0F, 0.0F, 0.0F, 2, 11, 2, 0.0F, false));//права нога
        bb_main.func_78792_a(rightLeg);

        bb_main.field_78804_l.add(new ModelBox(bb_main, 48, 16, 1.0F, -21.0F, -1.0F, 2, 7, 2, 0.0F, false));//лівий кусок тіла
        bb_main.field_78804_l.add(new ModelBox(bb_main, 16, 0, -3.0F, -21.0F, -1.0F, 2, 7, 2, 0.0F, false));//правий кусок тіла
        bb_main.field_78804_l.add(new ModelBox(bb_main, 0, 48, -4.0F, -14.0F, -1.0F, 8, 2, 2, 0.0F, false));//нижній кусок тіла
    }

    @Override
    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        func_78087_a(f, f1, f2, f3, f4, f5, entity);
        bb_main.func_78785_a(f5);
    }

    @Override
    public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
        // Анімація рук і ніг
        this.leftArm.field_78795_f = (float) Math.cos(f * 0.6662F) * 1.4F * f1;
        this.rightArm.field_78795_f = (float) Math.cos(f * 0.6662F + (float) Math.PI) * 1.4F * f1;
        this.leftLeg.field_78795_f = (float) Math.cos(f * 0.6662F + (float) Math.PI) * 1.4F * f1;
        this.rightLeg.field_78795_f = (float) Math.cos(f * 0.6662F) * 1.4F * f1;
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    // Додаємо публічний метод для доступу до bb_main
    public ModelRenderer getMainRenderer() {
        return this.bb_main;
    }
}
