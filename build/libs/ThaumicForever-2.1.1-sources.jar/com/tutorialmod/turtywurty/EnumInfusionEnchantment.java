package com.tutorialmod.turtywurty;

import java.util.Set;

import com.google.common.collect.ImmutableSet;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public enum EnumInfusionEnchantment {
    VOIDREPAIR(ImmutableSet.of("weapon", "axe", "pickaxe", "shovel", "armor"), 1, "NEWRUNICS");

    public final Set<String> applicableItems;
    public final int maxLevel;
    public final String researchKey;

    EnumInfusionEnchantment(Set<String> applicableItems, int maxLevel, String researchKey) {
        this.applicableItems = applicableItems;
        this.maxLevel = maxLevel;
        this.researchKey = researchKey;
    }

    // Method to get the NBT tag list for infusion enchantments
    public static NBTTagList getInfusionEnchantmentTagList(ItemStack stack) {
        if (stack == null || stack.func_190926_b() || !stack.func_77942_o()) {
            return null;
        }
        return stack.func_77978_p().func_150295_c("infenchtf", 10);
    }

    // Method to add the infusion enchantment to an item
    public static void addInfusionEnchantment(ItemStack stack, EnumInfusionEnchantment enchantment, int level) {
        if (stack == null || stack.func_190926_b() || level > enchantment.maxLevel) {
            return;
        }

        // Get or create the NBT tag list
        NBTTagList nbttaglist = getInfusionEnchantmentTagList(stack);
        if (nbttaglist == null) {
            nbttaglist = new NBTTagList();
        }

        // Check if the enchantment already exists
        for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
            NBTTagCompound tag = nbttaglist.func_150305_b(i);
            if (tag.func_74765_d("id") == (short) enchantment.ordinal()) {
                return; // The enchantment is already present
            }
        }

        // Add the enchantment ID and level to the NBT tag
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.func_74777_a("id", (short) enchantment.ordinal());
        nbttagcompound.func_74777_a("lvl", (short) level);
        nbttaglist.func_74742_a(nbttagcompound);

        // Apply the tag list to the item
        stack.func_77983_a("infenchtf", nbttaglist);
    }

    // Method to get the level of a specific infusion enchantment from an item
    public static int getInfusionEnchantmentLevel(ItemStack stack, EnumInfusionEnchantment enchantment) {
        NBTTagList nbttaglist = getInfusionEnchantmentTagList(stack);
        if (nbttaglist != null) {
            for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
                NBTTagCompound nbttagcompound = nbttaglist.func_150305_b(i);
                short id = nbttagcompound.func_74765_d("id");
                if (id == enchantment.ordinal()) {
                    return nbttagcompound.func_74765_d("lvl");
                }
            }
        }
        return 0;
    }
}
