package com.tutorialmod.turtywurty;

import net.minecraft.item.Item;

public class ItemZombieHeart extends Item {
        public ItemZombieHeart() {
            func_77655_b("zombie_heart");  // Локалізоване ім'я
            setRegistryName("zombie_heart");     // Реєстраційне ім'я
        }
    }
    