package com.tutorialmod.turtywurty;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class OreBlock extends Block {

    public OreBlock(String name, float hardness, float resistance, int lightLevel) {
        super(Material.field_151576_e);
        func_149663_c(ThaumicForever.MODID + "." + name);
        setRegistryName(ThaumicForever.MODID, name);
        func_149711_c(hardness);
        func_149752_b(resistance);
        func_149715_a(lightLevel / 15.0F);
        setHarvestLevel("pickaxe", 2);
        func_149672_a(SoundType.field_185851_d);
        func_149647_a(ThaumicForever.CREATIVE_TAB);  // Додаємо блок у вкладку "Building Blocks"

    }
}
