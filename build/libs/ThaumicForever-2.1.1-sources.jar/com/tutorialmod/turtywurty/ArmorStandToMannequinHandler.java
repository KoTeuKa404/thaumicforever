package com.tutorialmod.turtywurty;

import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ArmorStandToMannequinHandler {

    @SubscribeEvent
    public void onPlayerInteract(PlayerInteractEvent.EntityInteractSpecific event) {
        if (event.getTarget() instanceof EntityArmorStand) {
            EntityPlayer player = event.getEntityPlayer();
            EntityArmorStand armorStand = (EntityArmorStand) event.getTarget();
            ItemStack heldItem = player.func_184586_b(event.getHand());
            World world = event.getWorld();
            BlockPos pos = armorStand.func_180425_c();

            // Якщо гравець використовує "магічний предмет" (наприклад, ModItems.MAGIC_DUST)
            if (heldItem.func_77973_b() == ModItems.MAGIC_DUST) {
                if (!world.field_72995_K) {
                    // Вивантажуємо всі предмети зі стійки для броні
                    for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
                        ItemStack itemStack = armorStand.func_184582_a(slot);
                        if (!itemStack.func_190926_b()) {
                            armorStand.func_184201_a(slot, ItemStack.field_190927_a);
                            armorStand.func_70099_a(itemStack, 0.5F);
                        }
                    }

                    // Видаляємо ArmorStand
                    armorStand.func_70106_y();

                    // Створюємо EntityGuardianMannequin на місці ArmorStand
                    EntityGuardianMannequin guardianMannequin = new EntityGuardianMannequin(world);
                    guardianMannequin.func_70107_b(pos.func_177958_n() + 0.5, pos.func_177956_o(), pos.func_177952_p() + 0.5);  // Встановлюємо точну позицію
                    world.func_72838_d(guardianMannequin);

                    // Знімаємо один предмет ModItems.MAGIC_DUST у гравця
                    if (!player.func_184812_l_()) {
                        heldItem.func_190918_g(1);
                    }

                    // Програємо ефект взаємодії
                    world.func_175718_b(2001, pos, 0); // Ефект для руйнування стійки
                }
            }
        }
    }
}
