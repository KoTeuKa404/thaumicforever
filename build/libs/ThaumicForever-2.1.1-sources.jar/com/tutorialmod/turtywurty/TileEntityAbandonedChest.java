package com.tutorialmod.turtywurty;

import javax.annotation.Nullable;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;

public class TileEntityAbandonedChest extends TileEntityLockableLoot {

    private NonNullList<ItemStack> chestContents = NonNullList.func_191197_a(27, ItemStack.field_190927_a); // 27-slot chest
    private String lootTableName = null;  // Store the loot table name for multiple loot table handling

    // Method to set the loot table name dynamically
    public void setLootTable(String lootTableName) {
        this.lootTableName = lootTableName;
    }

    @Override
    public int func_70302_i_() {
        return this.chestContents.size();
    }

    @Override
    public boolean func_191420_l() {
        for (ItemStack stack : this.chestContents) {
            if (!stack.func_190926_b()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack func_70301_a(int index) {
        return this.chestContents.get(index);
    }

    @Override
    public ItemStack func_70298_a(int index, int count) {
        return ItemStackHelper.func_188382_a(this.chestContents, index, count);
    }

    @Override
    public ItemStack func_70304_b(int index) {
        return ItemStackHelper.func_188383_a(this.chestContents, index);
    }

    @Override
    public void func_70299_a(int index, ItemStack stack) {
        this.chestContents.set(index, stack);
        if (stack.func_190916_E() > this.func_70297_j_()) {
            stack.func_190920_e(this.func_70297_j_());
        }
        this.func_70296_d();
    }

    // Read the loot table name and chest contents from NBT
    @Override
    public void func_145839_a(NBTTagCompound compound) {
        super.func_145839_a(compound);
        this.chestContents = NonNullList.func_191197_a(this.func_70302_i_(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, this.chestContents);

        if (compound.func_150297_b("LootTableName", 8)) { // 8 означає String тег
            this.lootTableName = compound.func_74779_i("LootTableName");
            System.out.println("Завантажено лут-таблицю: " + this.lootTableName);
        }
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
        super.func_189515_b(compound);
        ItemStackHelper.func_191282_a(compound, this.chestContents);

        if (this.lootTableName != null) {
            compound.func_74778_a("LootTableName", this.lootTableName);
            System.out.println("Збережено лут-таблицю: " + this.lootTableName);
        }
        return compound;
    }


    @Override
    public int func_70297_j_() {
        return 64;
    }

    @Override
    public boolean func_70300_a(EntityPlayer player) {
        return this.field_145850_b.func_175625_s(this.field_174879_c) == this &&
               player.func_70092_e((double)this.field_174879_c.func_177958_n() + 0.5D, (double)this.field_174879_c.func_177956_o() + 0.5D, (double)this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
    }

    @Override
    public void func_174889_b(EntityPlayer player) {}

    @Override
    public void func_174886_c(EntityPlayer player) {}

    @Override
    public boolean func_94041_b(int index, ItemStack stack) {
        return true;
    }

    @Override
    public void func_174888_l() {
        this.chestContents.clear();
    }

    @Override
    public String func_70005_c_() {
        return "container.abandoned_chest";
    }

    @Override
    public boolean func_145818_k_() {
        return false;
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentTranslation(this.func_70005_c_());
    }

    @Override
    protected NonNullList<ItemStack> func_190576_q() {
        return this.chestContents;
    }

   @Nullable
    @Override
    public ResourceLocation func_184276_b() {
        return new ResourceLocation("thaumicforever", "chests/hilltop_stones");
    }


    // Create the container for the chest
    @Override
    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn) {
        return new ContainerAbandonedChest(playerInventory, this);
    }

    @Override
    public String func_174875_k() {
        return "thaumicforever:abandoned_chest";
    }
}
