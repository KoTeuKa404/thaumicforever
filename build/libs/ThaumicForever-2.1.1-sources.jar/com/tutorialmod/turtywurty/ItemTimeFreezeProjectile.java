package com.tutorialmod.turtywurty;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemTimeFreezeProjectile extends Item {

    public ItemTimeFreezeProjectile() {
        super();
        func_77625_d(64);
        func_77627_a(true);
        func_77656_e(0);
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!player.field_71075_bZ.field_75098_d) {
            player.func_184586_b(hand).func_190918_g(1);
        }
        player.func_184185_a(SoundEvents.field_187511_aA, 0.3f, 0.4f / (field_77697_d.nextFloat() * 0.4f + 0.8f));
        if (!world.field_72995_K) {
            EntityTimeFreezeProjectile projectile = new EntityTimeFreezeProjectile(world, player);
            projectile.func_184538_a(player, player.field_70125_A, player.field_70177_z, -5.0f, 0.4f, 2.0f);
            world.func_72838_d(projectile);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }
}