package com.tutorialmod.turtywurty;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import thaumcraft.common.entities.monster.EntityGiantBrainyZombie;

public class ItemZombieHeartAmulet extends Item implements IBauble {

    public ItemZombieHeartAmulet() {
        func_77655_b("zombie_heart_amulet");
        setRegistryName("zombie_heart_amulet");
        func_77625_d(1);
    }

    // Вказуємо, що амулет буде працювати в слоті амулетів Baubles
    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET;
    }

    // Визивається кожен раз, коли гравець носить амулет у слоті Baubles
    @Override
    public void onWornTick(ItemStack stack, EntityLivingBase entity) {
        if (entity instanceof EntityPlayer && !entity.field_70170_p.field_72995_K) {
            EntityPlayer player = (EntityPlayer) entity;

            // Якщо здоров'я гравця менше або дорівнює 4 HP (2 серця)
            if (player.func_110143_aJ() <= 4.0F) {
                summonGiantZombie(player, player.field_70170_p);  // Призиваємо гігантського зомбі
                replaceWithBrokenAmulet(stack, player); // Заміна амулета на поламаний амулет
            }
        }
    }

    // Метод для ручного виклику зомбі за допомогою правої кнопки миші
    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);

        if (!world.field_72995_K) {
            summonGiantZombie(player, world);  // Призиваємо зомбі вручну
            replaceWithBrokenAmulet(stack, player);  // Заміна амулета на поламаний амулет
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    // Призов зомбі
    private void summonGiantZombie(EntityPlayer player, World world) {
        if (!world.field_72995_K) {
            EntityGiantBrainyZombie giantZombie = new EntityGiantBrainyZombie(world);
            giantZombie.func_70107_b(player.field_70165_t, player.field_70163_u, player.field_70161_v);  // Призиваємо зомбі біля гравця
            world.func_72838_d(giantZombie);
            world.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187899_gZ, SoundCategory.PLAYERS, 1.0F, 1.0F);  // Звук
        }
    }

    // Заміна амулета на поламаний амулет після використання
    private void replaceWithBrokenAmulet(ItemStack stack, EntityPlayer player) {
        stack.func_190918_g(1);  // Видаляємо амулет

        // Додаємо "поламаний амулет" у інвентар гравця
        ItemStack brokenAmulet = new ItemStack(ModItems.BROKEN_AMULET);  // Потрібно зареєструвати "поламаний амулет"
        if (!player.field_71071_by.func_70441_a(brokenAmulet)) {
            player.func_71019_a(brokenAmulet, false);  // Якщо інвентар повний, викидаємо на землю
        }
    }
    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE; // Встановлення рідкості на EPIC
    }
}
