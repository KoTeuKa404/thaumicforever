package thaumcraft.api.research.theorycraft;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import thaumcraft.api.capabilities.IPlayerKnowledge;
import thaumcraft.api.capabilities.ThaumcraftCapabilities;
import thaumcraft.api.research.ResearchCategories;
import thaumcraft.api.research.ResearchCategory;
import thaumcraft.api.research.ResearchEntry;
import thaumcraft.api.research.ResearchEntry.EnumResearchMeta; 

public class ResearchTableData 
{
	public TileEntity table;
	public String player;
	public int inspiration;
	public int inspirationStart;
	public int bonusDraws;
	public int placedCards;	
	public int aidsChosen;
	public int penaltyStart;
	public ArrayList<Long> savedCards = new ArrayList<Long>();
	public ArrayList<String> aidCards = new ArrayList<String>();
	/*
	 * categoryTotals stores the amount of progress per research category. Each point = 1% of progress towards a full theory.  
	 */
	public TreeMap<String,Integer> categoryTotals = new TreeMap<>();
	public ArrayList<String> categoriesBlocked = new ArrayList<String>();
	public ArrayList<CardChoice> cardChoices = new ArrayList<>();
	
	public CardChoice lastDraw;
	
	public class CardChoice {
		public TheorycraftCard card;		
		public String key;
		public boolean fromAid;
		public boolean selected;
		public CardChoice(String key, TheorycraftCard card, boolean aid, boolean selected) {
			this.key = key;
			this.card = card;
			this.fromAid = aid;
			this.selected = selected;
		}
		
		@Override
		public String toString() {
			return "key:"+key+
					" card:"+card.getSeed()+
					" fromAid:"+fromAid+
					" selected:"+selected;
		}				
	}
	
	public ResearchTableData(TileEntity tileResearchTable) {
		table = tileResearchTable;
	}
		
	public ResearchTableData(EntityPlayer player2, TileEntity tileResearchTable) {
		player = player2.func_70005_c_();
		table = tileResearchTable;
	}

	public boolean isComplete() {
		return inspiration<=0;
	}
	
	public boolean hasTotal(String cat) {
		return categoryTotals.containsKey(cat);
	}
	
	public int getTotal(String cat) {
		return categoryTotals.containsKey(cat)?categoryTotals.get(cat):0;
	}
	
	public void addTotal(String cat, int amt) {
		int current = categoryTotals.containsKey(cat)?categoryTotals.get(cat):0;
		current+=amt;
		if (current<=0)
			categoryTotals.remove(cat);
		else
			categoryTotals.put(cat,current);
	}	
	
	public void addInspiration(int amt) {
		inspiration += amt;
		if (inspiration>inspirationStart) inspiration = inspirationStart;
	}	
	
	public NBTTagCompound serialize() {
		NBTTagCompound nbt = new NBTTagCompound();
		
		nbt.func_74778_a("player", player);
		nbt.func_74768_a("inspiration", inspiration);
		nbt.func_74768_a("inspirationStart", inspirationStart);
		nbt.func_74768_a("placedCards", placedCards);
		nbt.func_74768_a("bonusDraws", bonusDraws);		
		nbt.func_74768_a("aidsChosen", aidsChosen);		
		nbt.func_74768_a("penaltyStart", penaltyStart);
		
		//
		NBTTagList savedTag = new NBTTagList();
		for (Long card:savedCards) {
			NBTTagCompound gt = new NBTTagCompound();
			gt.func_74772_a("card", card);
			savedTag.func_74742_a(gt);
		}		
		nbt.func_74782_a("savedCards", savedTag);		 		
				
		//
		NBTTagList categoriesBlockedTag = new NBTTagList();
		for (String category:categoriesBlocked) {
			NBTTagCompound gt = new NBTTagCompound();
			gt.func_74778_a("category", category);
			categoriesBlockedTag.func_74742_a(gt);
		}		
		nbt.func_74782_a("categoriesBlocked", categoriesBlockedTag);		 
		
		//
		NBTTagList categoryTotalsTag = new NBTTagList();
		for (String category:categoryTotals.keySet()) {
			NBTTagCompound gt = new NBTTagCompound();
			gt.func_74778_a("category", category);
			gt.func_74768_a("total", categoryTotals.get(category));
			categoryTotalsTag.func_74742_a(gt);
		}		
		nbt.func_74782_a("categoryTotals", categoryTotalsTag);		
		
		//
		NBTTagList aidCardsTag = new NBTTagList();
		for (String mc:aidCards) {
			NBTTagCompound gt = new NBTTagCompound();
			gt.func_74778_a("aidCard", mc);
			aidCardsTag.func_74742_a(gt);
		}		
		nbt.func_74782_a("aidCards", aidCardsTag);	
		
		//
		NBTTagList cardChoicesTag = new NBTTagList();
		for (CardChoice mc:cardChoices) {
			NBTTagCompound gt = serializeCardChoice(mc);
			cardChoicesTag.func_74742_a(gt);
		}		
		nbt.func_74782_a("cardChoices", cardChoicesTag);	
		
		if (lastDraw!=null) nbt.func_74782_a("lastDraw", serializeCardChoice(lastDraw));
				
		return nbt;
	}
	
	public NBTTagCompound serializeCardChoice(CardChoice mc) {
		NBTTagCompound nbt = new NBTTagCompound();	
		nbt.func_74778_a("cardChoice", mc.key);
		nbt.func_74757_a("aid", mc.fromAid); 
		nbt.func_74757_a("select", mc.selected);
		try {
			nbt.func_74782_a("cardNBT", mc.card.serialize());
		} catch (Exception e) {	}
		return nbt;
	}
	
	public void deserialize(NBTTagCompound nbt) {	
		if (nbt == null) return;	
		inspiration = nbt.func_74762_e("inspiration");
		inspirationStart = nbt.func_74762_e("inspirationStart");
		placedCards = nbt.func_74762_e("placedCards");
		bonusDraws = nbt.func_74762_e("bonusDraws");
		aidsChosen = nbt.func_74762_e("aidsChosen");
		penaltyStart = nbt.func_74762_e("penaltyStart");
		player=nbt.func_74779_i("player");
				
		//
		NBTTagList savedTag = nbt.func_150295_c("savedCards", (byte)10);
		savedCards = new ArrayList<Long>();
		for (int x=0;x<savedTag.func_74745_c();x++) {
			NBTTagCompound nbtdata = (NBTTagCompound) savedTag.func_150305_b(x);
			savedCards.add(nbtdata.func_74763_f("card"));
		}
		
		//
		NBTTagList categoriesBlockedTag = nbt.func_150295_c("categoriesBlocked", (byte)10);
		categoriesBlocked = new ArrayList<String>();
		for (int x=0;x<categoriesBlockedTag.func_74745_c();x++) {
			NBTTagCompound nbtdata = (NBTTagCompound) categoriesBlockedTag.func_150305_b(x);
			categoriesBlocked.add(nbtdata.func_74779_i("category"));
		}
		
		//
		NBTTagList categoryTotalsTag = nbt.func_150295_c("categoryTotals", (byte)10);
		categoryTotals = new TreeMap<String,Integer>();
		for (int x=0;x<categoryTotalsTag.func_74745_c();x++) {
			NBTTagCompound nbtdata = (NBTTagCompound) categoryTotalsTag.func_150305_b(x);
			categoryTotals.put(nbtdata.func_74779_i("category"), nbtdata.func_74762_e("total"));
		}
		
		//
		NBTTagList aidCardsTag = nbt.func_150295_c("aidCards", (byte)10);
		aidCards = new ArrayList<String>();
		for (int x=0;x<aidCardsTag.func_74745_c();x++) {
			NBTTagCompound nbtdata = (NBTTagCompound) aidCardsTag.func_150305_b(x);
			aidCards.add(nbtdata.func_74779_i("aidCard"));
		}
		
		//
		
		EntityPlayer pe = null;		
		if (this.table!=null && table.func_145831_w()!=null && !table.func_145831_w().field_72995_K) 
			pe = this.table.func_145831_w().func_72924_a(player);
			
		NBTTagList cardChoicesTag = nbt.func_150295_c("cardChoices", (byte)10);
		cardChoices = new ArrayList<CardChoice>();
		for (int x=0;x<cardChoicesTag.func_74745_c();x++) {			
			NBTTagCompound nbtdata = (NBTTagCompound) cardChoicesTag.func_150305_b(x);			
			CardChoice cc = deserializeCardChoice(nbtdata);
			if (cc!=null) cardChoices.add(cc);
		}
		
		lastDraw = deserializeCardChoice(nbt.func_74775_l("lastDraw"));
		
	}
	
	public CardChoice deserializeCardChoice(NBTTagCompound nbt) {	
		if (nbt == null) return null;	
		String key = nbt.func_74779_i("cardChoice");			
		TheorycraftCard tc=generateCardWithNBT(nbt.func_74779_i("cardChoice"), nbt.func_74775_l("cardNBT"));				
		if (tc==null) return null;
		return new CardChoice(key,tc,nbt.func_74767_n("aid"),nbt.func_74767_n("select"));
	}
	
	private boolean isCategoryBlocked(String cat) {
		return this.categoriesBlocked.contains(cat);
	}
	
	public void drawCards(int draw, EntityPlayer pe) {
		
		if (draw==3) {
			if (bonusDraws>0) {
				this.bonusDraws--;
			} else {
				draw=2;
			}
		}
		cardChoices.clear();
		this.player=pe.func_70005_c_();
		ArrayList<String> availCats = getAvailableCategories(pe);
		ArrayList<String> drawnCards = new ArrayList<>();
		boolean aidDrawn=false;
		int failsafe=0;
		while (draw>0 && failsafe<10000) {
			failsafe++;
			if (!aidDrawn && !aidCards.isEmpty() && pe.func_70681_au().nextFloat()<=.25) {
				int idx = pe.func_70681_au().nextInt(aidCards.size());
				String key = aidCards.get(idx);				
				TheorycraftCard card = generateCard(key,-1,pe);
				if (card==null || card.getInspirationCost()>inspiration || isCategoryBlocked(card.getResearchCategory())) continue;		
				
				if (drawnCards.contains(key)) continue;
				drawnCards.add(key);
				cardChoices.add(new CardChoice(key,card,true,false));				
				aidCards.remove(idx);
			} else {
				try {
					String[] cards = TheorycraftManager.cards.keySet().toArray(new String[]{});
					int idx = pe.func_70681_au().nextInt(cards.length);
					TheorycraftCard card = generateCard(cards[idx],-1,pe);
					if (card==null || card.isAidOnly() || card.getInspirationCost()>inspiration) continue;
					if (card.getResearchCategory()!=null) {
						boolean found=false;
						for (String cn:availCats) {
							if (cn.equals(card.getResearchCategory())) {
								found=true;
								break;
							}
						}
						if (!found) continue;
					}
					
					if (drawnCards.contains(cards[idx])) continue;
					drawnCards.add(cards[idx]);
					cardChoices.add(new CardChoice(cards[idx],card,false,false));
				} catch (Exception e) {
//					e.printStackTrace();
					continue;
				}
			}		
			draw--;
		}
	}
	
	private TheorycraftCard generateCard(String key, long seed, EntityPlayer pe) {
		if (key==null) return null;
		Class<TheorycraftCard> tcc = TheorycraftManager.cards.get(key);
		if (tcc==null) return null;
		TheorycraftCard tc=null;
		try {
			tc = tcc.newInstance();
			if (seed<0)
				if (pe!=null)
					tc.setSeed(pe.func_70681_au().nextLong());
				else
					tc.setSeed(System.nanoTime());
			else
				tc.setSeed(seed);
			if (pe!=null && !tc.initialize(pe, this)) return null;
		} catch (Exception e) {  }
		return tc;
	}
	
	private TheorycraftCard generateCardWithNBT(String key, NBTTagCompound nbt) {
		if (key==null) return null;
		Class<TheorycraftCard> tcc = TheorycraftManager.cards.get(key);
		if (tcc==null) return null;
		TheorycraftCard tc=null;
		try {
			tc = tcc.newInstance();
			tc.deserialize(nbt);
		} catch (Exception e) {  }
		return tc;
	}
	
	public void initialize(EntityPlayer player1, Set<String> aids) {
		inspirationStart=getAvailableInspiration(player1);
		inspiration= inspirationStart - aids.size();
		
		for (String muk:aids) {
			ITheorycraftAid mu = TheorycraftManager.aids.get(muk);
			if (mu!=null) {
				for (Class clazz:mu.getCards()) {
					aidCards.add(clazz.getName());
				}
			}
		}
	}
	
	
	public ArrayList<String> getAvailableCategories(EntityPlayer player) {
		ArrayList<String> cats = new ArrayList<String>();
		for(String rck: ResearchCategories.researchCategories.keySet()) {
			ResearchCategory rc = ResearchCategories.getResearchCategory(rck);
			if (rc==null || isCategoryBlocked(rck)) continue;
			if (rc.researchKey==null || ThaumcraftCapabilities.knowsResearchStrict(player, rc.researchKey)) {
				cats.add(rck);
			}
		}
		return cats;
	}
	
	public static int getAvailableInspiration(EntityPlayer player) {
		float tot = 5;
		IPlayerKnowledge knowledge = ThaumcraftCapabilities.getKnowledge(player);
		for (String s:knowledge.getResearchList()) {
			if (ThaumcraftCapabilities.knowsResearchStrict(player, s)) {
				ResearchEntry re = ResearchCategories.getResearch(s);
				if (re==null) continue;
				if (re.hasMeta(EnumResearchMeta.SPIKY)) 				
					tot+=.5f;
				if (re.hasMeta(EnumResearchMeta.HIDDEN)) 
					tot+=.1f;
			}
		}
		return Math.min(15, Math.round(tot));
	}
	
	
}

