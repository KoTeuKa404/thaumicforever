package thaumcraft.api.potions;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class PotionVisExhaust extends Potion
{
    public static Potion instance = null; // will be instantiated at runtime
    private int statusIconIndex = -1;
    
    public PotionVisExhaust(boolean par2, int par3)
    {
    	super(par2,par3);
    	func_76399_b(5, 1);
    	func_76390_b("potion.vis_exhaust");
    	func_76404_a(0.25D);
    }
    
	@Override
	public boolean func_76398_f() {
		return true;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public int func_76392_e() {
		Minecraft.func_71410_x().field_71446_o.func_110577_a(rl);
		return super.func_76392_e();
	}
	
	static final ResourceLocation rl = new ResourceLocation("thaumcraft","textures/misc/potions.png");
	
	@Override
	public void func_76394_a(EntityLivingBase target, int par2) {
		
	}
    
    
}
