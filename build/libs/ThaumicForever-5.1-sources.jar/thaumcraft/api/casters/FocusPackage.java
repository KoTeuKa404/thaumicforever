package thaumcraft.api.casters;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EntitySelectors;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;

import thaumcraft.api.casters.IFocusElement.EnumUnitType;

public class FocusPackage implements IFocusElement {
	
	@Override
	public String getResearch() {
		return null;
	}
	
	public World world;
	private EntityLivingBase caster;	
	private UUID casterUUID;
	
	private float power = 1;
	private int complexity = 0;
	
	int index;
	UUID uid;
	
	public List<IFocusElement> nodes =  Collections.synchronizedList(new ArrayList<>());	
	
	public FocusPackage() {	}

	public FocusPackage(EntityLivingBase caster) {
		super();
		this.world = caster.field_70170_p;
		this.caster = caster;
		this.casterUUID = caster.func_110124_au();
	}	
		
	@Override
	public String getKey() {
		return "thaumcraft.PACKAGE";
	}

	@Override
	public EnumUnitType getType() {
		return EnumUnitType.PACKAGE;
	}
	
	public int getComplexity() {
		return complexity;
	}

	public void setComplexity(int complexity) {
		this.complexity = complexity;
	}

	public UUID getUniqueID() {
		return uid;
	}

	public void setUniqueID(UUID id) {
		this.uid = id;
	}
	
	public int getExecutionIndex() {
		return index;
	}

	public void setExecutionIndex(int idx) {
		this.index = idx;
	}
	
	public void addNode(IFocusElement e) {
		nodes.add(e);
	}
	
	public UUID getCasterUUID() {
		if (caster!=null) casterUUID = caster.func_110124_au();
		return casterUUID;
	}

	public void setCasterUUID(UUID casterUUID) {
		this.casterUUID = casterUUID;
	}	
	
	public EntityLivingBase getCaster() {
		try {
			if (caster==null) {
				caster = world.func_152378_a(getCasterUUID());
			}
			if (caster==null) {
				for (EntityLivingBase e : world.func_175644_a(EntityLivingBase.class, EntitySelectors.field_94557_a)) {
					if (getCasterUUID().equals(e.func_110124_au())) {
						caster = e;
						break;
					}
				}
			}
		} catch (Exception e) {}
		return caster;
	}
	
	public FocusEffect[] getFocusEffects() {		
		return getFocusEffectsPackage(this);
	}
	
	private FocusEffect[] getFocusEffectsPackage(FocusPackage fp) {
		ArrayList<FocusEffect> out = new ArrayList<>();
		for (IFocusElement el:fp.nodes) {
			if (el instanceof FocusEffect) out.add((FocusEffect) el);
			else
			if (el instanceof FocusPackage) {
				for (FocusEffect fep:getFocusEffectsPackage((FocusPackage) el))
					out.add(fep);
			} else 
			if (el instanceof FocusModSplit) {
				for (FocusPackage fsp:((FocusModSplit)el).getSplitPackages())
					for (FocusEffect fep:getFocusEffectsPackage(fsp))
						out.add(fep);
			}
		}
		return out.toArray(new FocusEffect[]{});
	}

	public void deserialize(NBTTagCompound nbt) {
		uid = nbt.func_186857_a("uid");		
		index = nbt.func_74762_e("index");
		int dim = nbt.func_74762_e("dim");
		world = DimensionManager.getWorld(dim);
		setCasterUUID(nbt.func_186857_a("casterUUID"));
		power = nbt.func_74760_g("power");
		complexity = nbt.func_74762_e("complexity");
				
		NBTTagList nodelist = nbt.func_150295_c("nodes", (byte)10);
		nodes.clear();
		for (int x=0;x<nodelist.func_74745_c();x++) {
			NBTTagCompound nodenbt = (NBTTagCompound) nodelist.func_150305_b(x);
			EnumUnitType ut = EnumUnitType.valueOf(nodenbt.func_74779_i("type"));
			if (ut!=null) {
				if (ut==EnumUnitType.PACKAGE) {
					FocusPackage fp = new FocusPackage();
					fp.deserialize(nodenbt.func_74775_l("package"));
					nodes.add(fp);
					break;
				} else {
					IFocusElement fn = FocusEngine.getElement(nodenbt.func_74779_i("key")); 
					if (fn!=null) {						
						if (fn instanceof FocusNode) {
							((FocusNode)fn).initialize();
							if (((FocusNode)fn).getSettingList()!=null)
								for (String ns : ((FocusNode)fn).getSettingList()) {
									((FocusNode)fn).getSetting(ns).setValue(nodenbt.func_74762_e("setting."+ns));
								}
							
							if (fn instanceof FocusModSplit) {								
								((FocusModSplit)fn).deserialize(nodenbt.func_74775_l("packages"));		
							}
						}
						this.addNode(fn);
					}
				}
			}
		}
		
	}

	public NBTTagCompound serialize() {
		NBTTagCompound nbt = new NBTTagCompound();
		if (uid!=null) nbt.func_186854_a("uid", uid);
		nbt.func_74768_a("index", index);
		if (getCasterUUID() != null) nbt.func_186854_a("casterUUID", getCasterUUID());
		if (world!=null) nbt.func_74768_a("dim", world.field_73011_w.getDimension());
		nbt.func_74776_a("power", power);
		nbt.func_74768_a("complexity", complexity);
		
		//nodes
		NBTTagList nodelist = new NBTTagList();
		synchronized (nodes) {
			for (IFocusElement node:nodes) {
				if (node==null || node.getType()==null) continue;
				NBTTagCompound nodenbt = new NBTTagCompound();
				nodenbt.func_74778_a("type", node.getType().name());
				nodenbt.func_74778_a("key", node.getKey());
				if (node.getType()==EnumUnitType.PACKAGE) {
					nodenbt.func_74782_a("package", ((FocusPackage)node).serialize());
					nodelist.func_74742_a(nodenbt);
					break;
				} else {				
					if (node instanceof FocusNode && ((FocusNode)node).getSettingList()!=null)
						for (String ns : ((FocusNode)node).getSettingList()) {
							nodenbt.func_74768_a("setting."+ns, ((FocusNode)node).getSettingValue(ns));
						}
					if (node instanceof FocusModSplit) {	
						nodenbt.func_74782_a("packages", ((FocusModSplit)node).serialize());	
					}
					nodelist.func_74742_a(nodenbt);
				}			
			}
		}
		nbt.func_74782_a("nodes", nodelist);					
		
		return nbt;
	}

	public float getPower() {
		return power;
	}

	public void multiplyPower(float pow) {
		this.power *= pow;
	}

	public FocusPackage copy(EntityLivingBase caster) {
		FocusPackage fp = new FocusPackage(caster);
		fp.deserialize(this.serialize());
		return fp;
	}
	
	public void initialize(EntityLivingBase caster) {
		world=caster.func_130014_f_();
		IFocusElement node = nodes.get(0);
		if (node instanceof FocusMediumRoot && ((FocusMediumRoot)node).supplyTargets()==null) {
			((FocusMediumRoot)node).setupFromCaster(caster);
		}
	}

	public int getSortingHelper() {
		String s="";
		for (IFocusElement k:this.nodes) {
			s+=k.getKey();
			if (k instanceof FocusNode && ((FocusNode)k).getSettingList()!=null)
				for (String ns : ((FocusNode)k).getSettingList()) {
					s += ""+((FocusNode)k).getSettingValue(ns);
				}
		}		
		return s.hashCode();
	}

	
	
	

	
	
	
	
	

}
