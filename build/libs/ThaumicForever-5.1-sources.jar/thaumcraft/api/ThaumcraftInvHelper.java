package thaumcraft.api;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.VanillaInventoryCodeHooks;
import net.minecraftforge.items.wrapper.InvWrapper;
import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraftforge.oredict.OreDictionary;
import thaumcraft.common.lib.utils.InventoryUtils;

public class ThaumcraftInvHelper {

	public static class InvFilter {
		public boolean igDmg;
		public boolean igNBT;
		public boolean useOre;
		public boolean useMod;
		public boolean relaxedNBT = false;
	
		public InvFilter(boolean ignoreDamage, boolean ignoreNBT, boolean useOre, boolean useMod) {
			this.igDmg = ignoreDamage;
			this.igNBT = ignoreNBT;
			this.useOre = useOre;
			this.useMod = useMod;
		}		
		
		public InvFilter setRelaxedNBT() {
			relaxedNBT = true;
			return this;
		}
		
		public final static InvFilter STRICT = new InvFilter(false,false,false,false);
		public final static InvFilter BASEORE = new InvFilter(false,false,true,false);
	}

	public static IItemHandler getItemHandlerAt(World world, BlockPos pos, EnumFacing side) {
		Pair<IItemHandler, Object> dest = VanillaInventoryCodeHooks.getItemHandler(world, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), side);
		if (dest!=null && dest.getLeft()!=null) {
			return dest.getLeft();
		} else {
			TileEntity tileentity = world.func_175625_s(pos);
	        if (tileentity != null && tileentity instanceof IInventory) {            	
	        	return wrapInventory ((IInventory) tileentity, side);
	        }
		}
		return null;
	}

	public static IItemHandler wrapInventory(IInventory inventory, EnumFacing side) {
		return inventory instanceof ISidedInventory? new SidedInvWrapper((ISidedInventory) inventory, side) : new InvWrapper((IInventory) inventory);
	}

	/**
		 * Unlike the normal nbt comparison used by itemstacks, this method only checks if all the tags in stackA is present and equal in stackB. Any extra tags in stackB is ignored. 
		 * Some mods love adding their own nbt data to itemstacks which ends up breaking a lot of crafting recipes or similar checks
		 * This version of the check ignores capabilities as this method is primarily used on my side by things that do not have capabilities in any case.
		 * @param prime
		 * @param other
		 * @return
		 */	
		public static boolean areItemStackTagsEqualRelaxed(ItemStack prime, ItemStack other) {
			if (prime.func_190926_b() && other.func_190926_b())
		    {
		        return true;
		    }
		    else if (!prime.func_190926_b() && !other.func_190926_b())
		    {
	//	        if (prime.getTagCompound() == null && other.getTagCompound() != null)
	//	        {
	//	            return false;
	//	        }
	//	        else
	//	        {
		            return (prime.func_77978_p() == null || ThaumcraftInvHelper.compareTagsRelaxed(prime.func_77978_p(),other.func_77978_p()));
	//	        }
		    }
		    else
		    {
		        return false;
		    }
		}

	public static boolean compareTagsRelaxed(NBTTagCompound prime, NBTTagCompound other) {
		for (String key : prime.func_150296_c()) {			
			if (!other.func_74764_b(key) || !prime.func_74781_a(key).equals(other.func_74781_a(key))) {
				return false;
			}
		}		
		return true;
	}

	public static boolean areItemStacksEqualForCrafting(ItemStack stack0, Object in)
	{
		if (stack0==null && in!=null) return false;
		if (stack0!=null && in==null) return false;
		if (stack0==null && in==null) return true;
		
		if (in instanceof Object[]) return true;
		
		if (in instanceof String) {
			List<ItemStack> l = OreDictionary.getOres((String) in,false);
			return ThaumcraftInvHelper.containsMatch(false, new ItemStack[]{stack0}, l);
		}
		
		if (in instanceof ItemStack) {
			//nbt
			boolean t1= !stack0.func_77942_o() || ThaumcraftInvHelper.areItemStackTagsEqualForCrafting(stack0, (ItemStack) in);		
			if (!t1) return false;	
	        return OreDictionary.itemMatches((ItemStack) in, stack0, false);
		}
		
		return false;
	}

	public static boolean containsMatch(boolean strict, ItemStack[] inputs, List<ItemStack> targets)
	{
	    for (ItemStack input : inputs)
	    {
	        for (ItemStack target : targets)
	        {
	            if (OreDictionary.itemMatches(target, input, strict) && ItemStack.func_77970_a(target, input))
	            {
	                return true;
	            }
	        }
	    }
	    return false;
	}

	public static boolean areItemsEqual(ItemStack s1,ItemStack s2)
	{
		if (s1.func_77984_f() && s2.func_77984_f())
		{
			return s1.func_77973_b() == s2.func_77973_b();
		} else
			return s1.func_77973_b() == s2.func_77973_b() && s1.func_77952_i() == s2.func_77952_i();
	}

	public static boolean areItemStackTagsEqualForCrafting(ItemStack slotItem,ItemStack recipeItem)
	{
		if (recipeItem == null || slotItem == null) return false;
		if (recipeItem.func_77978_p()!=null && slotItem.func_77978_p()==null ) return false;
		if (recipeItem.func_77978_p()==null ) return true;
		
		Iterator iterator = recipeItem.func_77978_p().func_150296_c().iterator();
	    while (iterator.hasNext())
	    {
	        String s = (String)iterator.next();
	        if (slotItem.func_77978_p().func_74764_b(s)) {
	        	if (!slotItem.func_77978_p().func_74781_a(s).toString().equals(
	        			recipeItem.func_77978_p().func_74781_a(s).toString())) {
	        		return false;
	        	}
	        } else {
	    		return false;
	        }
	        
	    }
	    return true;
	}

	public static ItemStack insertStackAt(World world, BlockPos pos, EnumFacing side, ItemStack stack, boolean simulate)
	{		
		IItemHandler inventory = getItemHandlerAt(world,pos,side); 		
		if (inventory!=null) {			
			return ItemHandlerHelper.insertItemStacked(inventory, stack, simulate);
		}
		return stack;
	}
	
	public static ItemStack hasRoomFor(World world, BlockPos pos, EnumFacing side, ItemStack stack) {
		ItemStack testStack = insertStackAt(world, pos, side, stack.func_77946_l(), true);
		if (testStack.func_190926_b()) {
			return stack.func_77946_l();
		}
		testStack.func_190920_e(stack.func_190916_E() - testStack.func_190916_E()); 
		return testStack;
	}

	public static boolean hasRoomForSome(World world, BlockPos pos, EnumFacing side, ItemStack stack) {
		ItemStack testStack = insertStackAt(world, pos, side, stack.func_77946_l(), true);
		return stack.func_190916_E()==0 || testStack.func_190916_E()!=stack.func_190916_E();
	}
	
	public static boolean hasRoomForAll(World world, BlockPos pos, EnumFacing side, ItemStack stack) {
		return insertStackAt(world, pos, side, stack.func_77946_l(), true).func_190926_b();
	}

	public static int countTotalItemsIn(IItemHandler inventory, ItemStack stack, ThaumcraftInvHelper.InvFilter filter) {
		int count = 0;    	
		if (inventory!=null) {			
			for (int a=0;a<inventory.getSlots();a++) {
	    		if (InventoryUtils.areItemStacksEqual(stack,inventory.getStackInSlot(a),filter)) {
	    			count+=inventory.getStackInSlot(a).func_190916_E();
	    		}
	    	}    	
		}    	
		return count;
	}

	public static int countTotalItemsIn(World world, BlockPos pos, EnumFacing side, ItemStack stack, ThaumcraftInvHelper.InvFilter filter) {
		return countTotalItemsIn(getItemHandlerAt(world,pos,side),stack,filter);
	}

}
