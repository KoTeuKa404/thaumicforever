package com.koteuka404.thaumicforever;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.oredict.OreDictionary;

public class TileEntityCompressor extends TileEntity implements ITickable {

    private ItemStackHandler inventory = new ItemStackHandler(2); 
    private int compressTime = 0;
    private ItemStack selectedPlate = ItemStack.field_190927_a;  
    private ItemStack lastInput = ItemStack.field_190927_a;  

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K) {
            ItemStack input = inventory.getStackInSlot(0);  
            ItemStack output = inventory.getStackInSlot(1);  

            if (!ItemStack.func_179545_c(input, lastInput)) {
                selectedPlate = ItemStack.field_190927_a;
                lastInput = input.func_77946_l();
                func_70296_d();
            }

            if (!input.func_190926_b() && (isValidInput(input) && !selectedPlate.func_190926_b() || isThauminite(input))) {
                if (!output.func_190926_b() && !isSameMaterial(selectedPlate, output)) {
                    return; 
                }

                compressTime++;

                if (compressTime >= 50) { 
                    compressItem(input);
                    compressTime = 0;
                }
            } else {
                compressTime = 0;
            }
        }
    }

    private void compressItem(ItemStack input) {
        if (!selectedPlate.func_190926_b() || isThauminite(input)) {
            ItemStack output = inventory.getStackInSlot(1);
            ItemStack plateToCreate = selectedPlate;

            if (isThauminite(input)) {
                plateToCreate = new ItemStack(Item.func_111206_d("thaumicbases:thauminite_plate"));
            }

            if (!output.func_190926_b() && output.func_77969_a(plateToCreate)) {
                output.func_190917_f(1); 
                inventory.setStackInSlot(1, output); 
            } else if (output.func_190926_b()) {
                inventory.setStackInSlot(1, plateToCreate.func_77946_l());
            }

            inventory.extractItem(0, 1, false); 
            func_70296_d(); 
        }
    }

    private boolean isThauminite(ItemStack stack) {
        if (stack == null || stack.func_190926_b()) {
            return false;
        }
        String itemName = stack.func_77973_b().getRegistryName().toString();
        return itemName.equals("thaumicbases:thauminite_ingot") || itemName.equals("thaumicbases:thauminite_plate");
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentTranslation("container.compressor");
    }

    public static boolean isValidInput(ItemStack stack) {
        int[] oreIds = OreDictionary.getOreIDs(stack);
        for (int id : oreIds) {
            String oreName = OreDictionary.getOreName(id);
            if (oreName.startsWith("ingot")) { 
                return true;
            }
        }
        return false;
    }

    private boolean isSameMaterial(ItemStack input, ItemStack output) {
        if (input == null || output == null || input.func_190926_b() || output.func_190926_b()) {
            return false;
        }
    
        if (isThauminite(input) && isThauminite(output)) {
            return true; 
        }
    
        int[] inputOreIds = OreDictionary.getOreIDs(input);
        int[] outputOreIds = OreDictionary.getOreIDs(output);
    
        for (int inputId : inputOreIds) {
            for (int outputId : outputOreIds) {
                if (inputId == outputId) {
                    return true; 
                }
            }
        }
        return false; 
    }
    

    public List<ItemStack> getPlateOptions() {
        ItemStack input = inventory.getStackInSlot(0); 
        List<ItemStack> plateOptions = new ArrayList<>();

        if (!input.func_190926_b()) {
            int[] oreIds = OreDictionary.getOreIDs(input);
            for (int id : oreIds) {
                String oreName = OreDictionary.getOreName(id);
                if (oreName.startsWith("ingot")) {
                    String plateName = "plate" + oreName.substring(5);
                    plateOptions.addAll(OreDictionary.getOres(plateName));  
                }
            }
        }

        return plateOptions;
    }

    public void setSelectedPlate(ItemStack plate) {
        this.selectedPlate = plate;
        func_70296_d(); 
    }

    public ItemStack getSelectedPlate() {
        return this.selectedPlate;
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
        super.func_189515_b(compound);

        // Збереження інвентаря
        compound.func_74782_a("Inventory", inventory.serializeNBT());

        if (!selectedPlate.func_190926_b()) {
            NBTTagCompound selectedPlateTag = new NBTTagCompound();
            selectedPlate.func_77955_b(selectedPlateTag);
            compound.func_74782_a("SelectedPlate", selectedPlateTag);
        }

        if (!lastInput.func_190926_b()) {
            NBTTagCompound lastInputTag = new NBTTagCompound();
            lastInput.func_77955_b(lastInputTag);
            compound.func_74782_a("LastInput", lastInputTag);
        }

        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound) {
        super.func_145839_a(compound);

        if (compound.func_74764_b("Inventory")) {
            inventory.deserializeNBT(compound.func_74775_l("Inventory"));
        }

        if (compound.func_74764_b("SelectedPlate")) {
            NBTTagCompound selectedPlateTag = compound.func_74775_l("SelectedPlate");
            selectedPlate = new ItemStack(selectedPlateTag);
        }

        if (compound.func_74764_b("LastInput")) {
            NBTTagCompound lastInputTag = compound.func_74775_l("LastInput");
            lastInput = new ItemStack(lastInputTag);
        }

        func_70296_d(); 
    }

    public ItemStackHandler getInventory() {
        return this.inventory;
    }

    public boolean isUsableByPlayer(EntityPlayer player) {
        if (field_145850_b.func_175625_s(field_174879_c) != this) {
            return false;
        } else {
            return player.func_70092_e((double) field_174879_c.func_177958_n() + 0.5D, (double) field_174879_c.func_177956_o() + 0.5D, (double) field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
        }
    }
}
