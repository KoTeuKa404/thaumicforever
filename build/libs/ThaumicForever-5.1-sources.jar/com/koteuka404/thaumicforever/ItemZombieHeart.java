package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemZombieHeart extends ItemFood {

    public ItemZombieHeart() {
        super(2, 0.1F, false);
        func_77655_b("zombie_heart");  
        setRegistryName("zombie_heart");    

        func_77848_i(); 
    }

    @Override
    protected void func_77849_c(ItemStack stack, World world, EntityPlayer player) {
        super.func_77849_c(stack, world, player);

        if (!world.field_72995_K) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 80, 1)); 
            player.func_70690_d(new PotionEffect(MobEffects.field_76431_k, 200, 0));
        }
    }
}
