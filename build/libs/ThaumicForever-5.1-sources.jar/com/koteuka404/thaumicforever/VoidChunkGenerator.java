package com.koteuka404.thaumicforever;

import java.util.Collections;
import java.util.List;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;

public class VoidChunkGenerator implements IChunkGenerator {
    private final World world;

    public VoidChunkGenerator(World worldIn) {
        this.world = worldIn;
    }

    @Override
    public Chunk func_185932_a(int x, int z) {
        ChunkPrimer chunkPrimer = new ChunkPrimer();
        return new Chunk(this.world, chunkPrimer, x, z);
    }

    @Override
    public void func_185931_b(int x, int z) {
        // Порожній світ
    }

    @Override
    public boolean func_185933_a(Chunk chunkIn, int x, int z) {
        return false;
    }

    @Override
    public BlockPos func_180513_a(World worldIn, String structureName, BlockPos position, boolean flag) {
        return null;
    }

    @Override
    public boolean func_193414_a(World worldIn, String structureName, BlockPos pos) {
        return false;
    }

    @Override
    public void func_180514_a(Chunk chunkIn, int x, int z) {
        // Нічого не генеруємо
    }

    @Override
    public List<SpawnListEntry> func_177458_a(EnumCreatureType creatureType, BlockPos pos) {
        return Collections.emptyList();
    }
}
