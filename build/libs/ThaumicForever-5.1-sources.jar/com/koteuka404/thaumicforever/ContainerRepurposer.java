package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;

public class ContainerRepurposer extends Container {

    private final TileEntityRepurposer tileEntity;

    public ContainerRepurposer(InventoryPlayer playerInv, TileEntityRepurposer tileEntity) {
        this.tileEntity = tileEntity;

        this.func_75146_a(new JewelrySlot(tileEntity.getInventory(), 0, 55, 13)); // Input слот
        this.func_75146_a(new JewelrySlot(tileEntity.getInventory(), 1, 104, 13)); // Output слот

        bindPlayerInventory(playerInv);
    }

    private void bindPlayerInventory(InventoryPlayer playerInventory) {
        int inventoryYOffset = 59; 
        int hotbarYOffset = 117;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                func_75146_a(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, inventoryYOffset + i * 18));
            }
        }
        for (int k = 0; k < 9; k++) {
            func_75146_a(new Slot(playerInventory, k, 8 + k * 18, hotbarYOffset));
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return this.tileEntity.isUsableByPlayer(playerIn);
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d()) {
            ItemStack stackInSlot = slot.func_75211_c();
            itemstack = stackInSlot.func_77946_l();

            if (index < 2) {
                if (!this.func_75135_a(stackInSlot, 2, this.field_75151_b.size(), true)) {
                    return ItemStack.field_190927_a;
                }
                slot.func_75220_a(stackInSlot, itemstack);
            } else {
                if (index >= 2 && index < this.field_75151_b.size()) {
                    if (!this.func_75135_a(stackInSlot, 0, 1, false)) {
                        return ItemStack.field_190927_a;
                    }
                }
            }

            if (stackInSlot.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }

            if (stackInSlot.func_190916_E() == itemstack.func_190916_E()) {
                return ItemStack.field_190927_a;
            }

            slot.func_190901_a(playerIn, stackInSlot);
        }

        return itemstack;
    }

    private static class JewelrySlot extends SlotItemHandler {
        public JewelrySlot(net.minecraftforge.items.IItemHandler itemHandler, int index, int xPosition, int yPosition) {
            super(itemHandler, index, xPosition, yPosition);
        }
    
        @Override
        public boolean func_75214_a(ItemStack stack) {
            return isJewelryValid(stack);
        }
    
        private boolean isJewelryValid(ItemStack stack) {
            if (stack.func_82833_r().toLowerCase().contains("ring") ||
                stack.func_82833_r().toLowerCase().contains("amulet") ||
                stack.func_82833_r().toLowerCase().contains("head") ||
                stack.func_82833_r().toLowerCase().contains("belt") ||
                stack.func_82833_r().toLowerCase().contains("body") ||
                stack.func_82833_r().toLowerCase().contains("charm")) {
                return true;
            }
            return false;
        }
    }
    
}
