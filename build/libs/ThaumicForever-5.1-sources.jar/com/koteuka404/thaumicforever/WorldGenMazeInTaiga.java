package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeTaiga;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenMazeInTaiga implements IWorldGenerator {

    private static final ResourceLocation MAZE_STRUCTURE = new ResourceLocation("thaumicforever", "saved_structure");

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.field_72995_K) {
            return; 
        }
    
        if (world.field_73011_w.getDimension() == 0) {
            if (random.nextInt(700) != 0) {
                return;
            }
    
            int x = chunkX * 16 + random.nextInt(16);
            int z = chunkZ * 16 + random.nextInt(16);
            int y = 10 + random.nextInt(31);
            BlockPos pos = new BlockPos(x, y, z);
            Biome biome = world.func_180494_b(pos);
    
            if (biome instanceof BiomeTaiga) {
                if (generateMaze(world, pos)) {
                    TemplateManager templateManager = world.func_72860_G().func_186340_h();
                    Template template = templateManager.func_186237_a(world.func_73046_m(), MAZE_STRUCTURE);
                    if (template != null) {
                        BlockPos size = template.func_186259_a();
                        BlockPos endPos = pos.func_177971_a(size);
    
                        WorldTickHandler.getInstance().addDungeonBounds(pos, endPos);
                    }
                }
            }
        }
    }
    

    private boolean generateMaze(World world, BlockPos pos) {
        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = templateManager.func_186237_a(world.func_73046_m(), MAZE_STRUCTURE);

        if (template != null) {
            PlacementSettings settings = new PlacementSettings()
                    .func_186222_a(false)
                    .func_186225_a(Blocks.field_189881_dj); 

            template.func_186260_a(world, pos, settings); 
            return true;
        } else {
            return false;
        }
    }
}
