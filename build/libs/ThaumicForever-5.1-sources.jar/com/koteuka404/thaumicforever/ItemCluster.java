package com.koteuka404.thaumicforever;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class ItemCluster extends Item {
    public static final String[] CLUSTER_TYPES = new String[]{"chromium", "iridium", "quartz", "charged_quartz"};

    public ItemCluster() {
        this.func_77627_a(true);
        this.func_77656_e(0); 
    }

    @Override
    public String func_77667_c(ItemStack stack) {
        int metadata = stack.func_77960_j();
        if (metadata < 0 || metadata >= CLUSTER_TYPES.length) {
            metadata = 0;
        }
        return super.func_77658_a() + "." + CLUSTER_TYPES[metadata];
    }

    @Override
    public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (func_194125_a(tab)) {
            for (int i = 0; i < CLUSTER_TYPES.length; i++) {
                items.add(new ItemStack(this, 1, i)); 
            }
        }
    }
}
