package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.aspects.IAspectContainer;
import thaumcraft.api.aspects.IEssentiaTransport;
import thaumcraft.api.crafting.ContainerDummy;

public class TileEntityMatteryDuplicator extends TileEntity implements IInventory, ITickable, IAspectContainer, IEssentiaTransport {

    private ItemStack[] inventory = new ItemStack[10];
    private String customName;
    private InventoryCrafting craftMatrix = new InventoryCrafting(new ContainerDummy(), 3, 3);

    private AspectList essentia = new AspectList();
    private static final Aspect REQUIRED_ESSENTIA = AspectRegistry.MATTERYA;
    private static final int ESSENTIA_COST = 100;
    private static final int MAX_ESSENTIA_AMOUNT = 500;
    private int essentiaAmount = 0;
    private boolean inventoryChanged = false;
    public TileEntityMatteryDuplicator() {
        for (int i = 0; i < inventory.length; i++) {
            inventory[i] = ItemStack.field_190927_a;
        }
    }

    private ItemStack previousResult = ItemStack.field_190927_a;

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K) {
            fillWithEssentia();
    
            ItemStack result = previousResult;
            if (inventoryChanged) {
                result = createCraftingResult();
                previousResult = result; 
                inventoryChanged = false;
            }
    
            ItemStack currentResult = func_70301_a(9);
    
            if (!result.func_190926_b() && hasEnoughEssentia()) {
                if (currentResult.func_190926_b()) {
                    func_70299_a(9, result.func_77946_l()); 
                  
                }
            } else {
                if (!currentResult.func_190926_b()) {
                    func_70299_a(9, ItemStack.field_190927_a);
                }
            }
    
            if (inventoryChanged || (!result.func_190926_b() && currentResult.func_190926_b())) {
                markForUpdate();
            }
        }
    }
    

    public void consumeEssentia() {
        if (essentiaAmount >= ESSENTIA_COST) {
            essentiaAmount -= ESSENTIA_COST;
            if (essentiaAmount < 0) {
                essentiaAmount = 0;
            }
            markForUpdate();
        }
    }

    private void fillWithEssentia() {
        for (EnumFacing facing : EnumFacing.values()) {
            TileEntity te = field_145850_b.func_175625_s(field_174879_c.func_177972_a(facing));
            if (te instanceof IEssentiaTransport) {
                IEssentiaTransport transport = (IEssentiaTransport) te;
                if (transport.canOutputTo(facing.func_176734_d()) && essentiaAmount < MAX_ESSENTIA_AMOUNT) {
                    Aspect essentiaType = transport.getEssentiaType(facing.func_176734_d());
                    if (essentiaType != null && essentiaType == REQUIRED_ESSENTIA) {
                        int taken = transport.takeEssentia(essentiaType, 1, facing.func_176734_d());
                        if (taken > 0) {
                            essentiaAmount += taken;
                            if (essentiaAmount > MAX_ESSENTIA_AMOUNT) {
                                essentiaAmount = MAX_ESSENTIA_AMOUNT;
                            }
                            markForUpdate();
                        }
                    }
                }
            }
        }
    }

    public boolean hasEnoughEssentia() {
        return essentiaAmount >= ESSENTIA_COST;
    }


    private ItemStack createCraftingResult() {
        for (int i = 0; i < 9; i++) {
            if (inventory[i] == null) {
                inventory[i] = ItemStack.field_190927_a;
            }
            craftMatrix.func_70299_a(i, inventory[i]);
        }
    
        IRecipe recipe = CraftingManager.func_192413_b(craftMatrix, field_145850_b);
        if (recipe != null && recipe.func_77569_a(craftMatrix, field_145850_b)) {
            return recipe.func_77572_b(craftMatrix);
        }
    
        return ItemStack.field_190927_a;
    }
    
    @Override
    public void func_70299_a(int index, ItemStack stack) {
        inventory[index] = stack != null ? stack : ItemStack.field_190927_a;
        inventoryChanged = true; 
        func_70296_d();
    }
    
    private void updateCraftingResult() {
        ItemStack result = createCraftingResult();
        inventory[9] = result.func_190926_b() ? ItemStack.field_190927_a : result.func_77946_l();
        previousResult = result.func_77946_l();
        func_70296_d();
    }

    private void markForUpdate() {
        func_70296_d(); 
        if (field_145850_b != null) {
            field_145850_b.func_184138_a(field_174879_c, field_145850_b.func_180495_p(field_174879_c), field_145850_b.func_180495_p(field_174879_c), 3);
            field_145850_b.func_175704_b(field_174879_c, field_174879_c);
        }
    }

    @Override
    public NBTTagCompound func_189517_E_() {
        NBTTagCompound tag = super.func_189517_E_();
        tag.func_74768_a("EssentiaAmount", essentiaAmount);
        return tag;
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        super.handleUpdateTag(tag);
        this.essentiaAmount = tag.func_74762_e("EssentiaAmount");
    }

    @Override
    public SPacketUpdateTileEntity func_189518_D_() {
        NBTTagCompound tag = new NBTTagCompound();
        func_189515_b(tag);
        return new SPacketUpdateTileEntity(this.field_174879_c, 1, tag);
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        func_145839_a(pkt.func_148857_g());
        field_145850_b.func_175704_b(field_174879_c, field_174879_c);
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
        super.func_189515_b(compound);
        compound.func_74768_a("EssentiaAmount", essentiaAmount);

        NBTTagList nbtTagList = new NBTTagList();
        for (int i = 0; i < this.inventory.length; i++) {
            if (!this.inventory[i].func_190926_b()) {
                NBTTagCompound itemTag = new NBTTagCompound();
                itemTag.func_74774_a("Slot", (byte) i);
                this.inventory[i].func_77955_b(itemTag);
                nbtTagList.func_74742_a(itemTag);
            }
        }
        compound.func_74782_a("Items", nbtTagList);
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound) {
        super.func_145839_a(compound);
        this.essentiaAmount = compound.func_74762_e("EssentiaAmount");

        NBTTagList nbtTagList = compound.func_150295_c("Items", 10);
        this.inventory = new ItemStack[this.func_70302_i_()];
        for (int i = 0; i < nbtTagList.func_74745_c(); i++) {
            NBTTagCompound itemTag = nbtTagList.func_150305_b(i);
            int slot = itemTag.func_74771_c("Slot") & 255;
            if (slot >= 0 && slot < this.inventory.length) {
                this.inventory[slot] = new ItemStack(itemTag);
            }
        }
    }

    @Override
    public AspectList getAspects() {
        AspectList aspects = new AspectList();
        aspects.add(REQUIRED_ESSENTIA, essentiaAmount);
        return aspects;
    }

    @Override
    public void setAspects(AspectList aspects) {
    }

    @Override
    public boolean doesContainerAccept(Aspect aspect) {
        return aspect == REQUIRED_ESSENTIA;
    }

    @Override
    public int addToContainer(Aspect aspect, int amount) {
        if (aspect == REQUIRED_ESSENTIA && essentiaAmount + amount <= MAX_ESSENTIA_AMOUNT) {
            int essentiaToAdd = Math.min(amount, MAX_ESSENTIA_AMOUNT - essentiaAmount);
            essentiaAmount += essentiaToAdd;
            markForUpdate();
            return essentiaToAdd;
        }
        return 0;
    }

    @Override
    public boolean takeFromContainer(Aspect aspect, int amount) {
        if (aspect == REQUIRED_ESSENTIA && essentiaAmount >= amount) {
            essentiaAmount -= amount;
            markForUpdate();
            return true;
        }
        return false;
    }

    @Override
    public boolean doesContainerContainAmount(Aspect aspect, int amount) {
        return aspect == REQUIRED_ESSENTIA && essentiaAmount >= amount;
    }

    @Override
    public int containerContains(Aspect aspect) {
        return essentiaAmount;
    }

    @Override
    public boolean doesContainerContain(AspectList ot) {
        return ot.getAmount(REQUIRED_ESSENTIA) <= essentiaAmount;
    }

    @Override
    public boolean takeFromContainer(AspectList ot) {
        if (doesContainerContain(ot)) {
            takeFromContainer(REQUIRED_ESSENTIA, ot.getAmount(REQUIRED_ESSENTIA));
            return true;
        }
        return false;
    }

    @Override
    public boolean isConnectable(EnumFacing face) {
        return true;
    }

    @Override
    public boolean canInputFrom(EnumFacing face) {
        return true;
    }

    @Override
    public boolean canOutputTo(EnumFacing face) {
        return false;
    }

    @Override
    public int getMinimumSuction() {
        return 128;
    }

    @Override
    public int getSuctionAmount(EnumFacing face) {
        return essentiaAmount < MAX_ESSENTIA_AMOUNT ? 128 : 0;
    }

    @Override
    public Aspect getSuctionType(EnumFacing face) {
        return REQUIRED_ESSENTIA;
    }

    @Override
    public int addEssentia(Aspect aspect, int amount, EnumFacing face) {
        return addToContainer(aspect, amount);
    }

    @Override
    public int takeEssentia(Aspect aspect, int amount, EnumFacing face) {
        return takeFromContainer(aspect, amount) ? amount : 0;
    }

    @Override
    public int getEssentiaAmount(EnumFacing face) {
        return essentiaAmount;
    }

    @Override
    public Aspect getEssentiaType(EnumFacing face) {
        return REQUIRED_ESSENTIA;
    }

    @Override
    public void setSuction(Aspect aspect, int amount) {
    }

    @Override
    public boolean func_145818_k_() {
        return this.customName != null && !this.customName.isEmpty();
    }

    @Override
    public String func_70005_c_() {
        return this.func_145818_k_() ? this.customName : "container.mattery_duplicator";
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentString(this.func_70005_c_());
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    @Override
    public int func_70302_i_() {
        return this.inventory.length;
    }

    @Override
    public boolean func_94041_b(int index, ItemStack stack) {
        return true;
    }

    @Override
    public boolean func_70300_a(EntityPlayer player) {
        return this.field_145850_b.func_175625_s(this.field_174879_c) == this &&
                player.func_70092_e((double) this.field_174879_c.func_177958_n() + 0.5D, (double) this.field_174879_c.func_177956_o() + 0.5D, (double) this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
    }

    @Override
    public ItemStack func_70301_a(int index) {
        if (index >= 0 && index < this.inventory.length) {
            return this.inventory[index] != null ? this.inventory[index] : ItemStack.field_190927_a;
        }
        return ItemStack.field_190927_a;
    }

    @Override
    public ItemStack func_70298_a(int index, int count) {
        if (!inventory[index].func_190926_b()) {
            ItemStack itemstack;

            if (inventory[index].func_190916_E() <= count) {
                itemstack = inventory[index];
                inventory[index] = ItemStack.field_190927_a;
                func_70296_d();
                updateCraftingResult();
                return itemstack;
            } else {
                itemstack = inventory[index].func_77979_a(count);
                if (inventory[index].func_190916_E() == 0) {
                    inventory[index] = ItemStack.field_190927_a;
                }
                func_70296_d();
                updateCraftingResult();
                return itemstack;
            }
        } else {
            return ItemStack.field_190927_a;
        }
    }

    @Override
    public ItemStack func_70304_b(int index) {
        if (!inventory[index].func_190926_b()) {
            ItemStack itemstack = inventory[index];
            inventory[index] = ItemStack.field_190927_a;
            updateCraftingResult();
            return itemstack;
        } else {
            return ItemStack.field_190927_a;
        }
    }

    @Override
    public int func_70297_j_() {
        return 64;
    }

    @Override
    public void func_174889_b(EntityPlayer player) {}

    @Override
    public void func_174886_c(EntityPlayer player) {}

    @Override
    public int func_174887_a_(int id) {
        return 0;
    }

    @Override
    public void func_174885_b(int id, int value) {}

    @Override
    public int func_174890_g() {
        return 0;
    }

    @Override
    public void func_174888_l() {
        for (int i = 0; i < inventory.length; i++) {
            inventory[i] = ItemStack.field_190927_a;
        }
    }

    @Override
    public boolean func_191420_l() {
        for (ItemStack stack : inventory) {
            if (!stack.func_190926_b()) {
                return false;
            }
        }
        return true;
    }
}