package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.block.BlockCauldron;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent;

public class RainCauldronFiller {

    private static final int CHECK_INTERVAL = 100; 
    private int tickCounter = 0;

    @SubscribeEvent
    public void onWorldTick(WorldTickEvent event) {
        tickCounter++;
        if (tickCounter < CHECK_INTERVAL) {
            return;
        }
        tickCounter = 0; 

        World world = event.world;

        if (world.func_72896_J()) {
            world.field_73010_i.forEach(player -> {
                BlockPos playerPos = player.func_180425_c();
                Random random = world.field_73012_v;

                for (int i = 0; i < 5; i++) { 
                    int xOffset = random.nextInt(21) - 10;
                    int zOffset = random.nextInt(21) - 10;
                    BlockPos cauldronPos = playerPos.func_177982_a(xOffset, 0, zOffset);
                    IBlockState state = world.func_180495_p(cauldronPos);

                    if (state.func_177230_c() instanceof BlockCauldron) {
                        int level = state.func_177229_b(BlockCauldron.field_176591_a);

                        
                        if (level < 3) {
                            if (random.nextInt(100) < 60) { 
                                world.func_180501_a(cauldronPos, state.func_177226_a(BlockCauldron.field_176591_a, level + 1), 2);
                            }
                        }
                    }
                }
            });
        }
    }
}
