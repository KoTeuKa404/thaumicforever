package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockAntiFlightStone extends Block implements ITileEntityProvider {

    public BlockAntiFlightStone() {
        super(Material.field_151576_e);
        func_149663_c("anti_flight_stone");
        setRegistryName("anti_flight_stone");
        func_149711_c(3.0F);
        func_149647_a(ThaumicForever.CREATIVE_TAB);
    }

    @Override
    public TileEntity func_149915_a(World worldIn, int meta) {
        return new TileEntityAntiFlightStone();
    }

    @Override
    public void func_180663_b(World world, BlockPos pos, IBlockState state) {
        TileEntity te = world.func_175625_s(pos);
        if (te instanceof TileEntityAntiFlightStone) {
            ((TileEntityAntiFlightStone) te).func_73660_a();
        }
        super.func_180663_b(world, pos, state);
    }
}
