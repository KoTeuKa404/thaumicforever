package com.koteuka404.thaumicforever;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.client.lib.UtilsFX;

public class DoubleTableGui extends GuiContainer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ThaumicForever.MODID, "textures/gui/guiresearchtable.png");
    private final IInventory tileEntity;
    private long lastClickedTime = 0;
    private boolean shouldLogAspects = false; // Контролює, чи потрібно виводити аспекти

    public DoubleTableGui(InventoryPlayer playerInventory, IInventory tileEntity) {
        super(new DoubleTableContainer(playerInventory, tileEntity));
        this.tileEntity = tileEntity;
        this.field_146999_f = 240;
        this.field_147000_g = 240;
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        field_146297_k.func_110434_K().func_110577_a(TEXTURE);
        func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);

        // **Малювання кнопки (лупи)**
        int lupaX = this.field_147003_i + 85;
        int lupaY = this.field_147009_r + 40;
        if (System.currentTimeMillis() - lastClickedTime < 1000) {
            func_73729_b(lupaX, lupaY, 241, 16, 16, 16); // Активна лупа
        } else {
            func_73729_b(lupaX, lupaY, 241, 0, 16, 16); // Неактивна лупа
        }

        // **Отримання аспектів з TileEntity**
        if (tileEntity instanceof DoubleTableTileEntity) {
            DoubleTableTileEntity doubleTable = (DoubleTableTileEntity) tileEntity;

            // Рендер лівої частини аспектів
            AspectList storedAspects = doubleTable.getStoredAspects();
            if (storedAspects != null) {
                renderSidebarAspects(storedAspects);
            }

            // Рендер правої частини аспектів зі скролу
            ItemStack scroll = doubleTable.func_70301_a(5);
            if (!scroll.func_190926_b() && scroll.func_77942_o()) {
                NBTTagCompound tag = scroll.func_77978_p();
                if (tag != null && tag.func_74764_b("aspects")) {
                    NBTTagCompound aspectTag = tag.func_74775_l("aspects");
                    AspectList scrollAspects = new AspectList();
                    for (String aspectKey : aspectTag.func_150296_c()) {
                        Aspect aspect = Aspect.getAspect(aspectKey);
                        if (aspect != null) {
                            scrollAspects.add(aspect, aspectTag.func_74762_e(aspectKey));
                        }
                    }
                    renderCenterAspects(scrollAspects);
                }
            }
        }
    }

    private void renderSidebarAspects(AspectList storedAspects) {
        Aspect[] aspects = storedAspects.getAspects();
    
        // Початкові координати для відображення аспектів
        int x = this.field_147003_i + 45; // Ліва частина екрана
        int y = this.field_147009_r + 32; // Верхня частина екрана
    
        for (int i = 0; i < aspects.length; i++) {
            if (aspects[i] != null) {
                try {
                    GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
                    GL11.glPushMatrix();
    
                    // Малюємо аспект
                    UtilsFX.drawTag(x, y, aspects[i], storedAspects.getAmount(aspects[i]), 0, field_73735_i, 771, 1.0F);
    
                    GL11.glPopMatrix();
                    GL11.glPopAttrib();
    
                    // Переміщення вниз
                    y += 16;
    
                    // Перехід до нового стовпця після 5 аспектів
                    if ((i + 1) % 5 == 0) {
                        x += 15; // Стовпець з аспектами (враховуючи ширину відступів)
                        y = this.field_147009_r + 32; // Скидаємо Y на початкову позицію
                    }
                } catch (Exception e) {
                }
            }
        }
    }
    

    private void renderCenterAspects(AspectList scrollAspects) {
        Aspect[] aspects = scrollAspects.getAspects();

        // Центр GUI
        int centerX = this.field_147003_i + 170;
        int centerY = this.field_147009_r + 75;
        int radius = 30; // Початковий радіус

        for (int i = 0; i < aspects.length; i++) {
            Aspect aspect = aspects[i];
            int amount = scrollAspects.getAmount(aspect);

            double angle = 2 * Math.PI * i / aspects.length;
            int x = centerX + (int) (radius * Math.cos(angle)) - 8;
            int y = centerY + (int) (radius * Math.sin(angle)) - 8;

            if (amount == 7) {
                // Не відображаємо аспект із кількістю 7
                continue;
            } else if (amount == 6 || amount == 5) {
                // Відображає unk.png для невідомих аспектів
                ResourceLocation texture = new ResourceLocation("thaumicforever", "textures/gui/unk.png");
                field_146297_k.func_110434_K().func_110577_a(texture);

                GL11.glPushMatrix();
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                UtilsFX.drawTexturedQuadF(x, y, 0, 0, 16, 16, field_73735_i);
                GL11.glDisable(GL11.GL_BLEND);
                GL11.glPopMatrix();
            } else if (amount < 5) {
                // Відображає відомі аспекти
                UtilsFX.drawTag(x, y, aspect, amount, 0, field_73735_i, 771, 1.0F);
            }

            // Збільшуємо радіус для кожного кроку
            radius += 5;
        }
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        try {
            super.func_73864_a(mouseX, mouseY, mouseButton);
        } catch (Exception e) {
        }

        // Координати кнопки лупи
        int lupaX = this.field_147003_i + 85;
        int lupaY = this.field_147009_r + 40;
        int lupaWidth = 16;
        int lupaHeight = 16;

        if (mouseX >= lupaX && mouseX <= lupaX + lupaWidth && mouseY >= lupaY && mouseY <= lupaY + lupaHeight) {
            if (mouseButton == 0) { // ЛКМ

                // Оновлюємо час останнього натискання
                lastClickedTime = System.currentTimeMillis();

                if (this.tileEntity instanceof DoubleTableTileEntity) {
                    BlockPos pos = ((DoubleTableTileEntity) this.tileEntity).func_174877_v();
                    ThaumicForever.network.sendToServer(new PacketClickLupa(pos));
                }
            }
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
}
