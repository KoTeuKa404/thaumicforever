package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DoubleTableBlock extends Block {
    public static final PropertyDirection FACING = BlockHorizontal.field_185512_D;

    public DoubleTableBlock() {
        super(Material.field_151575_d);
        func_149663_c(ThaumicForever.MODID + ".double_table");
        func_149711_c(2.5F);
        func_149752_b(12.5F);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a(FACING, EnumFacing.NORTH));
    }

    @Override
    public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer, EnumHand hand) {
        EnumFacing horizontalFacing = placer.func_174811_aO();
        BlockPos secondPartPos = pos.func_177972_a(horizontalFacing.func_176735_f()); // Позиція другої половини

        // Якщо немає місця для другої частини
        if (!worldIn.func_175623_d(secondPartPos) && !worldIn.func_180495_p(secondPartPos).func_185904_a().func_76222_j()) {
            // Розміщуємо стіл, але він одразу руйнується
            worldIn.func_175684_a(pos, this, 1); // Запланувати руйнування
            return this.func_176223_P().func_177226_a(FACING, horizontalFacing.func_176734_d());
        }

        // Розміщення невидимого блоку
        if (!worldIn.field_72995_K) {
            worldIn.func_180501_a(secondPartPos, ModBlocks.INVISIBLE_PART.func_176223_P(), 3);
        }

        return this.func_176223_P().func_177226_a(FACING, horizontalFacing.func_176734_d());
    }

    @Override
    public void func_180650_b(World worldIn, BlockPos pos, IBlockState state, java.util.Random rand) {
        // Якщо блок не має другого блоку, він сам руйнується
        EnumFacing facing = state.func_177229_b(FACING);
        BlockPos secondPartPos = pos.func_177972_a(facing.func_176735_f());

        if (!worldIn.func_180495_p(secondPartPos).func_177230_c().equals(ModBlocks.INVISIBLE_PART)) {
            worldIn.func_175698_g(pos);
            func_180635_a(worldIn, pos, new ItemStack(this)); // Випадає стіл
        }
    }

    @Override
    public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
        EnumFacing facing = state.func_177229_b(FACING);
        BlockPos secondPartPos = pos.func_177972_a(facing.func_176735_f()); // Позиція другої половини

        // Перевірка чи блок є основною частиною стола
        if (worldIn.func_180495_p(secondPartPos).func_177230_c().equals(ModBlocks.INVISIBLE_PART)) {
            worldIn.func_175698_g(secondPartPos); // Знищуємо невидимий блок
        } else {
            // Перевірка на невидимий блок, що залишився
            for (EnumFacing direction : EnumFacing.field_176754_o) {
                BlockPos possibleMainBlockPos = pos.func_177972_a(direction);
                IBlockState possibleMainBlockState = worldIn.func_180495_p(possibleMainBlockPos);

                if (possibleMainBlockState.func_177230_c() instanceof DoubleTableBlock) {
                    worldIn.func_175698_g(possibleMainBlockPos); // Видаляємо основний блок
                    break;
                }
            }
        }

        // Спавнимо предмет стола
        // spawnAsEntity(worldIn, pos, new ItemStack(ModBlocks.DOUBLE_TABLE));
        super.func_180663_b(worldIn, pos, state); // Викликаємо базовий метод
    }

    
    @Override
    public EnumBlockRenderType func_149645_b(IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }

    @Override
    public IBlockState func_176203_a(int meta) {
        return this.func_176223_P().func_177226_a(FACING, EnumFacing.func_176731_b(meta & 3));
    }

    @Override
    public int func_176201_c(IBlockState state) {
        return state.func_177229_b(FACING).func_176736_b();
    }

    @Override
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer(this, FACING);
    }

    @Override
    public boolean func_149662_c(IBlockState state) {
        return false;
    }

    @Override
    public boolean func_149686_d(IBlockState state) {
        return false;
    }

    @Override
    public IBlockState func_185499_a(IBlockState state, Rotation rot) {
        return state.func_177226_a(FACING, rot.func_185831_a(state.func_177229_b(FACING)));
    }

    @Override
    public IBlockState func_185471_a(IBlockState state, Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a(state.func_177229_b(FACING)));
    }
    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }
    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new DoubleTableTileEntity();
    }

    @Override
    public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (!world.field_72995_K) {
            TileEntity tileEntity = world.func_175625_s(pos);
            if (tileEntity instanceof DoubleTableTileEntity) {
                player.openGui(ThaumicForever.instance, ModGuiHandler.DOUBLE_TABLE_GUI, world, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
            }
        }
        return true;
    }
    
}
