package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.registries.IForgeRegistry;

@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ModBlocks {

    public static final Block DECONSTRUCTION_TABLE = new DeconstructionTableBlock()
        .func_149663_c(ThaumicForever.MODID + ".deconstruction_table")
        .setRegistryName(ThaumicForever.MODID, "deconstruction_table").func_149647_a(ThaumicForever.CREATIVE_TAB);

    public static final Block GREATWOOD_TABLE = new GreatwoodTableBlock()
        .func_149663_c(ThaumicForever.MODID + ".greatwood_table")
        .setRegistryName(ThaumicForever.MODID, "greatwood_table").func_149647_a(ThaumicForever.CREATIVE_TAB);

    public static final Block DOUBLE_TABLE = new DoubleTableBlock()
        .func_149663_c(ThaumicForever.MODID + ".double_table")
        .setRegistryName(ThaumicForever.MODID, "double_table").func_149647_a(ThaumicForever.CREATIVE_TAB);

    public static final Block LEAD_BLOCK = new BlockBase(Material.field_151573_f, "lead_block")
        .func_149647_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Block SILVER_BLOCK = new BlockBase(Material.field_151573_f, "silver_block")
        .func_149647_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Block TIN_BLOCK = new BlockBase(Material.field_151573_f, "tin_block")
        .func_149647_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Block COPPER_BLOCK = new BlockBase(Material.field_151573_f, "copper_block")
        .func_149647_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Block OBSIDIAN_TOTEM = new BlockBase(Material.field_151573_f, "obsidian_totem")
        .func_149647_a(ThaumicForever.CREATIVE_TAB);
    

    public static final Block TIME_STOP = new BlockTimeStop().func_149647_a(ThaumicForever.CREATIVE_TAB);    
    public static final Block ABANDONED_CHEST = new BlockAbandonedChest().func_149647_a(ThaumicForever.CREATIVE_TAB);
    
    public static final Block ANTI_FLIGHT_STONE = new BlockAntiFlightStone().func_149647_a(ThaumicForever.CREATIVE_TAB);
    public static final Block Duplicator = new BlockMatteryDuplicator().func_149647_a(ThaumicForever.CREATIVE_TAB);
    public static final Block COMPRESSOR = new BlockCompressor().func_149647_a(ThaumicForever.CREATIVE_TAB);

    public static final Block RED_ROSE = new BlockRedRose();
    public static final Block BLUE_ROSE = new BlockBlueRose();
    public static final Block BlockRepurposer = new BlockRepurposer();
    public static final Block BlockTimeStone = new BlockTimeStone();
    public static final Block BlockTimeSlow = new BlockTimeSlow();
    public static final Block INVISIBLE_BLOCK = new InvisibleBlock();
    public static final Block BlockMechanismAmplifier = new BlockMechanismAmplifier();
    public static final Block INVISIBLE_PART = new InvisiblePartBlock();
    
    
    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        IForgeRegistry<Block> registry = event.getRegistry();
        registry.registerAll(
            DECONSTRUCTION_TABLE,
            GREATWOOD_TABLE,
            DOUBLE_TABLE,
            LEAD_BLOCK,
            SILVER_BLOCK,
            TIN_BLOCK,
            COPPER_BLOCK,
            OBSIDIAN_TOTEM,
            ABANDONED_CHEST,
            ANTI_FLIGHT_STONE,
            TIME_STOP,
            Duplicator,
            COMPRESSOR,
            RED_ROSE,
            BLUE_ROSE,
            BlockRepurposer,
            BlockTimeStone,
            BlockTimeSlow,
            BlockMechanismAmplifier,
            INVISIBLE_PART


        );
        
    }

    @SubscribeEvent
    public static void registerItemBlocks(RegistryEvent.Register<Item> event) {
        IForgeRegistry<Item> registry = event.getRegistry();
        registry.registerAll(
            new ItemBlock(DECONSTRUCTION_TABLE).setRegistryName(DECONSTRUCTION_TABLE.getRegistryName()),
            new ItemBlock(GREATWOOD_TABLE).setRegistryName(GREATWOOD_TABLE.getRegistryName()),
            new ItemBlock(DOUBLE_TABLE).setRegistryName(DOUBLE_TABLE.getRegistryName()),
            new ItemBlock(LEAD_BLOCK).setRegistryName(LEAD_BLOCK.getRegistryName()),
            new ItemBlock(SILVER_BLOCK).setRegistryName(SILVER_BLOCK.getRegistryName()),
            new ItemBlock(TIN_BLOCK).setRegistryName(TIN_BLOCK.getRegistryName()),
            new ItemBlock(COPPER_BLOCK).setRegistryName(COPPER_BLOCK.getRegistryName()),
            new ItemBlock(OBSIDIAN_TOTEM).setRegistryName(OBSIDIAN_TOTEM.getRegistryName()),
            new ItemBlock(ABANDONED_CHEST).setRegistryName(ABANDONED_CHEST.getRegistryName()),
            new ItemBlock(ANTI_FLIGHT_STONE).setRegistryName(ANTI_FLIGHT_STONE.getRegistryName()),
            new ItemBlock(TIME_STOP).setRegistryName(TIME_STOP.getRegistryName()),
            new ItemBlock(Duplicator).setRegistryName(Duplicator.getRegistryName()),
            new ItemBlock(RED_ROSE).setRegistryName(RED_ROSE.getRegistryName()),
            new ItemBlock(BLUE_ROSE).setRegistryName(BLUE_ROSE.getRegistryName()),
            new ItemBlock(COMPRESSOR).setRegistryName(COMPRESSOR.getRegistryName()),
            new ItemBlock(BlockRepurposer).setRegistryName(BlockRepurposer.getRegistryName()),
            new ItemBlock(BlockTimeStone).setRegistryName(BlockTimeStone.getRegistryName()),
            new ItemBlock(BlockMechanismAmplifier).setRegistryName(BlockMechanismAmplifier.getRegistryName()),
            new ItemBlock(INVISIBLE_PART).setRegistryName(INVISIBLE_PART.getRegistryName()),
            new ItemBlock(BlockTimeSlow).setRegistryName(BlockTimeSlow.getRegistryName())
       
            );
            
            
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(DECONSTRUCTION_TABLE), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(GREATWOOD_TABLE), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(DOUBLE_TABLE), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(LEAD_BLOCK), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(SILVER_BLOCK), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(TIN_BLOCK), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(COPPER_BLOCK), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(OBSIDIAN_TOTEM), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(ABANDONED_CHEST), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(ANTI_FLIGHT_STONE), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(TIME_STOP), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(Duplicator), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(COMPRESSOR), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(RED_ROSE), 0, "thaumicforever:red_rose");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(BLUE_ROSE), 0, "thaumicforever:blue_rose");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(BlockRepurposer), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(BlockTimeStone), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(BlockTimeSlow), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(BlockMechanismAmplifier), 0, "inventory");
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(INVISIBLE_PART), 0, "inventory");

         
    }
}
