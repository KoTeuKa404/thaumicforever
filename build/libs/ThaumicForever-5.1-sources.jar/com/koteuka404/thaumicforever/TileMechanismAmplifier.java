package com.koteuka404.thaumicforever;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import thaumcraft.common.lib.utils.BlockStateUtils;
import thaumcraft.common.tiles.TileThaumcraft;
import thaumcraft.common.tiles.devices.TileBellows;

public class TileMechanismAmplifier extends TileThaumcraft implements ITickable {

    private int delay = 0;

    @Override
    public void func_73660_a() {
        // Виконуємо лише на сервері
        if (this.func_145831_w().field_72995_K) return;

        delay++;
        if (delay >= 20) { // Раз на секунду
            delay = 0;

            // Логування
            // System.out.println("[MechanismAmplifier] Updating at position: " + this.getPos());

            // Підраховуємо boost
            int totalBoost = calculateTotalBoost();
            // System.out.println("[MechanismAmplifier] Calculated total boost: " + totalBoost);

            // Застосовуємо boost до механізму
            applyBoostToMechanism(totalBoost);
        }
    }

    private int calculateTotalBoost() {
        int totalBoost = 0;

        for (EnumFacing direction : EnumFacing.values()) {
            BlockPos neighborPos = this.func_174877_v().func_177972_a(direction);
            TileEntity neighborTile = func_145831_w().func_175625_s(neighborPos);

            if (neighborTile instanceof TileMechanismAmplifier) {
                totalBoost += 2; // Інший Mechanism Amplifier
            } else if (neighborTile instanceof TileEntityFurnace) {
                int bellowsBoost = countConnectedBellows(neighborPos);
                totalBoost += bellowsBoost;
            }
        }

        return totalBoost;
    }

    private int countConnectedBellows(BlockPos pos) {
        int count = 0;

        for (EnumFacing direction : EnumFacing.values()) {
            BlockPos bellowPos = pos.func_177972_a(direction);
            TileEntity tile = func_145831_w().func_175625_s(bellowPos);

            if (tile instanceof TileBellows) {
                boolean isEnabled = BlockStateUtils.isEnabled(tile.func_145832_p());
                boolean isCorrectFacing = BlockStateUtils.getFacing(tile.func_145832_p()) == direction.func_176734_d();

                if (isEnabled && isCorrectFacing) {
                    count++;
                }
            }
        }

        return count;
    }

    private void applyBoostToMechanism(int boost) {
        EnumFacing facing = BlockStateUtils.getFacing(this.func_145832_p());
        BlockPos targetPos = this.func_174877_v().func_177972_a(facing);
        TileEntity targetTile = func_145831_w().func_175625_s(targetPos);

        if (targetTile instanceof TileEntityFurnace) {
            TileEntityFurnace furnace = (TileEntityFurnace) targetTile;

            int cookTime = furnace.func_174887_a_(2); // Отримуємо поточний cookTime
            if (cookTime > 0 && cookTime < 199) {
                furnace.func_174885_b(2, cookTime + boost);
            }
        }
    }
}
