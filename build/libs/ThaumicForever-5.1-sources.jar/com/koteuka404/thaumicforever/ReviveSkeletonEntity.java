package com.koteuka404.thaumicforever;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class ReviveSkeletonEntity extends EntityMob {

    private int attackCooldown = 0; // Змінна для контролю кулдауну атак

    public ReviveSkeletonEntity(World world) {
        super(world);
        this.func_70105_a(0.6F, 1.8F);

        // Налаштування атрибутів моба
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(11.0D);
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.18D);
        this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(2.0D);
        this.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(32.0D);
        this.func_70606_j(this.func_110138_aP());

        // Встановлюємо скрол у руці моба з шансом 50%
        if (this.field_70146_Z.nextInt(100) < 5) {
            this.func_184201_a(EntityEquipmentSlot.MAINHAND, new ItemStack(ModItems.SCROLL_P, 1, this.field_70146_Z.nextInt(4))); // Випадкові метадані
        }
    }

    @Override
    protected void func_184651_r() {
        // Додавання задач AI
        this.field_70714_bg.func_75776_a(0, new EntityAISwimming(this));
        this.field_70714_bg.func_75776_a(1, new EntityAIAttackMelee(this, 1.2D, false)); // Атака в ближньому бою
        this.field_70714_bg.func_75776_a(2, new EntityAIWanderAvoidWater(this, 0.8D)); // Блукання
        this.field_70714_bg.func_75776_a(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F)); // Спостереження за гравцем
        this.field_70714_bg.func_75776_a(4, new EntityAILookIdle(this)); // Бездіяльність

        // Цілі атаки
        this.field_70715_bh.func_75776_a(1, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true));
        this.field_70715_bh.func_75776_a(2, new EntityAIHurtByTarget(this, true)); // Реакція на атаку
    }

    @Override
    public void func_70636_d() {
        super.func_70636_d();

        // Зменшуємо кулдаун атак
        if (attackCooldown > 0) {
            attackCooldown--;
        }

        // Приєднання до групової атаки
        if (this.func_70638_az() == null) {
            joinGroupAttack();
        }

        EntityPlayer player = this.field_70170_p.func_72890_a(this, 15.0D);
        if (player != null) {
            double distance = this.func_70032_d(player);

            // Збільшуємо швидкість при наближенні до гравця
            if (distance < 10.0D) {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.18D);
            } else {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.18D);
            }

            // Виконуємо атаку
            if (distance <= 2.0D && attackCooldown == 0) {
                performAttack(player);
            }
        }
    }

    private void performAttack(EntityPlayer player) {
        // Завдаємо шкоди гравцеві
        float damage = (float) this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
        player.func_70097_a(DamageSource.func_76358_a(this), damage);

        // Встановлюємо кулдаун для атак
        attackCooldown = 20; // 1 секунда між атаками
        System.out.println("Attacked player with " + damage + " damage!");
    }

    private void callForHelp() {
        // Виклик союзників на допомогу
        List<ReviveSkeletonEntity> nearbySkeletons = this.field_70170_p.func_72872_a(ReviveSkeletonEntity.class, this.func_174813_aQ().func_186662_g(10.0D));
        for (ReviveSkeletonEntity skeleton : nearbySkeletons) {
            if (skeleton != this && skeleton.func_70638_az() == null) {
                skeleton.func_70624_b(this.func_70638_az());
                System.out.println("Calling for help from nearby skeleton!");
            }
        }
    }

    private void synchronizeAttackTarget(EntityLivingBase target) {
        // Узгодження цілі атаки з іншими мобами
        List<ReviveSkeletonEntity> nearbySkeletons = this.field_70170_p.func_72872_a(ReviveSkeletonEntity.class, this.func_174813_aQ().func_186662_g(10.0D));
        for (ReviveSkeletonEntity skeleton : nearbySkeletons) {
            if (skeleton != this && skeleton.func_70638_az() == null) {
                skeleton.func_70624_b(target);
                System.out.println("Synchronizing attack target!");
            }
        }
    }

    @Override
    protected void func_184610_a(boolean wasRecentlyHit, int lootingModifier, DamageSource source) {
        // Перевіряємо, чи є предмет у руці
        ItemStack heldItem = this.func_184582_a(EntityEquipmentSlot.MAINHAND);
        if (!heldItem.func_190926_b()) {
            this.func_70099_a(heldItem, 0.0F); // Додаємо предмет до дропу
        }

        // Гарантоване випадіння 3 OldBone
        for (int i = 0; i < 3; i++) {
            this.func_70099_a(new ItemStack(ModItems.OldBone), 0.0F);
        }

        // Додатковий шанс 10% для 1 OldBone
        if (this.field_70170_p.field_73012_v.nextInt(100) < 10) { // 10% шанс
            this.func_70099_a(new ItemStack(ModItems.OldBone), 0.0F);
        }

        // Виклик базового методу для інших предметів
        super.func_184610_a(wasRecentlyHit, lootingModifier, source);
    }

    private void joinGroupAttack() {
        // Приєднання до атаки інших мобів
        List<ReviveSkeletonEntity> nearbySkeletons = this.field_70170_p.func_72872_a(ReviveSkeletonEntity.class, this.func_174813_aQ().func_186662_g(10.0D));
        for (ReviveSkeletonEntity skeleton : nearbySkeletons) {
            if (skeleton != this && skeleton.func_70638_az() != null) {
                this.func_70624_b(skeleton.func_70638_az());
                break;
            }
        }
    }

    @Override
    public boolean func_70097_a(DamageSource source, float amount) {
        boolean result = super.func_70097_a(source, amount);

        // Виклик союзників на допомогу
        if (source.func_76346_g() instanceof EntityLivingBase) {
            this.func_70624_b((EntityLivingBase) source.func_76346_g());
            callForHelp();
        }

        return result;
    }

    @Override
    public EnumCreatureAttribute func_70668_bt() {
        return EnumCreatureAttribute.UNDEAD; // Позначає моба як нежить
    }
}
