package com.koteuka404.thaumicforever;

import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class TileEntityAntiFlightStone extends TileEntity implements ITickable {

    private static final int RADIUS_BLOCKS = 48;

    private AxisAlignedBB detectionBox = null;

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K) {
            if (detectionBox == null) {
                detectionBox = new AxisAlignedBB(
                    field_174879_c.func_177982_a(-RADIUS_BLOCKS, -RADIUS_BLOCKS, -RADIUS_BLOCKS), 
                    field_174879_c.func_177982_a(RADIUS_BLOCKS, RADIUS_BLOCKS, RADIUS_BLOCKS)
                );
            }

            List<EntityPlayer> players = field_145850_b.func_72872_a(EntityPlayer.class, detectionBox);

            for (EntityPlayer player : players) {
                if (!player.func_184812_l_() && player.field_71075_bZ.field_75101_c) {
                    player.field_71075_bZ.field_75101_c = false;
                    player.field_71075_bZ.field_75100_b = false;
                    player.func_71016_p();
                }
            }

            boolean hasNearbyAntiFlightBlocks = hasNearbyAntiFlightStones();
            if (!hasNearbyAntiFlightBlocks) {
                for (EntityPlayer player : players) {
                    if (!player.func_184812_l_() && !player.field_71075_bZ.field_75101_c) {
                        player.field_71075_bZ.field_75101_c = true;
                        player.func_71016_p();
                    }
                }
            }
        }
    }

    private boolean hasNearbyAntiFlightStones() {
        for (BlockPos checkPos : BlockPos.func_177975_b(
                field_174879_c.func_177982_a(-RADIUS_BLOCKS, -RADIUS_BLOCKS, -RADIUS_BLOCKS),
                field_174879_c.func_177982_a(RADIUS_BLOCKS, RADIUS_BLOCKS, RADIUS_BLOCKS))) {

            TileEntity te = field_145850_b.func_175625_s(checkPos);
            if (te instanceof TileEntityAntiFlightStone) {
                return true; 
            }
        }
        return false;
    }
}
