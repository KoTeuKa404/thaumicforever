package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemTimeFreeze extends Item {

    public ItemTimeFreeze() {
        func_77655_b("time_freeze_item");
        setRegistryName("time_freeze_item");
        func_77625_d(8);
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K) {
            EntityTimeFreezeProjectile projectile = new EntityTimeFreezeProjectile(world, player);
            projectile.func_184538_a(player, player.field_70125_A, player.field_70177_z, 0.0F, 1.5F, 1.0F);
            
            world.func_72838_d(projectile);
            player.func_184185_a(SoundEvents.field_187797_fA, 1.0F, 1.0F);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }
}
