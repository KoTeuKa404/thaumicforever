package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;

public class ItemCrimsonBook extends Item {
    public static final int CRIMSON_BOOK_GUI = 3;

    public ItemCrimsonBook() {
        this.func_77625_d(1); // Only one book in a stack
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K) {
        } else {
            world.func_184134_a(player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187713_n , SoundCategory.PLAYERS, 1.0f, 1.0f, false);
        }
        player.openGui(ThaumicForever.instance, ModGuiHandler.CRIMSON_BOOK_GUI, world, 0, 0, 0);
        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }

    

}

