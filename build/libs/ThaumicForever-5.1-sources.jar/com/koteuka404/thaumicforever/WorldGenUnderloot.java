package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenUnderloot implements IWorldGenerator {

    public static final ResourceLocation UNDERLOOT_LOOT_TABLE = new ResourceLocation("thaumicforever", "chests/dan");

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.field_73011_w.getDimension() == 0) { // Генерація тільки в Overworld
            if (random.nextInt(100) == 0) {  // Підвищена частота для тестування
                int x = chunkX * 16 + random.nextInt(16);
                int z = chunkZ * 16 + random.nextInt(16);
                int y = 10 + random.nextInt(21); // Випадкова висота від 10 до 40
                BlockPos pos = new BlockPos(x, y, z);

                if (isWithinHeightRange(pos.func_177956_o()) && isUnderground(world, pos)) {
                    generateStructure(world, pos);
                }
            }
        }
    }

    private void generateStructure(World world, BlockPos pos) {
        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = templateManager.func_186237_a(world.func_73046_m(), new ResourceLocation("thaumicforever", "underloot"));

        if (template != null) {
            template.func_186253_b(world, pos, new PlacementSettings().func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE));
            generateLootInChest(world, pos);
        } else {
        }
    }

    private void generateLootInChest(World world, BlockPos pos) {
        for (int x = -5; x < 5; x++) {
            for (int y = -5; y < 5; y++) {
                for (int z = -5; z < 5; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    if (world.func_180495_p(checkPos).func_177230_c() == Blocks.field_150447_bR) {
                        TileEntity tileEntity = world.func_175625_s(checkPos);
                        if (tileEntity instanceof TileEntityLockableLoot) {
                            ((TileEntityLockableLoot) tileEntity).func_189404_a(UNDERLOOT_LOOT_TABLE, world.field_73012_v.nextLong());
                        }
                    }
                }
            }
        }
    }

    private boolean isWithinHeightRange(int y) {
        return y >= 10 && y <= 40;
    }

    private boolean isUnderground(World world, BlockPos pos) {
        int requiredSolidBlocks = 20; // Мінімальна кількість суцільних блоків над структурою

        for (int y = pos.func_177956_o() + 1; y < pos.func_177956_o() + requiredSolidBlocks; y++) {
            BlockPos checkPos = new BlockPos(pos.func_177958_n(), y, pos.func_177952_p());

            if (world.func_175623_d(checkPos) || !world.func_180495_p(checkPos).func_185914_p()) {
                return false;
            }
        }
        return true; 
    }

    public static void registerLootTables() {
        if (!LootTableList.func_186374_a().contains(UNDERLOOT_LOOT_TABLE)) {
            LootTableList.func_186375_a(UNDERLOOT_LOOT_TABLE);
        }
    }
}
