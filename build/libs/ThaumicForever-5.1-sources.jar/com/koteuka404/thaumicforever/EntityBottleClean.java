package com.koteuka404.thaumicforever;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

// EntityBottleClean.java

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import thaumcraft.api.blocks.BlocksTC;

public class EntityBottleClean extends EntityThrowable {

    public EntityBottleClean(World worldIn) {
        super(worldIn);
    }

    public EntityBottleClean(World worldIn, EntityLivingBase throwerIn) {
        super(worldIn, throwerIn);
    }

    @Override
    protected void func_70184_a(RayTraceResult result) {
        if (!this.field_70170_p.field_72995_K) {
            BlockPos hitPos = result.func_178782_a();
            if (hitPos == null) {
                hitPos = new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            }

            // Генерація 3 блоків води в радіусі 3x3
            Set<BlockPos> potentialPositions = new HashSet<>();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos newPos = hitPos.func_177982_a(dx, 0, dz);
                    if (field_70170_p.func_175623_d(newPos)) {
                        potentialPositions.add(newPos);
                    }
                }
            }

            Random random = new Random();
            int waterCount = 0;
            while (waterCount < 3 && !potentialPositions.isEmpty()) {
                BlockPos selectedPos = potentialPositions.stream()
                        .skip(random.nextInt(potentialPositions.size()))
                        .findFirst().orElse(null);
                if (selectedPos != null) {
                    field_70170_p.func_175656_a(selectedPos, BlocksTC.purifyingFluid.func_176223_P());
                    potentialPositions.remove(selectedPos);
                    waterCount++;
                }
            }

            this.func_70106_y();
        }
    }
}
