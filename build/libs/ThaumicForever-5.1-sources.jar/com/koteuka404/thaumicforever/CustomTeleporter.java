package com.koteuka404.thaumicforever;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;

public class CustomTeleporter implements ITeleporter {
    private final BlockPos targetPosition;

    public CustomTeleporter(BlockPos targetPosition) {
        this.targetPosition = targetPosition;
    }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        entity.func_70634_a(targetPosition.func_177958_n() + 0.5, targetPosition.func_177956_o() + 1, targetPosition.func_177952_p() + 0.5);
    }
}
