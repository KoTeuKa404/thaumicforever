package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockBlueRose extends BlockBush {
    public BlockBlueRose() {
        super(Material.field_151585_k);
        setRegistryName("blue_rose");
        func_149663_c("blue_rose");
    }

    @Override
    protected boolean func_185514_i(IBlockState state) {
        // Дозволяємо рости тільки на траві, ґрунті або ріллі
        return state.func_177230_c() == Blocks.field_150349_c
                || state.func_177230_c() == Blocks.field_150346_d
                || state.func_177230_c() == Blocks.field_150458_ak;
    }

    @Override
    public boolean func_176196_c(World worldIn, BlockPos pos) {
        // Викликаємо метод для перевірки блоку під квіткою
        IBlockState soil = worldIn.func_180495_p(pos.func_177977_b());
        return this.func_185514_i(soil);
    }

    @Override
    public void func_189540_a(IBlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos) {
        // Видаляємо квітку, якщо блок під нею більше не підтримує її
        if (!func_176196_c(worldIn, pos)) {
            worldIn.func_175655_b(pos, true);
        }
    }
}
