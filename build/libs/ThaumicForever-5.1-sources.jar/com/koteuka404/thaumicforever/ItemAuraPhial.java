package com.koteuka404.thaumicforever;

import net.minecraft.item.Item;

public class ItemAuraPhial extends Item {

    public ItemAuraPhial() {
        func_77655_b("auraphial");
        setRegistryName("auraphial");
        func_77637_a(ThaumicForever.CREATIVE_TAB);
    }

}
