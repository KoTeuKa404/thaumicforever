package com.koteuka404.thaumicforever;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;

public class GuiRepurposer extends GuiContainer {

    private static final ResourceLocation TEXTURES = new ResourceLocation("thaumicforever", "textures/gui/gui_arcanebore.png");
    private final TileEntityRepurposer tileEntity;

    public GuiRepurposer(InventoryPlayer player, TileEntityRepurposer tileEntity) {
        super(new ContainerRepurposer(player, tileEntity));
        this.tileEntity = tileEntity;
        this.field_146999_f = 176;
        this.field_147000_g = 166;
    }


    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        Minecraft.func_71410_x().func_110434_K().func_110577_a(TEXTURES);
        this.func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
    }
    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
}
