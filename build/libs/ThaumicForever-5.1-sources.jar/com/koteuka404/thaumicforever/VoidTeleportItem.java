package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class VoidTeleportItem extends Item {

    public VoidTeleportItem() {
        this.func_77625_d(1);
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K && player instanceof EntityPlayerMP) {
            EntityPlayerMP playerMP = (EntityPlayerMP) player;

            // Якщо гравець не в VOID_DIMENSION, телепортуємо в нього
            if (playerMP.field_71093_bK != ModDimensions.VOID_DIMENSION.func_186068_a()) {
                WorldServer voidWorld = playerMP.func_184102_h().func_71218_a(ModDimensions.VOID_DIMENSION.func_186068_a());

                if (voidWorld != null) {
                    // Знайти або створити структуру для гравця
                    BlockPos spawnPosition = PlayerStructureManager.getOrCreateStructureForPlayer(playerMP, voidWorld);
                    playerMP.changeDimension(ModDimensions.VOID_DIMENSION.func_186068_a(), new CustomTeleporter(spawnPosition));
                } else {
                    System.err.println("Помилка: вимір VOID_DIMENSION не знайдено!");
                }
            } 
            // Якщо гравець вже у VOID_DIMENSION, повертаємо в OVERWORLD
            else {
                WorldServer overworld = playerMP.func_184102_h().func_71218_a(0); // ID 0 для Overworld

                if (overworld != null) {
                    BlockPos overworldSpawn = overworld.func_175694_M();
                    playerMP.changeDimension(0, new CustomTeleporter(overworldSpawn));
                } else {
                    System.err.println("Помилка: Overworld не знайдено!");
                }
            }
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }
}
