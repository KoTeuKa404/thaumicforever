package com.koteuka404.thaumicforever;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.items.ItemsTC;

public class DeconstructionTableTileEntity extends TileEntity implements ITickable, IInventory {

    private NonNullList<ItemStack> inventory = NonNullList.func_191197_a(2, ItemStack.field_190927_a); 
    private int burnTime = 0;
    private Random random = new Random();
    private boolean oldResearchLoaded;

    private Map<Item, ItemStack[]> recipes = new HashMap<>();
    private Map<Item, Float> chances = new HashMap<>(); 

    public DeconstructionTableTileEntity() {
        this.oldResearchLoaded = net.minecraftforge.fml.common.Loader.isModLoaded("oldresearch");

        recipes.put(Item.func_150898_a(net.minecraft.init.Blocks.field_150462_ai), 
            new ItemStack[] { new ItemStack(Item.field_150901_e.func_82594_a(new ResourceLocation("thaumicbases", "knowledge_shard"))) });
        chances.put(Item.func_150898_a(net.minecraft.init.Blocks.field_150462_ai), 0.35f);

        recipes.put(net.minecraft.init.Items.field_151079_bi, 
            new ItemStack[] { new ItemStack(ItemsTC.curio, 1, 6) });
        chances.put(net.minecraft.init.Items.field_151079_bi, 0.45f);

        recipes.put(net.minecraft.init.Items.field_151073_bk, 
            new ItemStack[] { new ItemStack(ItemsTC.curio, 1, 6) });
        chances.put(net.minecraft.init.Items.field_151073_bk, 0.95f);

        recipes.put(Item.field_150901_e.func_82594_a(new ResourceLocation("planarartifice", "condensed_crystal_cluster")),
            new ItemStack[] { 
                new ItemStack(Item.field_150901_e.func_82594_a(new ResourceLocation("planarartifice", "fundamental_curiosity"))), 
                new ItemStack(Item.field_150901_e.func_82594_a(new ResourceLocation("planarartifice", "dimensional_curiosity"))) 
            });
        chances.put(Item.field_150901_e.func_82594_a(new ResourceLocation("planarartifice", "condensed_crystal_cluster")), 0.50f);

        recipes.put(net.minecraft.init.Items.field_151122_aG,
            new ItemStack[] { new ItemStack(ItemsTC.curio, 1, random.nextInt(6)) });
        if (oldResearchLoaded) {
            chances.put(net.minecraft.init.Items.field_151122_aG, 0.85f); 
        } else {
            chances.put(net.minecraft.init.Items.field_151122_aG, 0.60f);
        }
    }

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K && !inventory.get(0).func_190926_b()) {
            burnTime++;

            if (burnTime >= 80) {
                ItemStack inputStack = inventory.get(0);
                ItemStack[] results = getResults(inputStack);

                if (results != null && results.length > 0) {
                    float chance = chances.getOrDefault(inputStack.func_77973_b(), 1.0f);

                    if (random.nextFloat() <= chance) {
                        ItemStack result = results[random.nextInt(results.length)];

                        if (inputStack.func_77973_b() == net.minecraft.init.Items.field_151122_aG && oldResearchLoaded) {
                            result = new ItemStack(ItemsTC.curio, 1, 7);
                        } else if (inputStack.func_77973_b() == net.minecraft.init.Items.field_151122_aG) {
                            result = new ItemStack(ItemsTC.curio, 1, random.nextInt(6));
                        }

                        if ((inputStack.func_77973_b() == net.minecraft.init.Items.field_151079_bi ||
                            inputStack.func_77973_b() == net.minecraft.init.Items.field_151073_bk ||
                            inputStack.func_77973_b() == Item.func_150898_a(net.minecraft.init.Blocks.field_150462_ai) ||
                            (inputStack.func_77973_b() == net.minecraft.init.Items.field_151122_aG && oldResearchLoaded)) &&
                            !inventory.get(1).func_190926_b() &&
                            inventory.get(1).func_77973_b() == result.func_77973_b() &&
                            inventory.get(1).func_190916_E() < inventory.get(1).func_77976_d()) {
                            inventory.get(1).func_190917_f(1);
                        } else if (inventory.get(1).func_190926_b()) {
                            inventory.set(1, result.func_77946_l());
                        } else {
                            burnTime = 0;
                            return;
                        }

                        inputStack.func_190918_g(1); 
                        burnTime = 0;
                        func_70296_d();
                    } else {
                        inputStack.func_190918_g(1);
                        burnTime = 0;
                        func_70296_d();
                    }
                } else {
                    burnTime = 0;
                }
            }
        }
    }




    private ItemStack[] getResults(ItemStack input) {
        ItemStack[] result = recipes.get(input.func_77973_b());
        if (result != null) {
            return result;
        }

        if (input.func_77973_b() == ItemsTC.curio) {
            int meta = random.nextInt(6);
            return new ItemStack[] { new ItemStack(ItemsTC.curio, 1, meta) };
        }
        return null;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound) {
        super.func_145839_a(compound);
        this.inventory = NonNullList.func_191197_a(this.func_70302_i_(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, this.inventory);
        this.burnTime = compound.func_74762_e("BurnTime");
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound) {
        super.func_189515_b(compound);
        ItemStackHelper.func_191282_a(compound, this.inventory);
        compound.func_74768_a("BurnTime", this.burnTime);
        return compound;
    }

    @Override
    public int func_70302_i_() {
        return 2;
    }

    @Override
    public boolean func_191420_l() {
        for (ItemStack itemstack : this.inventory) {
            if (!itemstack.func_190926_b()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack func_70301_a(int index) {
        return this.inventory.get(index);
    }

    @Override
    public ItemStack func_70298_a(int index, int count) {
        return ItemStackHelper.func_188382_a(this.inventory, index, count);
    }

    @Override
    public ItemStack func_70304_b(int index) {
        return ItemStackHelper.func_188383_a(this.inventory, index);
    }

    @Override
    public void func_70299_a(int index, ItemStack stack) {
        this.inventory.set(index, stack);
        if (stack.func_190916_E() > this.func_70297_j_()) {
            stack.func_190920_e(this.func_70297_j_());
        }
        this.func_70296_d();
    }

    @Override
    public int func_70297_j_() {
        return 64;
    }

    @Override
    public void func_174889_b(EntityPlayer player) {}

    @Override
    public void func_174886_c(EntityPlayer player) {}

    @Override
    public boolean func_94041_b(int index, ItemStack stack) {
        return index == 0; 
    }

    @Override
    public int func_174887_a_(int id) {
        return 0;
    }

    @Override
    public void func_174885_b(int id, int value) {}

    @Override
    public int func_174890_g() {
        return 0;
    }

    @Override
    public void func_174888_l() {
        this.inventory.clear();
    }

    @Override
    public String func_70005_c_() {
        return "container.deconstruction_table";
    }

    @Override
    public boolean func_145818_k_() {
        return false;
    }

    @Override
    public net.minecraft.util.text.ITextComponent func_145748_c_() {
        return new net.minecraft.util.text.TextComponentString(this.func_70005_c_());
    }

    @Override
    public boolean func_70300_a(EntityPlayer player) {
        return this.field_145850_b.func_175625_s(this.field_174879_c) == this &&
               player.func_70092_e((double)this.field_174879_c.func_177958_n() + 0.5D, (double)this.field_174879_c.func_177956_o() + 0.5D, (double)this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
    }
}
