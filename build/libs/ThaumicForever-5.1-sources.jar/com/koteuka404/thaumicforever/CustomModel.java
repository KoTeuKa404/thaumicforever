package com.koteuka404.thaumicforever;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class CustomModel extends ModelBase {
    public final ModelRenderer bb_main;
    public final ModelRenderer head;
    public final ModelRenderer upperBody;
    public final ModelRenderer leftArm;
    public final ModelRenderer rightArm;
    public final ModelRenderer leftLeg;
    public final ModelRenderer rightLeg;
    public final ModelRenderer leftBodyPiece;
    public final ModelRenderer rightBodyPiece;
    public final ModelRenderer lowerBody;

    public CustomModel() {
        field_78090_t = 64;
        field_78089_u = 64;

        // Головний контейнер
        bb_main = new ModelRenderer(this);
        bb_main.func_78793_a(0.0F, 24.0F, 0.0F);

        // Голова
        head = new ModelRenderer(this);
        head.func_78793_a(0.0F, -30.0F, 0.0F);
        head.field_78804_l.add(new ModelBox(head, 0, 0, -1.0F, 0.0F, -1.0F, 2, 7, 2, 0.0F, false));
        bb_main.func_78792_a(head);

        // Верхня частина тіла
        upperBody = new ModelRenderer(this);
        upperBody.func_78793_a(0.0F, -24.0F, 0.0F);
        upperBody.field_78804_l.add(new ModelBox(upperBody, 0, 26, -6.0F, 0.0F, -1.5F, 12, 3, 3, 0.0F, false));
        bb_main.func_78792_a(upperBody);

        // Ліва рука
        leftArm = new ModelRenderer(this);
        leftArm.func_78793_a(5.0F, -24.0F, -1.0F);
        leftArm.field_78804_l.add(new ModelBox(leftArm, 32, 16, 0.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F, true));
        bb_main.func_78792_a(leftArm);

        // Права рука
        rightArm = new ModelRenderer(this);
        rightArm.func_78793_a(-7.0F, -24.0F, -1.0F);
        rightArm.field_78804_l.add(new ModelBox(rightArm, 24, 0, 0.0F, 0.0F, 0.0F, 2, 12, 2, 0.0F, false));
        bb_main.func_78792_a(rightArm);

        // Ліва нога
        leftLeg = new ModelRenderer(this);
        leftLeg.func_78793_a(0.9F, -12.0F, -1.0F);
        leftLeg.field_78804_l.add(new ModelBox(leftLeg, 40, 16, 0.0F, 0.0F, 0.0F, 2, 11, 2, 0.0F, true));
        bb_main.func_78792_a(leftLeg);

        // Права нога
        rightLeg = new ModelRenderer(this);
        rightLeg.func_78793_a(-3.05F, -12.0F, -1.0F);
        rightLeg.field_78804_l.add(new ModelBox(rightLeg, 8, 0, 0.0F, 0.0F, 0.0F, 2, 11, 2, 0.0F, false));
        bb_main.func_78792_a(rightLeg);

        // Лівий кусок тіла
        leftBodyPiece = new ModelRenderer(this);
        leftBodyPiece.func_78793_a(1.0F, -21.0F, -1.0F);
        leftBodyPiece.field_78804_l.add(new ModelBox(leftBodyPiece, 48, 16, 0.0F, 0.0F, 0.0F, 2, 7, 2, 0.0F, false));
        bb_main.func_78792_a(leftBodyPiece);

        // Правий кусок тіла
        rightBodyPiece = new ModelRenderer(this);
        rightBodyPiece.func_78793_a(-3.0F, -21.0F, -1.0F);
        rightBodyPiece.field_78804_l.add(new ModelBox(rightBodyPiece, 16, 0, 0.0F, 0.0F, 0.0F, 2, 7, 2, 0.0F, false));
        bb_main.func_78792_a(rightBodyPiece);

        // Нижня частина тіла
        lowerBody = new ModelRenderer(this);
        lowerBody.func_78793_a(0.0F, -14.0F, -1.0F);
        lowerBody.field_78804_l.add(new ModelBox(lowerBody, 0, 48, -4.0F, 0.0F, 0.0F, 8, 2, 2, 0.0F, false));
        bb_main.func_78792_a(lowerBody);
    }

    @Override
    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        func_78087_a(f, f1, f2, f3, f4, f5, entity);
        bb_main.func_78785_a(f5);
    }

    @Override
    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        this.leftArm.field_78795_f = (float) Math.cos(limbSwing * 0.6662F) * 1.1F * limbSwingAmount;
        this.rightArm.field_78795_f = (float) Math.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.1F * limbSwingAmount;
        this.leftLeg.field_78795_f = (float) Math.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.1F * limbSwingAmount;
        this.rightLeg.field_78795_f = (float) Math.cos(limbSwing * 0.6662F) * 1.1F * limbSwingAmount;

        if (entity instanceof EntityLivingBase && ((EntityLivingBase) entity).func_70678_g(scaleFactor) > 0.0F) {
            float swingProgress = ((EntityLivingBase) entity).func_70678_g(scaleFactor);
            this.rightArm.field_78795_f = -2.0F + 1.5F * swingProgress; 
            this.rightArm.field_78796_g = 0.0F;
            this.rightArm.field_78808_h = (float) Math.cos(ageInTicks * 0.09F) * 0.05F + 0.05F;
        }
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}
