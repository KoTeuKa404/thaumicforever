package com.koteuka404.thaumicforever;

import java.util.Arrays;
import java.util.List;

import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import thaumcraft.api.crafting.IDustTrigger;
import thaumcraft.api.items.ItemsTC;

import thaumcraft.api.crafting.IDustTrigger.Placement;

public class SalisMundusDoubleTableTrigger implements IDustTrigger {

    @Override
    public Placement getValidFace(World world, EntityPlayer player, BlockPos pos, EnumFacing face) {
        IBlockState state = world.func_180495_p(pos);
        
        if (state.func_177230_c() == ModBlocks.GREATWOOD_TABLE) {
            BlockPos[] neighbors = {
                pos.func_177978_c(), pos.func_177968_d(), pos.func_177974_f(), pos.func_177976_e()
            };
            
            for (BlockPos neighborPos : neighbors) {
                IBlockState neighborState = world.func_180495_p(neighborPos);
                if (neighborState.func_177230_c() == ModBlocks.GREATWOOD_TABLE) {
                    return new Placement(0, 0, 0, face); 
                }
            }
        }
        return null; 
    }

    // Реалізація основної дії
    @Override
    public void execute(World world, EntityPlayer player, BlockPos pos, Placement placement, EnumFacing side) {
        IBlockState state = world.func_180495_p(pos);
        
        if (state.func_177230_c() == ModBlocks.GREATWOOD_TABLE) {
            BlockPos[] neighbors = {
                pos.func_177978_c(), pos.func_177968_d(), pos.func_177974_f(), pos.func_177976_e()
            };
            
            for (BlockPos neighborPos : neighbors) {
                IBlockState neighborState = world.func_180495_p(neighborPos);
                if (neighborState.func_177230_c() == ModBlocks.GREATWOOD_TABLE) {
                    world.func_175656_a(pos, ModBlocks.DOUBLE_TABLE.func_176223_P().func_177226_a(BlockHorizontal.field_185512_D, state.func_177229_b(BlockHorizontal.field_185512_D)));
                    world.func_175698_g(neighborPos);

                    ItemStack heldItem = player.func_184614_ca();
                    if (!player.func_184812_l_() && !heldItem.func_190926_b() && heldItem.func_77973_b() == ItemsTC.salisMundus) {
                        heldItem.func_190918_g(1);
                    }
                    break;
                }
            }
        }
    }

    @Override
    public List<BlockPos> sparkle(World world, EntityPlayer player, BlockPos pos, Placement placement) {
        return Arrays.asList(new BlockPos[]{pos});
    }
}
