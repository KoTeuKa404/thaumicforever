package com.koteuka404.thaumicforever;


import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;

public class ItemBottleVis extends Item {

    public ItemBottleVis() {
        super();
        this.func_77625_d(8); // Максимальна кількість у стосі
    }


    @Override
    public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
        ItemStack itemstack = playerIn.func_184586_b(handIn);

        if (!playerIn.field_71075_bZ.field_75098_d) {
            itemstack.func_190918_g(1); // Зменшуємо кількість у стосі
        }

        worldIn.func_184148_a(null, playerIn.field_70165_t, playerIn.field_70163_u, playerIn.field_70161_v, SoundEvents.field_187827_fP, SoundCategory.PLAYERS, 0.5F, 0.4F / (field_77697_d.nextFloat() * 0.4F + 0.8F));

        if (!worldIn.field_72995_K) {
            EntityBottleVis bottleEntity = new EntityBottleVis(worldIn, playerIn);
            bottleEntity.func_184538_a(playerIn, playerIn.field_70125_A, playerIn.field_70177_z, -20.0F, 0.7F, 1.0F);
            worldIn.func_72838_d(bottleEntity);
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, itemstack);
    }

}
