package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;
import net.minecraftforge.fml.common.IWorldGenerator;


public class WorldGenThaumicHouse implements IWorldGenerator {

    public static final ResourceLocation HOUSE_LOOT_TABLE = new ResourceLocation("thaumicforever", "chests/house");

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.field_73011_w.getDimension() == 0) { 
            Biome targetBiome = Biome.field_185377_q.func_82594_a(new ResourceLocation("thaumcraft", "magical_forest"));
            Biome biome = world.func_180494_b(new BlockPos(chunkX * 16, 0, chunkZ * 16));

            if (biome == targetBiome && random.nextInt(200) == 0) {  
                int x = chunkX * 16 + random.nextInt(16);
                int z = chunkZ * 16 + random.nextInt(16);
                int y = world.func_189649_b(x, z);

                BlockPos pos = new BlockPos(x, y, z);

                if (isValidGround(world, pos.func_177977_b()) && world.func_175678_i(pos)) {
                    TemplateManager templateManager = world.func_72860_G().func_186340_h();
                    Template template = templateManager.func_186237_a(world.func_73046_m(), new ResourceLocation("thaumicforever", "thaumic_house"));

                    if (template != null) {
                        template.func_186253_b(world, pos, new PlacementSettings().func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE));

                        generateLootInChests(world, pos);
                    }
                }
            }
        }
    }

    private boolean isValidGround(World world, BlockPos pos) {
        return world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150349_c
                || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150346_d
                || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150348_b
                || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150354_m
                || world.func_180495_p(pos).func_177230_c() == net.minecraft.init.Blocks.field_150431_aC;
    }
    
    private void generateStructure(World world, BlockPos pos, Random random) {

        generateLootInChests(world, pos);
    }

    private void generateLootInChests(World world, BlockPos pos) {
        for (int x = -5; x < 5; x++) {  
            for (int y = 0; y < 5; y++) {
                for (int z = -5; z < 5; z++) {
                    BlockPos checkPos = pos.func_177982_a(x, y, z);
                    TileEntity tileEntity = world.func_175625_s(checkPos);

                    if (tileEntity instanceof TileEntityLockableLoot) {
                        ((TileEntityLockableLoot) tileEntity).func_189404_a(HOUSE_LOOT_TABLE, world.field_73012_v.nextLong());
                    }
                }
            }
        }
    }
}
