package com.koteuka404.thaumicforever;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHandSide;

public class SkeletonReviveModel extends ModelBase {
    private final ModelRenderer head;
    private final ModelRenderer body;
    private final ModelRenderer leftArm;
    private final ModelRenderer rightArm;
    private final ModelRenderer leftLeg;
    private final ModelRenderer rightLeg;

    public SkeletonReviveModel() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;

        this.head = new ModelRenderer(this, 0, 0);
        this.head.func_78789_a(-4.0F, -8.0F, -4.0F, 8, 8, 8);
        this.head.func_78793_a(0.0F, 0.0F, 0.0F);

        this.body = new ModelRenderer(this, 16, 16);
        this.body.func_78789_a(-4.0F, 0.0F, -2.0F, 8, 12, 4);
        this.body.func_78793_a(0.0F, 0.0F, 0.0F);

        this.leftArm = new ModelRenderer(this, 40, 16);
        this.leftArm.func_78789_a(-1.0F, -2.0F, -1.0F, 2, 12, 2);
        this.leftArm.func_78793_a(5.0F, 2.0F, 0.0F);

        this.rightArm = new ModelRenderer(this, 40, 16);
        this.rightArm.func_78789_a(-1.0F, -2.0F, -1.0F, 2, 12, 2);
        this.rightArm.func_78793_a(-5.0F, 2.0F, 0.0F);

        this.leftLeg = new ModelRenderer(this, 0, 16);
        this.leftLeg.func_78789_a(-1.0F, 0.0F, -1.1F, 2, 12, 2);
        this.leftLeg.func_78793_a(2.0F, 12.0F, 0.1F);

        this.rightLeg = new ModelRenderer(this, 0, 16);
        this.rightLeg.func_78789_a(-1.0F, 0.0F, -1.1F, 2, 12, 2);
        this.rightLeg.func_78793_a(-2.0F, 12.0F, 0.1F);
    }

    @Override
    public void func_78088_a(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        this.head.func_78785_a(scale);
        this.body.func_78785_a(scale);
        this.leftArm.func_78785_a(scale);
        this.rightArm.func_78785_a(scale);
        this.leftLeg.func_78785_a(scale);
        this.rightLeg.func_78785_a(scale);
    }

    @Override
    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.head.field_78796_g = netHeadYaw * 0.017453292F;
        this.head.field_78795_f = headPitch * 0.017453292F;

        
            EntityPlayer player = entityIn.field_70170_p.func_72890_a(entityIn, 10.0D);
            double distanceToPlayer = player != null ? entityIn.func_70032_d(player) : 10.0D;

            float animationScale = 1.0F;
            if (distanceToPlayer < 2.0) {
                animationScale = (float) distanceToPlayer / 2.0F; 
            }

            this.rightArm.field_78795_f = (float) (Math.cos(limbSwing * 0.6662F + Math.PI) * 2.0F * limbSwingAmount * 0.5F * animationScale);
            this.leftArm.field_78795_f = (float) (Math.cos(limbSwing * 0.6662F) * 2.0F * limbSwingAmount * 0.5F * animationScale);
            this.rightLeg.field_78795_f = (float) (Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount * animationScale);
            this.leftLeg.field_78795_f = (float) (Math.cos(limbSwing * 0.6662F + Math.PI) * 1.4F * limbSwingAmount * animationScale);
        }
    public void postRenderArm(float scale, EnumHandSide handSide) {
        if (handSide == EnumHandSide.RIGHT) {
            this.rightArm.func_78794_c(scale);
        } else {
            this.leftArm.func_78794_c(scale);
        }
    }

}
