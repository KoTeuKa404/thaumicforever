package com.koteuka404.thaumicforever;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class TileEntityTimeSlow extends TileEntity implements ITickable {

    private static final int RADIUS = 3; // Радіус охоплення
    private static final int SLOWDOWN_INTERVAL = 3; // Кількість пропущених тиків

    // Глобальна мапа для контролю уповільнених TileEntity
    private static final Map<BlockPos, Integer> slowRegistry = new HashMap<>();

    @Override
    public void onLoad() {
        if (!field_145850_b.field_72995_K) {
            addToRegistry();
        }
    }

    @Override
    public void onChunkUnload() {
        if (!field_145850_b.field_72995_K) {
            removeFromRegistry();
        }
    }

    @Override
    public void func_145843_s() {
        if (!field_145850_b.field_72995_K) {
            removeFromRegistry();
        }
        super.func_145843_s();
    }

    private void addToRegistry() {
        AxisAlignedBB area = new AxisAlignedBB(field_174879_c.func_177982_a(-RADIUS, -RADIUS, -RADIUS), field_174879_c.func_177982_a(RADIUS, RADIUS, RADIUS));
        for (BlockPos targetPos : BlockPos.func_177980_a(new BlockPos(area.field_72340_a, area.field_72338_b, area.field_72339_c),
                                                       new BlockPos(area.field_72336_d, area.field_72337_e, area.field_72334_f))) {
            if (!slowRegistry.containsKey(targetPos)) {
                slowRegistry.put(targetPos, 0); // Додаємо блок у реєстр
            }
        }
    }

    private void removeFromRegistry() {
        AxisAlignedBB area = new AxisAlignedBB(field_174879_c.func_177982_a(-RADIUS, -RADIUS, -RADIUS), field_174879_c.func_177982_a(RADIUS, RADIUS, RADIUS));
        for (BlockPos targetPos : BlockPos.func_177980_a(new BlockPos(area.field_72340_a, area.field_72338_b, area.field_72339_c),
                                                       new BlockPos(area.field_72336_d, area.field_72337_e, area.field_72334_f))) {
            slowRegistry.remove(targetPos); // Видаляємо блок із реєстру
        }
    }

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K) {
            // Просто контролюємо реєстр, нічого іншого тут не робимо
        }
    }

    public static boolean shouldUpdate(BlockPos pos) {
        if (slowRegistry.containsKey(pos)) {
            int ticksSkipped = slowRegistry.get(pos);
            ticksSkipped++;
            if (ticksSkipped >= SLOWDOWN_INTERVAL) {
                slowRegistry.put(pos, 0); // Скидаємо лічильник
                return true; // Дозволяємо оновлення
            } else {
                slowRegistry.put(pos, ticksSkipped); // Оновлюємо лічильник
                return false; // Блокуємо оновлення
            }
        }
        return true; // Якщо блок не під впливом, дозволяємо оновлення
    }
}
