package com.koteuka404.thaumicforever;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SpawnStructure {

    public static void generateStructure(World world, BlockPos pos) {
        for (int x = -5; x <= 5; x++) {
            for (int z = -5; z <= 5; z++) {
                for (int y = 0; y <= 25; y++) {
                    BlockPos blockPos = pos.func_177982_a(x, y, z);
                    IBlockState blockState = Blocks.field_180401_cv.func_176223_P();
                    world.func_180501_a(blockPos, blockState, 2);
                }
            }
        }

        BlockPos spawnPos = pos.func_177982_a(0, 1, 0);
        world.func_180501_a(spawnPos, Blocks.field_150348_b.func_176223_P(), 2);
    }
}
