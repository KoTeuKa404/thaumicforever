package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class DoubleTableContainer extends Container {
    private final IInventory tileEntity;

    public DoubleTableContainer(InventoryPlayer playerInventory, IInventory tileEntity) {
        this.tileEntity = tileEntity;

        this.func_75146_a(new Slot(tileEntity, 0, 15, 16));
        this.func_75146_a(new Slot(tileEntity, 1, 15, 32 + 8));
        this.func_75146_a(new Slot(tileEntity, 2, 15, 48 + 16));
        this.func_75146_a(new Slot(tileEntity, 3, 15, 64 + 25));
        this.func_75146_a(new Slot(tileEntity, 4, 15, 80 + 31));

        this.func_75146_a(new Slot(tileEntity, 5, 85, 64) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return stack.func_77973_b().getRegistryName().toString().equals("thaumicforever:scroll_o");
            }
        });

        this.func_75146_a(new Slot(tileEntity, 6, 85, 96) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return stack.func_77973_b().getRegistryName().toString().equals("minecraft:paper");
            }
        });

        // Інвентар гравця (відстань між слотами по Y зменшена)
        int playerInventoryStartX = 43;
        int playerInventoryStartY = 160;
        int slotSpacingX = 17; // Стандартна відстань між слотами по X
        int slotSpacingY = 18; // Зменшена відстань між слотами по Y
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                this.func_75146_a(new Slot(playerInventory, j + i * 9 + 9, playerInventoryStartX + j * slotSpacingX, playerInventoryStartY + i * slotSpacingY));
            }
        }

        int hotbarX = 43;
        int hotbarY = 218;
        for (int i = 0; i < 9; i++) {
            this.func_75146_a(new Slot(playerInventory, i, hotbarX + i * slotSpacingX, hotbarY));
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return this.tileEntity.func_70300_a(playerIn);
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d()) {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();

            int containerSlotCount = 7;

            if (index < containerSlotCount) {
                if (!this.func_75135_a(itemstack1, containerSlotCount, this.field_75151_b.size(), true)) {
                    return ItemStack.field_190927_a;
                }
            } else {
                if (!this.func_75135_a(itemstack1, 0, containerSlotCount, false)) {
                    return ItemStack.field_190927_a;
                }
            }

            if (itemstack1.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }
        }

        return itemstack;
    }
}
