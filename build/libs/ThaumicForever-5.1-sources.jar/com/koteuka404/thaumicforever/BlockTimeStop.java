package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockTimeStop extends Block {

    public BlockTimeStop() {
        super(Material.field_151592_s);
        func_149711_c(20.0F); 
        func_149752_b(100.0F); 
        func_149713_g(1); 
        func_149663_c("time_stop_block");
        setRegistryName("time_stop_block");
    }

    @Override
    public boolean func_149662_c(IBlockState state) {
        return false; 
    }

    @Override
    public boolean func_149686_d(IBlockState state) {
        return false; 
    }

    @Override
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.TRANSLUCENT;
    }
    @Override
    public void func_180650_b(World world, BlockPos pos, net.minecraft.block.state.IBlockState state, java.util.Random rand) {
        world.func_175698_g(pos);
    }
}

