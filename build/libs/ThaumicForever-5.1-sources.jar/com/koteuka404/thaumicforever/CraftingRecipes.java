package com.koteuka404.thaumicforever;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import thaumcraft.api.items.ItemsTC;

public class CraftingRecipes {
    public static void init() {
        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "greatwood_table"),
            null,
            new ItemStack(ModBlocks.GREATWOOD_TABLE), 
            "PPP",
            " S ",
            'P', Blocks.field_150376_bx, 
            'S', Blocks.field_150344_f 
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "lead_block"),
            null,
            new ItemStack(ModBlocks.LEAD_BLOCK),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.LEAD_INGOT)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "silver_block"),
            null,
            new ItemStack(ModBlocks.SILVER_BLOCK),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.SILVER_INGOT)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "tin_block"),
            null,
            new ItemStack(ModBlocks.TIN_BLOCK),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.TIN_INGOT)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "copper_block"),
            null,
            new ItemStack(ModBlocks.COPPER_BLOCK),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.COPPER_INGOT)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "lead_ingot_from_block"),
            null,
            new ItemStack(ModItems.LEAD_INGOT, 9),
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.LEAD_BLOCK))
        );
        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "bowl_treatmeat"),
            null,
            new ItemStack(ModItems.BOWL_TREATMEAT),
            Ingredient.func_193368_a(Items.field_151054_z), 
            Ingredient.func_193368_a(ItemsTC.tripleMeatTreat), 
            Ingredient.func_193368_a(ItemsTC.tripleMeatTreat),
            Ingredient.func_193368_a(ItemsTC.tripleMeatTreat)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "bowl_zombie"),
            null,
            new ItemStack(ModItems.BOWL_ZOMBIE),
            Ingredient.func_193368_a(Items.field_151054_z),
            Ingredient.func_193368_a(ModItems.ItemZombieHeart), 
            Ingredient.func_193368_a(Items.field_151078_bh)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "dye_from_red"),
            null,
            new ItemStack(Items.field_151100_aR, 1, 1), 
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.RED_ROSE)) 
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "dye_from_blue"),
            null,
            new ItemStack(Items.field_151100_aR, 1, 12), 
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.BLUE_ROSE)) 
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "silver_ingot_from_block"),
            null,
            new ItemStack(ModItems.SILVER_INGOT, 9),
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.SILVER_BLOCK))
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "tin_ingot_from_block"),
            null,
            new ItemStack(ModItems.TIN_INGOT, 9),
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.TIN_BLOCK))
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "copper_ingot_from_block"),
            null,
            new ItemStack(ModItems.COPPER_INGOT, 9),
            Ingredient.func_193368_a(Item.func_150898_a(ModBlocks.COPPER_BLOCK))
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "lead_nugget"),
            null,
            new ItemStack(ModItems.LEAD_NUGGET, 9),
            Ingredient.func_193368_a(ModItems.LEAD_INGOT)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "silver_nugget"),
            null,
            new ItemStack(ModItems.SILVER_NUGGET, 9),
            Ingredient.func_193368_a(ModItems.SILVER_INGOT)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "tin_nugget"),
            null,
            new ItemStack(ModItems.TIN_NUGGET, 9),
            Ingredient.func_193368_a(ModItems.TIN_INGOT)
        );

        GameRegistry.addShapelessRecipe(
            new ResourceLocation("thaumicforever", "copper_nugget"),
            null,
            new ItemStack(ModItems.COPPER_NUGGET, 9),
            Ingredient.func_193368_a(ModItems.COPPER_INGOT)
        );
        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "amulet_fix"),
            null,
            new ItemStack(ModItems.ZOMBIE_HEART_AMULET),
            "IA",
            'I', Ingredient.func_193368_a(ModItems.BROKEN_AMULET),
            'A', Ingredient.func_193368_a(ModItems.ItemZombieHeart)

        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "lead_ingot_from_nuggets"),
            null,
            new ItemStack(ModItems.LEAD_INGOT),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.LEAD_NUGGET)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "silver_ingot_from_nuggets"),
            null,
            new ItemStack(ModItems.SILVER_INGOT),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.SILVER_NUGGET)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "aquareiagoggles"),
            null,
            new ItemStack(ModItems.ItemAquareiaGoggles),
            "IAI",
            'I', Ingredient.func_193368_a(ModItems.AQUAREIA_GEM),
            'A', Ingredient.func_193368_a(ItemsTC.goggles)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "tin_ingot_from_nuggets"),
            null,
            new ItemStack(ModItems.TIN_INGOT),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.TIN_NUGGET)
        );

        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "copper_ingot_from_nuggets"),
            null,
            new ItemStack(ModItems.COPPER_INGOT),
            "III", "III", "III",
            'I', Ingredient.func_193368_a(ModItems.COPPER_NUGGET)
        );
        GameRegistry.addShapedRecipe(
            new ResourceLocation("thaumicforever", "iron_ring"),
            null,
            new ItemStack(ModItems.IRONRING),
            "III", "I I", "III",
            'I', Ingredient.func_193368_a(Items.field_191525_da)
        );
    }
}
