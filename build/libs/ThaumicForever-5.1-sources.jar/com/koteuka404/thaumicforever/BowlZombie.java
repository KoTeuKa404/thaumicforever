package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class BowlZombie extends ItemFood {

    public BowlZombie() {
        super(3, 0.3F, false);
        setRegistryName("bowl_zombie");
        func_77655_b("bowl_zombie");
        func_77848_i(); 
    }

    @Override
    protected void func_77849_c(ItemStack stack, World world, EntityPlayer player) {
        super.func_77849_c(stack, world, player);

        if (!world.field_72995_K) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76431_k, 14 * 20, 0));
            player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 10 * 20, 0)); 
        }

        if (!player.field_71071_by.func_70441_a(new ItemStack(Items.field_151054_z))) {
            player.func_71019_a(new ItemStack(Items.field_151054_z), false);
        }
    }
}
