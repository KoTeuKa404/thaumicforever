package com.koteuka404.thaumicforever;

import java.util.ArrayList;

import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.registries.IForgeRegistryEntry;
import thaumcraft.api.items.ItemsTC;
import thaumcraft.common.items.resources.ItemCrystalEssence;

public class CustomSalisMundusRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe {

    public CustomSalisMundusRecipe() {
        setRegistryName(new ResourceLocation("thaumicforever", "salis_mundus_recipe"));
    }

    @Override
    public boolean func_77569_a(InventoryCrafting inv, World worldIn) {
        boolean bowl = false;
        boolean flint = false;
        boolean redstone = false;
        ArrayList<String> crystals = new ArrayList<>();

        for (int i = 0; i < inv.func_70302_i_(); i++) {
            ItemStack stack = inv.func_70301_a(i);

            if (stack.func_190926_b()) continue;

            if (stack.func_77973_b() == Items.field_151054_z) {
                if (bowl) return false;
                bowl = true;
            } else if (stack.func_77973_b() == Items.field_151145_ak) {
                if (flint) return false;
                flint = true;
            } else if (stack.func_77973_b() == Items.field_151137_ax) {
                if (redstone) return false;
                redstone = true;
            } else if (stack.func_77973_b() == ItemsTC.crystalEssence) {
                ItemCrystalEssence ice = (ItemCrystalEssence) stack.func_77973_b();
                String aspect = ice.getAspects(stack).getAspects()[0].getTag();
                if (crystals.contains(aspect) || crystals.size() >= 3) {
                    return false;
                }
                crystals.add(aspect);
            } else {
                return false; 
            }
        }

        return bowl && flint && redstone && crystals.size() == 3;
    }

    @Override
    public ItemStack func_77572_b(InventoryCrafting inv) {
        return new ItemStack(ItemsTC.salisMundus);
    }

    @Override
    public boolean func_194133_a(int width, int height) {
        return width * height >= 6;
    }

    @Override
    public ItemStack func_77571_b() {
        return new ItemStack(ItemsTC.salisMundus);
    }

    @Override
    public NonNullList<ItemStack> func_179532_b(InventoryCrafting inv) {
        NonNullList<ItemStack> ret = NonNullList.func_191197_a(inv.func_70302_i_(), ItemStack.field_190927_a);

        for (int i = 0; i < ret.size(); ++i) {
            ItemStack itemstack = inv.func_70301_a(i);
            if (!itemstack.func_190926_b() && (itemstack.func_77973_b() == Items.field_151145_ak || itemstack.func_77973_b() == Items.field_151054_z)) {
                ItemStack is = itemstack.func_77946_l();
                is.func_190920_e(1);
                ret.set(i, is);
            } else {
                ret.set(i, ForgeHooks.getContainerItem(itemstack));
            }
        }

        return ret;
    }
}

