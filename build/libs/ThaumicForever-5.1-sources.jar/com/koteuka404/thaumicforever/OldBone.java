package com.koteuka404.thaumicforever;

import java.util.List;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;

public class OldBone extends Item {

    @Override
    public boolean onEntityItemUpdate(EntityItem entityItem) {
        World world = entityItem.func_130014_f_();

        if (!world.field_72995_K && entityItem != null && !entityItem.field_70128_L) {
            AxisAlignedBB searchBox = new AxisAlignedBB(
                    entityItem.field_70165_t - 3, entityItem.field_70163_u - 3, entityItem.field_70161_v - 3,
                    entityItem.field_70165_t + 3, entityItem.field_70163_u + 3, entityItem.field_70161_v + 3
            );

            List<EntityItem> nearbyBones = world.func_175647_a(EntityItem.class, searchBox, nearbyItem ->
                    nearbyItem.func_92059_d().func_77973_b() instanceof OldBone && !nearbyItem.field_70128_L);

            int totalBones = nearbyBones.stream()
                    .mapToInt(bone -> bone.func_92059_d().func_190916_E())
                    .sum();

            int skeletonsToSpawn = totalBones / 4;

            if (skeletonsToSpawn > 0) {
                int bonesToRemove = skeletonsToSpawn * 4;

                for (EntityItem nearbyBone : nearbyBones) {
                    ItemStack stack = nearbyBone.func_92059_d();
                    int count = stack.func_190916_E();

                    if (count > bonesToRemove) {
                        stack.func_190918_g(bonesToRemove);
                        bonesToRemove = 0;
                    } else {
                        bonesToRemove -= count;
                        nearbyBone.func_70106_y();
                    }

                    if (bonesToRemove <= 0) {
                        break;
                    }
                }

                for (int i = 0; i < skeletonsToSpawn; i++) {
                    ReviveSkeletonEntity reviveSkeleton = new ReviveSkeletonEntity(world);
                    reviveSkeleton.func_70107_b(entityItem.field_70165_t, entityItem.field_70163_u, entityItem.field_70161_v);
                    world.func_72838_d(reviveSkeleton);
                }

                entityItem.func_70106_y();
            }
        }

        return super.onEntityItemUpdate(entityItem);
    }
}
