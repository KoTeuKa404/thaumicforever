package com.koteuka404.thaumicforever;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;

public class PlayerStructureManager {
    private static final Map<UUID, BlockPos> playerStructures = new HashMap<>();
    private static final String STRUCTURE_NAME = "thaumicforever:void";

    public static BlockPos getOrCreateStructureForPlayer(EntityPlayerMP player, World world) {
        UUID playerID = player.func_110124_au();

        if (playerStructures.containsKey(playerID)) {
            return playerStructures.get(playerID);
        } else {
            BlockPos structurePosition = generateStructure(world);
            playerStructures.put(playerID, structurePosition);
            return structurePosition.func_177982_a(15, 8, 15); // Зсув для точки спавну
        }
    }

    private static BlockPos generateStructure(World world) {
        int x = world.field_73012_v.nextInt(100000) - 50000; // Генерація координат у межах (-50000, 50000)
        int z = world.field_73012_v.nextInt(100000) - 50000;
        BlockPos structurePosition = new BlockPos(x, 64, z);

        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = templateManager.func_186237_a(world.func_73046_m(), new ResourceLocation(STRUCTURE_NAME));

        if (template != null) {
            template.func_186253_b(world, structurePosition, new net.minecraft.world.gen.structure.template.PlacementSettings());
        } else {
            System.err.println("Шаблон не знайдено: " + STRUCTURE_NAME);
        }

        return structurePosition;
    }
}
