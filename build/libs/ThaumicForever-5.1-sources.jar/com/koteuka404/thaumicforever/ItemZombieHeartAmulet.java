package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import thaumcraft.common.entities.monster.EntityGiantBrainyZombie;

public class ItemZombieHeartAmulet extends Item implements IBauble {

    public ItemZombieHeartAmulet() {
        func_77655_b("zombie_heart_amulet");
        setRegistryName("zombie_heart_amulet");
        func_77625_d(1);
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET;
    }

    @Override
    public void onWornTick(ItemStack stack, EntityLivingBase entity) {
        if (entity instanceof EntityPlayer && !entity.field_70170_p.field_72995_K) {
            EntityPlayer player = (EntityPlayer) entity;

            if (player.func_110143_aJ() <= 4.0F) {
                summonGiantZombie(player, player.field_70170_p); 
                replaceWithBrokenAmulet(stack, player); 
            }
        }
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);

        if (!world.field_72995_K) {
            summonGiantZombie(player, world); 
            replaceWithBrokenAmulet(stack, player); 
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    private void summonGiantZombie(EntityPlayer player, World world) {
    if (!world.field_72995_K) {
        EntityGiantBrainyZombie giantZombie = new EntityGiantBrainyZombie(world);
        giantZombie.func_70107_b(player.field_70165_t, player.field_70163_u, player.field_70161_v); 
        giantZombie.field_70715_bh.func_75776_a(1, new EntityAIBase() {
            @Override
            public boolean func_75250_a() {
                return giantZombie.func_70638_az() != null;
            }

            @Override
            public void func_75246_d() {
                if (giantZombie.func_70638_az() instanceof EntityPlayer) {
                    EntityPlayer target = (EntityPlayer) giantZombie.func_70638_az();
                    if (isPlayerWearingAmulet(target)) {
                        giantZombie.func_70624_b(null);
                    }
                }
            }

            @Override
            public boolean func_75253_b() {
                return false;  
            }
        });

        world.func_72838_d(giantZombie);
        world.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187899_gZ, SoundCategory.PLAYERS, 1.0F, 1.0F);  
    }
}

private boolean isPlayerWearingAmulet(EntityPlayer player) {
    for (ItemStack stack : player.field_71071_by.field_70462_a) {
        if (stack.func_77973_b() instanceof ItemZombieHeartAmulet) {
            return true;
        }
    }
    return false;
}

    
    


    private void replaceWithBrokenAmulet(ItemStack stack, EntityPlayer player) {
        stack.func_190918_g(1);   

        ItemStack brokenAmulet = new ItemStack(ModItems.BROKEN_AMULET);  
        if (!player.field_71071_by.func_70441_a(brokenAmulet)) {
            player.func_71019_a(brokenAmulet, false);  
        }
    }
    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE; 
    }
}
