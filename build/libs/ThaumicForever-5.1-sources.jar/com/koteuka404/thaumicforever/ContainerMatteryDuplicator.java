package com.koteuka404.thaumicforever;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerMatteryDuplicator extends Container {

    private final TileEntityMatteryDuplicator tileEntity;

    public ContainerMatteryDuplicator(InventoryPlayer playerInventory, TileEntityMatteryDuplicator tileEntity) {
        this.tileEntity = tileEntity;

        // Adding slots for the duplicator inventory
        func_75146_a(new Slot(tileEntity, 0, 36, 8));
        func_75146_a(new Slot(tileEntity, 1, 56, 8));
        func_75146_a(new Slot(tileEntity, 2, 76, 8));

        func_75146_a(new Slot(tileEntity, 3, 36, 28));
        func_75146_a(new Slot(tileEntity, 4, 56, 28));
        func_75146_a(new Slot(tileEntity, 5, 76, 28));

        func_75146_a(new Slot(tileEntity, 6, 36, 48));
        func_75146_a(new Slot(tileEntity, 7, 56, 48));
        func_75146_a(new Slot(tileEntity, 8, 76, 48));

        func_75146_a(new Slot(tileEntity, 9, 132, 28) {
            @Override
            public boolean func_75214_a(ItemStack stack) {
                return false; 
            }

            @Override
            public ItemStack func_190901_a(EntityPlayer playerIn, ItemStack stack) {
                if (tileEntity.hasEnoughEssentia()) {
                    tileEntity.consumeEssentia();
                }
                return super.func_190901_a(playerIn, stack);
            }
        });

        bindPlayerInventory(playerInventory);
    }

    private void bindPlayerInventory(InventoryPlayer playerInventory) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                func_75146_a(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18 + 22));
            }
        }

        for (int k = 0; k < 9; k++) {
            func_75146_a(new Slot(playerInventory, k, 8 + k * 18, 142 + 22));
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return this.tileEntity.func_70300_a(playerIn);
    }

    @Override
public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
    ItemStack itemstack = ItemStack.field_190927_a;
    Slot slot = this.field_75151_b.get(index);

    if (slot != null && slot.func_75216_d()) {
        ItemStack stackInSlot = slot.func_75211_c();
        itemstack = stackInSlot.func_77946_l();

        // Якщо слот - результатний (9-й)
        if (index == 9) {
            if (!this.func_75135_a(stackInSlot, 10, this.field_75151_b.size(), true)) {
                return ItemStack.field_190927_a;
            }
            slot.func_75220_a(stackInSlot, itemstack);
        } 
        // Якщо слот входить до інвентаря дуплікатора (0-8)
        else if (index < 9) {
            if (!this.func_75135_a(stackInSlot, 10, this.field_75151_b.size(), false)) {
                return ItemStack.field_190927_a;
            }
        } 
        // Якщо слот входить до інвентаря гравця (10+)
        else if (index >= 10) {
            // Переміщення в слоти дуплікатора
            if (!this.func_75135_a(stackInSlot, 0, 9, false)) {
                return ItemStack.field_190927_a;
            }
        }

        if (stackInSlot.func_190926_b()) {
            slot.func_75215_d(ItemStack.field_190927_a);
        } else {
            slot.func_75218_e();
        }

        if (stackInSlot.func_190916_E() == itemstack.func_190916_E()) {
            return ItemStack.field_190927_a;
        }

        slot.func_190901_a(playerIn, stackInSlot);
    }

    return itemstack;
}



    @Override
    public void func_75142_b() {
        super.func_75142_b();

        for (int i = 0; i < this.field_75151_b.size(); i++) {
            Slot slot = this.field_75151_b.get(i);
            ItemStack stackInSlot = slot.func_75211_c();

            if (stackInSlot == null) {
                stackInSlot = ItemStack.field_190927_a;
            }

            ItemStack currentStack = slot.func_75211_c();
            if (currentStack == null) {
                currentStack = ItemStack.field_190927_a;
            }

            if (!ItemStack.func_77989_b(currentStack, stackInSlot)) {
                for (int j = 0; j < this.field_75149_d.size(); ++j) {
                    this.field_75149_d.get(j).func_71111_a(this, i, stackInSlot);
                }
            }
        }
    }
}