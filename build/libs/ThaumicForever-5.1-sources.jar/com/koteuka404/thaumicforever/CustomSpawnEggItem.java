package com.koteuka404.thaumicforever;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.World;

public class CustomSpawnEggItem extends Item {
    private final ResourceLocation entityID;

    public CustomSpawnEggItem(String modID, String entityName) {
        this.entityID = new ResourceLocation(modID, entityName);
        this.func_77655_b(entityName + "_spawn_egg");
        this.setRegistryName(entityName + "_spawn_egg");
        this.func_77637_a(CreativeTabs.field_78026_f);
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);

        RayTraceResult rayTrace = this.func_77621_a(world, player, true);
        if (rayTrace == null || rayTrace.field_72313_a != Type.BLOCK) {
            return new ActionResult<>(EnumActionResult.PASS, stack);
        }

        if (!world.field_72995_K) {
            Entity entity = EntityList.func_188429_b(entityID, world);
            if (entity != null) {
                entity.func_70107_b(rayTrace.field_72307_f.field_72450_a, rayTrace.field_72307_f.field_72448_b + 1.0, rayTrace.field_72307_f.field_72449_c);
                world.func_72838_d(entity);

                if (!player.field_71075_bZ.field_75098_d) {
                    stack.func_190918_g(1);
                }
                return new ActionResult<>(EnumActionResult.SUCCESS, stack);
            }
        }
        return new ActionResult<>(EnumActionResult.FAIL, stack);
    }
}
