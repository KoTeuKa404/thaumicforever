package com.koteuka404.thaumicforever;


import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import thaumcraft.api.aura.AuraHelper;

public class EntityBottleVis extends EntityThrowable {

    public EntityBottleVis(World worldIn) {
        super(worldIn);
    }

    public EntityBottleVis(World worldIn, EntityLivingBase throwerIn) {
        super(worldIn, throwerIn);
    }

    @Override
    protected void func_70184_a(RayTraceResult result) {
        if (!this.field_70170_p.field_72995_K) {
            BlockPos impactPos = result.func_178782_a();
            if (impactPos == null) {
                impactPos = new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            }

            // Підвищуємо ауру на 50 одиниць
            AuraHelper.addVis(field_70170_p, impactPos, 50.0f);

            this.func_70106_y();
        }
    }
}
