package com.koteuka404.thaumicforever;

import java.io.IOException;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiCrimsonBook extends GuiScreen {

    private static final ResourceLocation BOOK_TEXTURE = new ResourceLocation("thaumicforever", "textures/gui/crims_book.png");
    private static final ResourceLocation BOOK_TEXTURE1 = new ResourceLocation("thaumicforever", "textures/gui/crims_book1.png");
    
    private ResourceLocation currentTexture = BOOK_TEXTURE;
    private final int textureWidth = 255; 
    private final int textureHeight = 250;

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(currentTexture);
        int centerX = (this.field_146294_l - textureWidth) / 2;
        int centerY = (this.field_146295_m - textureHeight) / 2 ;
        this.func_73729_b(centerX, centerY, 0, 0, textureWidth, textureHeight);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        try {
            super.func_73864_a(mouseX, mouseY, mouseButton);
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        int centerX = (this.field_146294_l - textureWidth) / 2;
        int rightX = centerX + textureWidth / 2;
        int centerY = (this.field_146295_m - textureHeight) / 2 - 40;
    
        if (mouseX > rightX) {
            currentTexture = BOOK_TEXTURE1;
        } else if (mouseX < rightX) {
            currentTexture = BOOK_TEXTURE;
        }
    }
    

    @Override
    public boolean func_73868_f() {
        return false;
    }
}
