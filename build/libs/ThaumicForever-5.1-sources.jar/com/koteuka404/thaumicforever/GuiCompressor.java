package com.koteuka404.thaumicforever;

import java.io.IOException;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class GuiCompressor extends GuiContainer {

    private static final ResourceLocation TEXTURES = new ResourceLocation("thaumicforever", "textures/gui/compressor.png");
    private final TileEntityCompressor tileEntity;

    public GuiCompressor(InventoryPlayer player, TileEntityCompressor tileEntity) {
        super(new ContainerCompressor(player, tileEntity));
        this.tileEntity = tileEntity;
        this.field_146999_f = 176;
        this.field_147000_g = 166;
    }

    @Override
    protected void func_146979_b(int mouseX, int mouseY) {
        List<ItemStack> plateOptions = tileEntity.getPlateOptions();
        if (plateOptions != null && !plateOptions.isEmpty()) {
            for (int i = 0; i < plateOptions.size(); i++) {
                ItemStack plate = plateOptions.get(i);
                this.field_146296_j.func_180450_b(plate, 40 + (i * 20), 40);
                if (tileEntity.getSelectedPlate().func_77969_a(plate)) {
                    this.func_73734_a(40 + (i * 20) - 1, 40 - 1, 40 + (i * 20) + 17, 40 + 17, 0x80FF0000);
                }
            }
        }
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        Minecraft.func_71410_x().func_110434_K().func_110577_a(TEXTURES);
        this.func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
    
        List<ItemStack> plateOptions = tileEntity.getPlateOptions();
        if (plateOptions != null && !plateOptions.isEmpty()) {
            for (int i = 0; i < plateOptions.size(); i++) {
                int xPos = this.field_147003_i + 40 + (i * 20);
                int yPos = this.field_147009_r + 40;
    
                if (mouseX >= xPos && mouseX <= xPos + 16 && mouseY >= yPos && mouseY <= yPos + 16) {
                    ItemStack selectedPlate = plateOptions.get(i);
                    tileEntity.setSelectedPlate(selectedPlate);
    
                    PacketSelectPlate packet = new PacketSelectPlate(selectedPlate, tileEntity.func_174877_v());
                    ThaumicForever.network.sendToServer(packet);
                    break;
                }
            }
        }
    }
    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
    
}
