package com.koteuka404.thaumicforever;

import io.netty.buffer.ByteBuf;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketSelectPlate implements IMessage {
    private ItemStack selectedPlate;
    private BlockPos pos; 

    public PacketSelectPlate() {}

    public PacketSelectPlate(ItemStack selectedPlate, BlockPos pos) {
        this.selectedPlate = selectedPlate;
        this.pos = pos;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        this.selectedPlate = new ItemStack(ByteBufUtils.readTag(buf));
        this.pos = new BlockPos(buf.readInt(), buf.readInt(), buf.readInt());
    }

    @Override
    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeTag(buf, this.selectedPlate.func_77955_b(new NBTTagCompound()));
        buf.writeInt(pos.func_177958_n()); 
        buf.writeInt(pos.func_177956_o());
        buf.writeInt(pos.func_177952_p()); 
    }

    public static class Handler implements IMessageHandler<PacketSelectPlate, IMessage> {
        @Override
        public IMessage onMessage(PacketSelectPlate message, MessageContext ctx) {
            ctx.getServerHandler().field_147369_b.func_71121_q().func_152344_a(() -> {
                TileEntityCompressor tile = (TileEntityCompressor) ctx.getServerHandler().field_147369_b.field_70170_p.func_175625_s(message.pos);
                if (tile != null) {
                    tile.setSelectedPlate(message.selectedPlate);
                }
            });
            return null;
        }
    }
}
