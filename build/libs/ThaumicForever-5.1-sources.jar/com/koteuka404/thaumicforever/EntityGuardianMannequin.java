package com.koteuka404.thaumicforever;

import java.util.UUID;

import javax.annotation.Nullable;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Loader;

public class EntityGuardianMannequin extends EntityCreature {
    private UUID ownerUUID;
    private static final UUID ARMOR_MODIFIER_UUID = UUID.fromString("5d7e7c84-7b10-4c78-bd3f-fc6c7efddc71");
    private static final UUID ARMOR_TOUGHNESS_MODIFIER_UUID = UUID.fromString("9f38e78e-3f09-4f62-8802-34d3ff8ff747");

    public EntityGuardianMannequin(World worldIn, EntityPlayer owner) {
        super(worldIn);
        this.ownerUUID = owner.func_110124_au();
        this.func_70105_a(0.6F, 1.6F);
        this.field_70728_aV = 5;
        this.func_184651_r();
    }

    public EntityGuardianMannequin(World worldIn) {
        super(worldIn);
        this.ownerUUID = null;
        this.func_70105_a(0.6F, 1.6F);
        this.field_70728_aV = 5;
        this.func_184651_r();
    }

    protected void func_184651_r() {
        this.field_70714_bg.func_75776_a(0, new EntityAISwimming(this));
        this.field_70714_bg.func_75776_a(1, new EntityAIAttackMelee(this, 1.0D, true));
        this.field_70714_bg.func_75776_a(3, new EntityAIWanderAvoidWater(this, 0.6D));
        this.field_70715_bh.func_75776_a(1, new EntityAIHurtByTarget(this, true) {
            @Override
            public boolean func_75250_a() {
                if (EntityGuardianMannequin.this.func_70643_av() instanceof EntityPlayer) {
                    EntityPlayer attacker = (EntityPlayer) EntityGuardianMannequin.this.func_70643_av();
                    if (EntityGuardianMannequin.this.isOwner(attacker)) {
                        return false;
                    }
                }
                return super.func_75250_a();
            }
        });
        this.field_70715_bh.func_75776_a(2, new EntityAINearestAttackableTarget<>(this, EntityLivingBase.class, 10, true, false, entity -> {
            if (entity instanceof EntityPlayer && EntityGuardianMannequin.this.isOwner((EntityPlayer) entity)) {
                return false;
            }
            return entity instanceof IMob;
        }));
    }
    
    private boolean isOwner(EntityPlayer player) {
        return this.ownerUUID != null && this.ownerUUID.equals(player.func_110124_au());
    }

    public EntityPlayer getOwner() {
        if (this.ownerUUID == null) {
            return null;
        }
        return this.field_70170_p.func_152378_a(this.ownerUUID);
    }

    @Override
    public void func_70636_d() {
        this.func_70050_g(9999999);

        EntityPlayer owner = this.getOwner();
        if (owner != null && !this.field_70170_p.field_72995_K) {
            if (this.func_70032_d(owner) > 10.0D) {
                this.func_70661_as().func_75497_a(owner, 1.0D);
            }
        }
        super.func_70636_d();
    }

    @Override
    public void func_70071_h_() {
        super.func_70071_h_();
        applyArmorAttributes();
        applyArmorEffects();
    }

    private boolean isSRParasitesInstalled() {
        return Loader.isModLoaded("srparasites");
    }

    private void applyArmorAttributes() {
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            ItemStack stack = this.func_184582_a(slot);
            if (!stack.func_190926_b()) {
                double armorValue = getArmorValue(stack);
                double toughnessValue = getArmorToughness(stack);

                if (!isSRParasitesInstalled()) {
                    armorValue /= 2;
                    toughnessValue /= 2;
                }

                if (armorValue > 0) {
                    if (this.func_110148_a(SharedMonsterAttributes.field_188791_g).func_111127_a(ARMOR_MODIFIER_UUID) == null) {
                        this.func_110148_a(SharedMonsterAttributes.field_188791_g).func_111121_a(
                            new AttributeModifier(ARMOR_MODIFIER_UUID, "Armor modifier", armorValue, 0));
                    }
                }

                if (toughnessValue > 0) {
                    if (this.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111127_a(ARMOR_TOUGHNESS_MODIFIER_UUID) == null) {
                        this.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111121_a(
                            new AttributeModifier(ARMOR_TOUGHNESS_MODIFIER_UUID, "Armor toughness", toughnessValue, 0));
                    }
                }
            }
        }
    }

    private double getArmorValue(ItemStack stack) {
        if (stack.func_77973_b() instanceof ItemArmor) {
            return ((ItemArmor) stack.func_77973_b()).field_77879_b;
        }
        return 0;
    }

    private double getArmorToughness(ItemStack stack) {
        if (stack.func_77973_b() instanceof ItemArmor) {
            return ((ItemArmor) stack.func_77973_b()).field_189415_e;
        }
        return 0;
    }

    private void applyArmorEffects() {
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            ItemStack stack = this.func_184582_a(slot);
            if (!stack.func_190926_b() && stack.func_77948_v()) {
                if (EnchantmentHelper.func_77506_a(Enchantments.field_92091_k, stack) > 0) {
                    this.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 200, 1));
                }
            }
        }
    }

    @Override
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e);
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0D);
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.25D);
        this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(2.0D);
    }

    @Override
    public boolean func_70097_a(DamageSource source, float amount) {
        if (source.func_76347_k()) {
            amount *= 2.0F; 
        }

        if (source.func_76346_g() instanceof EntityPlayer) {
            EntityPlayer attacker = (EntityPlayer) source.func_76346_g();
            if (this.isOwner(attacker)) {
                return super.func_70097_a(source, amount); 
            }
        }

        return super.func_70097_a(source, amount);
    }

    @Override
    public void func_70604_c(@Nullable EntityLivingBase livingBase) {
        if (livingBase instanceof EntityPlayer && this.isOwner((EntityPlayer) livingBase)) {
            return;
        }
        super.func_70604_c(livingBase);
    }

    @Override
    public boolean func_70652_k(Entity entityIn) {
        if (entityIn instanceof EntityPlayer && this.isOwner((EntityPlayer) entityIn)) {
            return false;
        }

        float attackDamage = (float) this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
        ItemStack heldItem = this.func_184614_ca();

        if (!heldItem.func_190926_b() && heldItem.func_77973_b() instanceof ItemSword) {
            attackDamage += ((ItemSword) heldItem.func_77973_b()).func_150931_i();
        } else if (!heldItem.func_190926_b() && heldItem.func_77973_b() instanceof ItemTool) {
            attackDamage += 4.0F;
        }

        if (!isSRParasitesInstalled()) {
            attackDamage /= 2;
        }

        return entityIn.func_70097_a(DamageSource.func_76358_a(this), attackDamage);
    }

    @Override
    public EnumActionResult func_184199_a(EntityPlayer player, Vec3d vec, EnumHand hand) {
        ItemStack heldItem = player.func_184586_b(hand);
        ItemStack currentItem = this.func_184582_a(EntityEquipmentSlot.MAINHAND);
        boolean isArmor = heldItem.func_77973_b() instanceof ItemArmor;
        EntityEquipmentSlot slot = isArmor ? ((ItemArmor) heldItem.func_77973_b()).field_77881_a : EntityEquipmentSlot.MAINHAND;

        if (!this.field_70170_p.field_72995_K) {
            if (!heldItem.func_190926_b()) {
                if (!currentItem.func_190926_b()) {
                    player.func_191521_c(currentItem);
                }
                this.func_184201_a(slot, heldItem.func_77946_l());
                player.func_184611_a(hand, ItemStack.field_190927_a);
                return EnumActionResult.SUCCESS;
            } else if (heldItem.func_190926_b() && !currentItem.func_190926_b()) {
                player.func_184611_a(hand, currentItem.func_77946_l());
                this.func_184201_a(slot, ItemStack.field_190927_a);
                return EnumActionResult.SUCCESS;
            }
        }
        return EnumActionResult.PASS;
    }

    @Override
    public boolean func_70687_e(PotionEffect potioneffectIn) {
        if (potioneffectIn.func_188419_a() == MobEffects.field_76436_u || potioneffectIn.func_188419_a() == MobEffects.field_82731_v) {
            return false;
        }
        return true;
    }

    @Override
    public void func_70014_b(NBTTagCompound compound) {
        super.func_70014_b(compound);
        if (this.ownerUUID != null) {
            compound.func_74778_a("OwnerUUID", this.ownerUUID.toString());
        }
        ItemStack mainHandItem = this.func_184582_a(EntityEquipmentSlot.MAINHAND);
        if (!mainHandItem.func_190926_b()) {
            compound.func_74782_a("MainHandItem", mainHandItem.func_77955_b(new NBTTagCompound()));
        }
    }

    @Override
    public void func_70037_a(NBTTagCompound compound) {
        super.func_70037_a(compound);
        if (compound.func_74764_b("OwnerUUID")) {
            this.ownerUUID = UUID.fromString(compound.func_74779_i("OwnerUUID"));
        }
        if (compound.func_74764_b("MainHandItem")) {
            ItemStack mainHandItem = new ItemStack(compound.func_74775_l("MainHandItem"));
            this.func_184201_a(EntityEquipmentSlot.MAINHAND, mainHandItem);
        }
    }
}
