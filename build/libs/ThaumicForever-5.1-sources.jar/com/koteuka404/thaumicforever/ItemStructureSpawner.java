package com.koteuka404.thaumicforever;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.util.Constants;

public class ItemStructureSpawner extends Item {

    public ItemStructureSpawner() {
        this.func_77625_d(1);
        this.func_77655_b("structure_spawner");
        this.setRegistryName("structure_spawner");
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K) {
            BlockPos spawnPos = player.func_180425_c().func_177984_a();
            File structureFile = new File(DimensionManager.getCurrentSaveRootDirectory(), "structures/saved_structure.nbt");

            if (!structureFile.exists()) {
                player.func_145747_a(new TextComponentString("Structure file not found!"));
                return new ActionResult<>(EnumActionResult.FAIL, player.func_184586_b(hand));
            }

            try {
                NBTTagCompound structureData = CompressedStreamTools.func_74796_a(new FileInputStream(structureFile));

                spawnBlocks(world, spawnPos, structureData);
                spawnTileEntities(world, spawnPos, structureData);
                spawnEntities(world, spawnPos, structureData);

                player.func_145747_a(new TextComponentString("Structure spawned successfully!"));
            } catch (IOException e) {
                player.func_145747_a(new TextComponentString("Failed to read structure file: " + e.getMessage()));
            }
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }

    private void spawnBlocks(World world, BlockPos spawnPos, NBTTagCompound structureData) {
        NBTTagList blockList = structureData.func_150295_c("blocks", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < blockList.func_74745_c(); i++) {
            NBTTagCompound blockData = blockList.func_150305_b(i);
            int x = blockData.func_74762_e("x");
            int y = blockData.func_74762_e("y");
            int z = blockData.func_74762_e("z");
            String blockName = blockData.func_74779_i("block");

            IBlockState state = net.minecraft.block.Block.func_149684_b(blockName).func_176223_P();
            BlockPos blockPos = spawnPos.func_177982_a(x, y, z);
            world.func_180501_a(blockPos, state, 3);
        }
    }

    private void spawnTileEntities(World world, BlockPos spawnPos, NBTTagCompound structureData) {
        NBTTagList tileEntityList = structureData.func_150295_c("tile_entities", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < tileEntityList.func_74745_c(); i++) {
            NBTTagCompound tileEntityData = tileEntityList.func_150305_b(i);
            int x = tileEntityData.func_74762_e("x");
            int y = tileEntityData.func_74762_e("y");
            int z = tileEntityData.func_74762_e("z");

            BlockPos tilePos = spawnPos.func_177982_a(x, y, z);
            TileEntity tileEntity = world.func_175625_s(tilePos);
            if (tileEntity != null) {
                tileEntity.func_145839_a(tileEntityData);
                tileEntity.func_70296_d();
            }
        }
    }

    private void spawnEntities(World world, BlockPos spawnPos, NBTTagCompound structureData) {
        NBTTagList entityList = structureData.func_150295_c("entities", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < entityList.func_74745_c(); i++) {
            NBTTagCompound entityData = entityList.func_150305_b(i);
            double x = entityData.func_74769_h("x") + spawnPos.func_177958_n();
            double y = entityData.func_74769_h("y") + spawnPos.func_177956_o();
            double z = entityData.func_74769_h("z") + spawnPos.func_177952_p();

            Entity entity = EntityList.func_75615_a(entityData, world);
            if (entity != null) {
                entity.func_70107_b(x, y, z);
                world.func_72838_d(entity);
            }
        }
    }

    @Override
    public boolean func_77636_d(ItemStack stack) {
        return true;
    }
}
