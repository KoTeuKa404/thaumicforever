package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class BlockTimeSlow extends Block {

    public BlockTimeSlow() {
        super(Material.field_151576_e);
        func_149663_c("time_slow");
        setRegistryName("time_slow");
        func_149711_c(2.0F);
        func_149752_b(10.0F);
    }

    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TileEntityTimeSlow();
    }
    @Override
    public Item func_180660_a(IBlockState state, Random rand, int fortune) {
        return Item.func_150898_a(this); // Блок буде випадати сам як предмет
    }
}
