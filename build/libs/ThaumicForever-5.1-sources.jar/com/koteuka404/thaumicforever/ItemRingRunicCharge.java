package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;

public class ItemRingRunicCharge extends Item implements IBauble {

    public ItemRingRunicCharge() {
        this.func_77655_b("ring_runic_charge");
        this.setRegistryName("ring_runic_charge");
        this.func_77625_d(1);
        this.func_77637_a(CreativeTabs.field_78040_i); 
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.RING;
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
        if (player instanceof EntityPlayer) {
            EntityPlayer entityPlayer = (EntityPlayer) player;
            entityPlayer.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 200, 0, true, true));
            entityPlayer.func_70690_d(new PotionEffect(MobEffects.field_76426_n, 200, 0, true, true));
        }
    }
    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }
}
