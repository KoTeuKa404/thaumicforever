package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockMechanismAmplifier extends Block {

    public static final PropertyDirection FACING = PropertyDirection.func_177712_a("facing", EnumFacing.Plane.HORIZONTAL);
    public static final PropertyBool ENABLED = PropertyBool.func_177716_a("enabled");

    public BlockMechanismAmplifier() {
        super(Material.field_151575_d);
        setRegistryName("thaumicforever", "mechanism_amplifier");
        func_149663_c("mechanism_amplifier");
        func_149672_a(SoundType.field_185848_a);
        func_149711_c(2.5F);
        func_180632_j(this.field_176227_L.func_177621_b()
                .func_177226_a(FACING, EnumFacing.NORTH)
                .func_177226_a(ENABLED, false));
    }

    @Override
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer(this, FACING, ENABLED);
    }

    @Override
    public IBlockState func_176203_a(int meta) {
        EnumFacing facing = EnumFacing.func_176731_b(meta & 3);
        boolean enabled = (meta & 4) != 0;
        return this.func_176223_P().func_177226_a(FACING, facing).func_177226_a(ENABLED, enabled);
    }

    @Override
    public int func_176201_c(IBlockState state) {
        int meta = state.func_177229_b(FACING).func_176736_b();
        if (state.func_177229_b(ENABLED)) {
            meta |= 4;
        }
        return meta;
    }

    @Override
    public IBlockState func_180642_a(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a(FACING, placer.func_174811_aO().func_176734_d()).func_177226_a(ENABLED, false);
    }

    @Override
    public boolean func_149662_c(IBlockState state) {
        return false;
    }

    @Override
    public boolean func_149686_d(IBlockState state) {
        return false;
    }

    @Override
    public EnumBlockRenderType func_149645_b(IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }

    @Override
    public void func_189540_a(IBlockState state, World world, BlockPos pos, Block blockIn, BlockPos fromPos) {
        boolean isPowered = world.func_175640_z(pos);
        if (state.func_177229_b(ENABLED) != isPowered) {
            world.func_180501_a(pos, state.func_177226_a(ENABLED, isPowered), 3);
        }
    }

    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TileMechanismAmplifier();
    }

}
