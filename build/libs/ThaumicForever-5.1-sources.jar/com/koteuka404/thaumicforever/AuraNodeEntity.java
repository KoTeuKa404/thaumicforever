package com.koteuka404.thaumicforever;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import thaumcraft.api.aura.AuraHelper;
import thaumcraft.api.items.ItemsTC;

public class AuraNodeEntity extends Entity {
    private static final float MAX_AURA = 300.0f; 
    private static final float INCREMENT_AMOUNT = 5.0f; 
    private static final int CHUNK_RADIUS = 3;
    private static final int TICKS_PER_SECOND = 20; 
    private int tickCounter = 0; 

    public AuraNodeEntity(World world) {
        super(world);
        this.func_70105_a(0.6F, 0.6F); // Установка розміру сутності
    }

    @Override
    public void func_70071_h_() {
        super.func_70071_h_();

        tickCounter++;

        if (tickCounter >= TICKS_PER_SECOND) {
            tickCounter = 0;
            increaseAura();
        }
    }

    private void increaseAura() {
        BlockPos nodePos = this.func_180425_c();

        for (int xOffset = -CHUNK_RADIUS * 16; xOffset <= CHUNK_RADIUS * 16; xOffset += 16) {
            for (int zOffset = -CHUNK_RADIUS * 16; zOffset <= CHUNK_RADIUS * 16; zOffset += 16) {
                BlockPos pos = nodePos.func_177982_a(xOffset, 0, zOffset);
                float currentVis = AuraHelper.getVis(field_70170_p, pos);

                if (currentVis < MAX_AURA) {
                    float increaseAmount = Math.min(INCREMENT_AMOUNT, MAX_AURA - currentVis);
                    AuraHelper.addVis(field_70170_p, pos, increaseAmount);
                }
            }
        }
    }

    @Override
    protected void func_70088_a() {
    }

    @Override
    protected void func_70037_a(NBTTagCompound compound) {
    }

    @Override
    protected void func_70014_b(NBTTagCompound compound) {
    }

    @Override
    public boolean func_184230_a(EntityPlayer player, EnumHand hand) {
        if (!field_70170_p.field_72995_K) {
            System.out.println("Interaction triggered");

            ItemStack heldItem = player.func_184586_b(hand);
            if (!heldItem.func_190926_b() && heldItem.func_77973_b() == ItemsTC.phial) {
                System.out.println("Player is holding a valid phial");

                // Створюємо новий предмет AuraPhial
                ItemStack auraPhial = new ItemStack(ModItems.AuraPhial);
                NBTTagCompound nbt = new NBTTagCompound();
                nbt.func_74776_a("storedAura", MAX_AURA);
                auraPhial.func_77982_d(nbt);

                // Замінюємо предмет у руці
                heldItem.func_190918_g(1); // Зменшуємо кількість порожніх phial
                if (!player.func_191521_c(auraPhial)) {
                    this.func_70099_a(auraPhial, 0.5F); // Якщо інвентар повний, скидаємо предмет
                }

                System.out.println("Exchanged empty phial for aura phial");
                return true;
            } else if (!heldItem.func_190926_b() && heldItem.func_77973_b() == ModItems.AuraPhial) {
                System.out.println("Player is holding an aura phial");

                // Логіка взаємодії із заповненим aura phial
                NBTTagCompound nbt = heldItem.func_77978_p();
                if (nbt != null && nbt.func_74764_b("storedAura")) {
                    float storedAura = nbt.func_74760_g("storedAura");
                    System.out.println("Stored aura: " + storedAura);

                    // Додаємо ауру в локацію
                    AuraHelper.addVis(field_70170_p, this.func_180425_c(), storedAura);

                    // Забираємо використаний предмет
                    heldItem.func_190918_g(1);
                    System.out.println("Aura returned to the node");
                }

                return true;
            } else {
                System.out.println("Player is not holding a valid phial");
            }
        }
        return super.func_184230_a(player, hand);
    }

    @Override
    public boolean func_70067_L() {
        return true; // Дозволяємо взаємодію з сутністю
    }
}
