package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import thaumcraft.client.fx.FXDispatcher;

public class EldritchEyeAmulet extends Item implements IBauble {

    public EldritchEyeAmulet() {
        super();
        this.func_77625_d(1);
        this.func_77655_b("eldritch_eye_amulet");
        this.setRegistryName("eldritch_eye_amulet");
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET;
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
        if (player instanceof EntityPlayer && player.field_70170_p.field_72995_K) {
            World world = player.field_70170_p;
            float x = (float)(player.field_70165_t + (player.func_70681_au().nextFloat() - player.func_70681_au().nextFloat()) * 0.2f);
            float z = (float)(player.field_70161_v + (player.func_70681_au().nextFloat() - player.func_70681_au().nextFloat()) * 0.2f);
            FXDispatcher.INSTANCE.wispFXEG(x, (float)(player.field_70163_u + 0.22 * player.field_70131_O), z, player);
        }
    }
}
