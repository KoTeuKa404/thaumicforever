package com.koteuka404.thaumicforever;

import java.io.File;
import java.io.FileOutputStream;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.template.Template;
import net.minecraft.world.gen.structure.template.TemplateManager;

public class ItemStructureSaver extends Item {
    private BlockPos firstCorner = null;
    private BlockPos secondCorner = null;

    public ItemStructureSaver() {
        this.func_77625_d(1);
        this.func_77655_b("structure_saver");
        this.setRegistryName("structure_saver");
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K) {
            if (player.func_70093_af()) {
                secondCorner = player.func_180425_c();
                player.func_145747_a(new TextComponentString("Second corner set at: " + secondCorner));
                if (firstCorner != null) {
                    saveStructure(world, player);
                }
            } else {
                firstCorner = player.func_180425_c();
                player.func_145747_a(new TextComponentString("First corner set at: " + firstCorner));
            }
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }

    private void saveStructure(World world, EntityPlayer player) {
        if (firstCorner == null || secondCorner == null) {
            player.func_145747_a(new TextComponentString("Both corners must be set to save the structure!"));
            return;
        }

        int minX = Math.min(firstCorner.func_177958_n(), secondCorner.func_177958_n());
        int minY = Math.min(firstCorner.func_177956_o(), secondCorner.func_177956_o());
        int minZ = Math.min(firstCorner.func_177952_p(), secondCorner.func_177952_p());
        int maxX = Math.max(firstCorner.func_177958_n(), secondCorner.func_177958_n());
        int maxY = Math.max(firstCorner.func_177956_o(), secondCorner.func_177956_o());
        int maxZ = Math.max(firstCorner.func_177952_p(), secondCorner.func_177952_p());

        BlockPos startPos = new BlockPos(minX, minY, minZ);
        BlockPos size = new BlockPos(maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1);

        MinecraftServer server = world.func_73046_m();
        if (server == null) {
            player.func_145747_a(new TextComponentString("Failed to access Minecraft server."));
            return;
        }

        TemplateManager templateManager = world.func_72860_G().func_186340_h();
        Template template = new Template();

        try {
            // Capture blocks from the world into the template
            template.func_186254_a(world, startPos, size, true, null);

            // Define the name and location for the template
            ResourceLocation templateName = new ResourceLocation("thaumicforever", "saved_structure");

            // Save the Template
            File saveDir = new File(server.func_71218_a(0).func_72860_G().func_75765_b(), "structures");
            if (!saveDir.exists() && !saveDir.mkdirs()) {
                player.func_145747_a(new TextComponentString("Failed to create structures directory!"));
                return;
            }

            File structureFile = new File(saveDir, templateName.func_110623_a() + ".nbt");

            // Write the structure to a file
            NBTTagCompound nbt = template.func_189552_a(new NBTTagCompound());
            try (FileOutputStream fos = new FileOutputStream(structureFile)) {
                CompressedStreamTools.func_74799_a(nbt, fos);
            }

            player.func_145747_a(new TextComponentString("Structure saved successfully as: " + structureFile.getAbsolutePath()));
        } catch (Exception e) {
            player.func_145747_a(new TextComponentString("Unexpected error occurred: " + e.getMessage()));
            e.printStackTrace();
        }

        firstCorner = null;
        secondCorner = null;
    }

    @Override
    public boolean func_77636_d(ItemStack stack) {
        return true;
    }
}
