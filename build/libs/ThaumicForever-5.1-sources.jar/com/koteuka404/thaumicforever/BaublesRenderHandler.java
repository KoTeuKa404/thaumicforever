package com.koteuka404.thaumicforever;

import baubles.api.BaublesApi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class BaublesRenderHandler {

    @SubscribeEvent
    public void onRenderPlayer(RenderPlayerEvent.Post event) {
        EntityPlayer player = event.getEntityPlayer();
        
        ItemStack amuletStack = BaublesApi.getBaublesHandler(player).getStackInSlot(0);

        if (!amuletStack.func_190926_b() && amuletStack.func_77973_b() instanceof ItemZombieHeartAmulet) {
            renderAmuletOnPlayer(amuletStack, player, event);
        }
    }

    private void renderAmuletOnPlayer(ItemStack amuletStack, EntityPlayer player, RenderPlayerEvent.Post event) {
        GlStateManager.func_179094_E();

        event.getRenderer().func_177087_b().field_78115_e.func_78794_c(0.0625F);

        GlStateManager.func_179109_b(0F, 0.7F, 0.3F);

        IBakedModel model = Minecraft.func_71410_x().func_175599_af().func_184393_a(amuletStack, player.field_70170_p, player);

        Minecraft.func_71410_x().func_175599_af().func_180454_a(amuletStack, model);

        GlStateManager.func_179121_F();
    }
}
