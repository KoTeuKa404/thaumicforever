package com.koteuka404.thaumicforever;

import java.util.List;

import org.lwjgl.opengl.GL11;

import baubles.api.BaubleType;
import baubles.api.BaublesApi;
import baubles.api.IBauble;
import baubles.api.render.IRenderBauble;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import thaumcraft.api.items.IGoggles;
import thaumcraft.api.items.IRevealer;
import thaumcraft.api.items.IVisDiscountGear;
import thaumcraft.client.lib.UtilsFX;

import baubles.api.render.IRenderBauble.RenderType;
import net.minecraft.item.ItemArmor.ArmorMaterial;

public class ItemAquareiaGoggles extends ItemArmor implements IRevealer, IGoggles, IVisDiscountGear, IBauble, IRenderBauble {

    public ItemAquareiaGoggles(String name, ArmorMaterial mat) {
        super(mat, 3, EntityEquipmentSlot.HEAD);
        this.func_77655_b("aquareia_goggles");
        this.setRegistryName("aquareia_goggles");
        this.func_77625_d(1);
        this.func_77637_a(CreativeTabs.field_78040_i);
    }

    @Override
    public boolean showIngamePopups(ItemStack itemstack, EntityLivingBase player) {
        return true;
    }

    @Override
    public int getVisDiscount(ItemStack stack, EntityPlayer player) {
        return 15;
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.HEAD;
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }

    @Override
    public boolean showNodes(ItemStack itemstack, EntityLivingBase player) {
        return true;
    }

    @SideOnly(Side.CLIENT)
    public String getArmorTexture(ItemStack stack, Entity entity, EntityEquipmentSlot slot, String type) {
        return "thaumicforever:textures/items/aquareia_goggles_e.png";
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void onPlayerBaubleRender(ItemStack itemStack, EntityPlayer entityPlayer, RenderType renderType, float v) {
        if (renderType == RenderType.HEAD) {
            boolean armor = entityPlayer.func_184582_a(EntityEquipmentSlot.HEAD) != null;

            Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation("thaumicforever", "textures/items/aquareia_goggles_b.png"));

            IRenderBauble.Helper.translateToHeadLevel(entityPlayer);
            IRenderBauble.Helper.translateToFace();
            IRenderBauble.Helper.defaultTransforms();

            GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.func_179137_b(-0.5D, -0.5D, 0.12D);
            UtilsFX.renderTextureIn3D(0.0F, 0.0F, 1.0F, 1.0F, 16, 26, 0.1F);

            Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation("thaumicforever", "textures/items/aquareia_goggles.png"));

            int frameCount = 8;
            int frameHeight = 16;
            int textureHeight = 128;
            int currentFrame = (int)(Minecraft.func_71410_x().field_71441_e.func_82737_E() / 5 % frameCount);
            float minV = (float)(currentFrame * frameHeight) / (float)textureHeight;
            float maxV = (float)((currentFrame + 1) * frameHeight) / (float)textureHeight;

            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.5F, 1.0F, 0.02F);
            GlStateManager.func_179114_b(180.0F, 1.0F, 0.0F, 0.0F);

            Tessellator tessellator = Tessellator.func_178181_a();
            BufferBuilder buffer = tessellator.func_178180_c();
            buffer.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181707_g);

            buffer.func_181662_b(-0.5D, 0.0D, 0.0D).func_187315_a(0.0F, minV).func_181675_d();
            buffer.func_181662_b(0.5D, 0.0D, 0.0D).func_187315_a(1.0F, minV).func_181675_d();
            buffer.func_181662_b(0.5D, 1.0D, 0.0D).func_187315_a(1.0F, maxV).func_181675_d();
            buffer.func_181662_b(-0.5D, 1.0D, 0.0D).func_187315_a(0.0F, maxV).func_181675_d();
            tessellator.func_78381_a();

            GlStateManager.func_179121_F();
        }
    }

    @SideOnly(Side.CLIENT)
    public void func_77624_a(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
        tooltip.add("\u00A79" + "\u00A7o" + "Special goggles that reveal hidden things...");
        super.func_77624_a(stack, worldIn, tooltip, flagIn);
    }

    public static boolean shouldRenderHud(EntityPlayer player) {
        return player.field_71071_by.func_70440_f(3).func_77973_b() instanceof ItemAquareiaGoggles
                || BaublesApi.isBaubleEquipped(player, ModItems.ItemAquareiaGoggles) != -1;
    }
}
