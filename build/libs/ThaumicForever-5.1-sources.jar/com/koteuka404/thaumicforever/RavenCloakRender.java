package com.koteuka404.thaumicforever;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RavenCloakRender extends RenderLiving<EntityLiving> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("thaumicforever:textures/entity/raven_cloak3.png");

    public RavenCloakRender(RenderManager renderManager) {
        super(renderManager, new RavenCloakModel(), 0.5f);
    }

    @Override
    protected ResourceLocation func_110775_a(EntityLiving entity) {
        return TEXTURE;
    }

    @Override
    protected void func_77041_b(EntityLiving entity, float partialTickTime) {
        // Тестування масштабування і зміщення
        GlStateManager.func_179094_E();
        GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F); // зменшення моделі для тестування
        GlStateManager.func_179109_b(0.0F, 1.5F, 0.0F); // зміщення для тестування

        super.func_77041_b(entity, partialTickTime);
        GlStateManager.func_179121_F();
    }
}
