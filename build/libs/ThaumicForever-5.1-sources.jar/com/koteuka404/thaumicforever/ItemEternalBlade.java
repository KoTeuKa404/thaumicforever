package com.koteuka404.thaumicforever;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import net.minecraft.item.Item.ToolMaterial;

public class ItemEternalBlade extends ItemSword {

    private static final long COOLDOWN_TIME = 45 * 1000; // 45 секунд у мілісекундах
    private static final float ATTACK_DAMAGE = 23.0F;    // Урон меча
    private static final float ATTACK_SPEED = -2.34F;    // Швидкість атаки меча
    private final Multimap<String, AttributeModifier> attributeModifiers;
    private long lastUseTime = 0;

    public ItemEternalBlade() {
        super(ToolMaterial.DIAMOND);
        setRegistryName("eternal_blade");
        func_77655_b("eternal_blade");
        func_77625_d(1);

        // Налаштування атрибутів атаки
        ImmutableMultimap.Builder<String, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(SharedMonsterAttributes.field_111264_e.func_111108_a(),
                new AttributeModifier(field_111210_e, "Weapon modifier", ATTACK_DAMAGE, 0));
        builder.put(SharedMonsterAttributes.field_188790_f.func_111108_a(),
                new AttributeModifier(field_185050_h, "Weapon modifier", ATTACK_SPEED, 0));
        this.attributeModifiers = builder.build();
    }

    @Override
public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
    if (!world.field_72995_K) {
        long currentTime = System.currentTimeMillis();

        if (currentTime - lastUseTime >= COOLDOWN_TIME) {
            lastUseTime = currentTime;

            // Викликаємо ефект активації
            CustomEventHandler.startParticleWave(world, player);

            // Відтворення звуку
            world.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v,
                    net.minecraft.init.SoundEvents.field_187616_bj,
                    net.minecraft.util.SoundCategory.PLAYERS,
                    1.0F, 1.0F); // Гучність 1.0F, висота звуку 1.0F

            return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
        } else {
            // Повідомлення про те, що меч ще на кулдауні
            long remainingTime = (COOLDOWN_TIME - (currentTime - lastUseTime)) / 1000;
            player.func_146105_b(new TextComponentString(
                    TextFormatting.RED + "Eternal Blade is on cooldown. Wait " + remainingTime + " seconds."), true);
        }
    }
    return new ActionResult<>(EnumActionResult.PASS, player.func_184586_b(hand));
}


    @Override
    public void func_77663_a(ItemStack stack, World world, Entity entity, int itemSlot, boolean isSelected) {
        super.func_77663_a(stack, world, entity, itemSlot, isSelected);

        // Перевірка: чи це гравець, і чи меч знаходиться в головній руці
        if (world.field_72995_K && entity instanceof EntityPlayer && isSelected) {
            EntityPlayer player = (EntityPlayer) entity;

            // Перевірка: меч у головній руці
            if (player.func_184614_ca() == stack) {
                double handOffsetX = -0.4; // Відкориговане зміщення для правої сторони
                double handOffsetY = 1.0;  // Висота руки
                double handOffsetZ = -0.4;  // Зміщення вперед від гравця

                float yaw = (float) Math.toRadians(player.field_70177_z);

                // Розрахунок координат партиклів біля руки
                double particleX = player.field_70165_t + handOffsetZ * Math.sin(yaw) + handOffsetX * Math.cos(yaw);
                double particleY = player.field_70163_u + handOffsetY;
                double particleZ = player.field_70161_v - handOffsetZ * Math.cos(yaw) + handOffsetX * Math.sin(yaw);

                // Генерація частинок
                for (int i = 0; i < 2; i++) {
                    double offsetX = (world.field_73012_v.nextDouble() - 0.5) * 0.1;
                    double offsetY = (world.field_73012_v.nextDouble() - 0.5) * 0.1;
                    double offsetZ = (world.field_73012_v.nextDouble() - 0.5) * 0.1;

                    world.func_175688_a(EnumParticleTypes.FLAME,
                            particleX + offsetX,
                            particleY + offsetY,
                            particleZ + offsetZ,
                            0, 0, 0);
                }
            }
        }
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack) {
        // Повертаємо модифікатори атрибутів лише для головної руки
        return slot == EntityEquipmentSlot.MAINHAND ? this.attributeModifiers : super.getAttributeModifiers(slot, stack);
    }

    @Override
    public boolean func_77644_a(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        stack.func_77972_a(1, attacker); // Зменшення міцності предмета

        // Підпалюємо ціль
        target.func_70015_d(5); // Підпал триває 5 секунд

        return true;
    }

    @Override
    public String func_77653_i(ItemStack stack) {
        return TextFormatting.DARK_RED + "Eternal Blade";
    }
}
