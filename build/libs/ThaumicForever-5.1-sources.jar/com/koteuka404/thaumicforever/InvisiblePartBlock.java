package com.koteuka404.thaumicforever;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class InvisiblePartBlock extends Block {

    public InvisiblePartBlock() {
        super(Material.field_151575_d);
        func_149663_c("invisible_part");
        setRegistryName("invisible_part");
        func_149711_c(2.5F);
        func_149752_b(12.5F);
    }

    @Override
    public EnumBlockRenderType func_149645_b(IBlockState state) {
        return EnumBlockRenderType.INVISIBLE; // Робить блок невидимим
    }

    @Override
    public boolean func_149686_d(IBlockState state) {
        return false;
    }

    @Override
    public boolean func_149662_c(IBlockState state) {
        return false;
    }

    @Override
    public boolean func_176196_c(World worldIn, BlockPos pos) {
        return false; // Забороняє ставити блок вручну
    }

    @Override
    public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        // Перенаправляємо взаємодію на основний блок
        for (EnumFacing direction : EnumFacing.field_176754_o) {
            BlockPos possibleMainBlockPos = pos.func_177972_a(direction);
            IBlockState possibleMainBlockState = worldIn.func_180495_p(possibleMainBlockPos);

            if (possibleMainBlockState.func_177230_c() instanceof DoubleTableBlock) {
                return possibleMainBlockState.func_177230_c().func_180639_a(worldIn, possibleMainBlockPos, possibleMainBlockState, playerIn, hand, facing, hitX, hitY, hitZ);
            }
        }
        return false; // Якщо основний блок не знайдено
    }

    @Override
    public void func_180650_b(World worldIn, BlockPos pos, IBlockState state, java.util.Random rand) {
        // Перевіряємо чи існує основний блок
        boolean mainBlockExists = false;

        for (EnumFacing direction : EnumFacing.field_176754_o) {
            BlockPos possibleMainBlockPos = pos.func_177972_a(direction);
            IBlockState possibleMainBlockState = worldIn.func_180495_p(possibleMainBlockPos);

            if (possibleMainBlockState.func_177230_c() instanceof DoubleTableBlock) {
                mainBlockExists = true;
                break;
            }
        }

        // Якщо основний блок відсутній, видаляємо себе
        if (!mainBlockExists) {
            worldIn.func_175698_g(pos);
        }
    }

    @Override
    public void func_189540_a(IBlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos) {
        // Викликаємо перевірку на основний блок при зміні сусіднього блоку
        worldIn.func_175684_a(pos, this, 1);
    }

    @Override
    public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
        for (EnumFacing direction : EnumFacing.field_176754_o) {
            BlockPos possibleMainBlockPos = pos.func_177972_a(direction);
            IBlockState possibleMainBlockState = worldIn.func_180495_p(possibleMainBlockPos);
    
            if (possibleMainBlockState.func_177230_c() instanceof DoubleTableBlock) {
                // Ламаємо основний блок
                worldIn.func_175698_g(possibleMainBlockPos);
    
                // Випадіння стола
                Block.func_180635_a(worldIn, possibleMainBlockPos, new ItemStack(ModBlocks.DOUBLE_TABLE));
                break;
            }
        }
    
        super.func_180663_b(worldIn, pos, state);
    }
    

    @Override
    public boolean removedByPlayer(IBlockState state, World world, BlockPos pos, EntityPlayer player, boolean willHarvest) {
        // Забороняємо дроп при ламанні цього блоку
        world.func_175698_g(pos);
        return false;
    }
     @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }
    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new DoubleTableTileEntity();
    }

    // @Override
    // public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
    //     if (!world.isRemote) {
    //         TileEntity tileEntity = world.getTileEntity(pos);
    //         if (tileEntity instanceof DoubleTableTileEntity) {
    //             player.openGui(ThaumicForever.instance, ModGuiHandler.DOUBLE_TABLE_GUI, world, pos.getX(), pos.getY(), pos.getZ());
    //         }
    //     }
    //     return true;
    // }
}
