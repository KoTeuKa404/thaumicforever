package com.koteuka404.thaumicforever;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class RavenCloakModel extends ModelBase {
	private final ModelRenderer cloac;
	private final ModelRenderer chest;
	private final ModelRenderer right_wing;
	private final ModelRenderer left_wing;
	private final ModelRenderer head;
	private final ModelRenderer right_arm;
	private final ModelRenderer left_arm;
    public float rotateAngleY = 0.0F;
    public float rotateAngleX = 0.0F;

	public RavenCloakModel() {
		field_78090_t = 128;
		field_78089_u = 64;

		cloac = new ModelRenderer(this);
		cloac.func_78793_a(0.0F, 24.0F, 0.0F);
		

		right_wing = new ModelRenderer(this);
		right_wing.func_78793_a(0.0F, -20.0F, 3.0F);
		cloac.func_78792_a(right_wing);
		right_wing.field_78804_l.add(new ModelBox(right_wing, 49, 41, -9.0F, -0.25F, 0.3F, 13, 15, 0, 0.0F, false));
		right_wing.field_78804_l.add(new ModelBox(right_wing, 49, 41, -6.0F, 3.5F, 0.15F, 13, 12, 0, 0.0F, false));
		right_wing.field_78804_l.add(new ModelBox(right_wing, 48, 41, -4.75F, 8.0F, -0.05F, 13, 15, 0, 0.0F, false));

		left_wing = new ModelRenderer(this);
		left_wing.func_78793_a(0.0F, -19.0F, 3.0F);
		cloac.func_78792_a(left_wing);
		left_wing.field_78804_l.add(new ModelBox(left_wing, 48, 41, -4.0F, -1.25F, 0.1F, 13, 14, 0, 0.0F, false));

		head = new ModelRenderer(this);
		head.func_78793_a(0.0F, -19.0F, 0.0F);
		cloac.func_78792_a(head);
		head.field_78804_l.add(new ModelBox(head, 3, 2, -4.5F, -9.5F, -4.2F, 9, 9, 9, 0.0F, false));

		right_arm = new ModelRenderer(this);
		right_arm.func_78793_a(-5.0F, -20.0F, 0.0F);
		cloac.func_78792_a(right_arm);
		right_arm.field_78804_l.add(new ModelBox(right_arm, 59, 23, -3.0F, 0.5F, -2.0F, 3, 11, 4, 1.0F, true));

		left_arm = new ModelRenderer(this);
		left_arm.func_78793_a(5.0F, -20.0F, 0.0F);
		cloac.func_78792_a(left_arm);
		left_arm.field_78804_l.add(new ModelBox(left_arm, 59, 23, 0.0F, 0.5F, -2.0F, 3, 11, 4, 1.0F, false));

		chest = new ModelRenderer(this);
		chest.func_78793_a(0.0F, 0.0F, 0.0F);
		chest.field_78804_l.add(new ModelBox(chest, 78, 7, -4.0F, 5.0F, -0.25F, 8, 12, 3, 0.9F, false));
	}
    // Рендер голови
    public void renderHead(Entity entity, float scale) {
        head.field_78796_g = this.rotateAngleY;
        head.field_78795_f = this.rotateAngleX; 
        head.func_78785_a(scale);
    }

    // Рендер тіла
    public void renderBody(Entity entity, float scale) {
        cloac.func_78785_a(scale);
    }
    public void renderChest(Entity entity, float scale) {
        chest.func_78785_a(scale);

    }
    // Рендер правої руки
    public void renderRightArm(Entity entity, float scale) {
        right_arm.func_78785_a(scale);
    }

    // Рендер лівої руки
    public void renderLeftArm(Entity entity, float scale) {
        left_arm.func_78785_a(scale);
    }

    public void setToPlayerAngles(ModelPlayer modelPlayer, EntityPlayer player) {
    // Прив’язка голови
    head.field_78796_g = modelPlayer.field_78116_c.field_78796_g; 
    head.field_78795_f = modelPlayer.field_78116_c.field_78795_f; 

    // Права рука
    right_arm.field_78795_f = modelPlayer.field_178723_h.field_78795_f; 
    right_arm.field_78796_g = modelPlayer.field_178723_h.field_78796_g;
    right_arm.field_78808_h = modelPlayer.field_178723_h.field_78808_h;
    // Ліва рука
    left_arm.field_78795_f = modelPlayer.field_178724_i.field_78795_f; 
    left_arm.field_78796_g = modelPlayer.field_178724_i.field_78796_g; 
    left_arm.field_78808_h = modelPlayer.field_178724_i.field_78808_h; 

    // Прив’язка тіла
    chest.field_78795_f = modelPlayer.field_78115_e.field_78795_f;
    chest.field_78796_g = modelPlayer.field_78115_e.field_78796_g; 
    chest.field_78808_h = modelPlayer.field_78115_e.field_78808_h;

    // Прив’язка крил до руху тіла
    right_wing.field_78795_f = chest.field_78795_f;
    right_wing.field_78796_g = chest.field_78796_g;
    right_wing.field_78808_h = chest.field_78808_h;

    left_wing.field_78795_f = chest.field_78795_f;
    left_wing.field_78796_g = chest.field_78796_g;
    left_wing.field_78808_h = chest.field_78808_h;

    // // Динамічне зміщення залежно від стану гравця (присів чи ні)
    // float yOffset = player.isSneaking() ? 0.0F : -0.25F;
    // float zOffset = player.isSneaking() ? 0.0F : 0.0F;
    // chest.offsetY = yOffset; // Зміщення тіла вниз
    // chest.offsetZ = zOffset; // Зміщення тіла вперед
    // right_wing.offsetY = yOffset;
    // right_wing.offsetZ = zOffset;
    // left_wing.offsetY = yOffset;
    // left_wing.offsetZ = zOffset;
    // head.offsetY = yOffset;
    // head.offsetZ = zOffset;
    // right_arm.offsetY = yOffset;
    // right_arm.offsetZ = zOffset;
    // left_arm.offsetY = yOffset;
    // left_arm.offsetZ = zOffset;

}


}
