package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import baubles.api.render.IRenderBauble;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

import baubles.api.render.IRenderBauble.RenderType;

public class RavenCloakItem extends Item implements IBauble, IRenderBauble {

    private static final ResourceLocation TEXTURE = new ResourceLocation("thaumicforever:textures/entity/raven_cloak3.png");
    private final RavenCloakModel model;

    public RavenCloakItem() {
        setRegistryName("raven_cloak_bauble");
        func_77655_b("raven_cloak_bauble");
        this.model = new RavenCloakModel();
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.BODY;
    }

    @Override
    public void onPlayerBaubleRender(ItemStack stack, EntityPlayer player, RenderType type, float partialTicks) {
        if (type == RenderType.BODY) {
        GlStateManager.func_179094_E();
        Minecraft.func_71410_x().func_175598_ae().field_78724_e.func_110577_a(TEXTURE);
    
            RenderLivingBase<?> render = (RenderLivingBase<?>) Minecraft.func_71410_x().func_175598_ae().func_78713_a(player);
            if (render != null && render.func_177087_b() instanceof ModelPlayer) {
                ModelPlayer modelPlayer = (ModelPlayer) render.func_177087_b();
    
                boolean isSneaking = player.func_70093_af();
                float yOffset = isSneaking ? -0.0F : -0.25F; 
                float zOffset = isSneaking ? -0.0F : 0.0F;  
                float zOffsetch = isSneaking ? -0.25F : -0.1F;  
                float zOffsetchb = isSneaking ? -0.23F : -0.1F;  
    
                GlStateManager.func_179094_E();
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.0F); 
    
                model.rotateAngleY = modelPlayer.field_78116_c.field_78796_g;
                model.rotateAngleX = modelPlayer.field_78116_c.field_78795_f;
    
                // Рендер голови 
                GlStateManager.func_179094_E();
                float headYOffset = -4.5F + (float) Math.sin(modelPlayer.field_78116_c.field_78795_f) * 1.5F;
                float headZOffset = (float) Math.cos(modelPlayer.field_78116_c.field_78795_f) * -0.5F;
                GlStateManager.func_179109_b(0.0F, headYOffset, headZOffset);
                GlStateManager.func_179114_b((float) Math.toDegrees(modelPlayer.field_78116_c.field_78796_g), 0.0F, 1.0F, 0.0F);
                GlStateManager.func_179114_b((float) Math.toDegrees(modelPlayer.field_78116_c.field_78795_f), 1.0F, 0.0F, 0.0F);
                GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F);
                model.renderHead(player, 1.0F);
                GlStateManager.func_179121_F();
    
                // Повертаємо прозорість 
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    
                // Рендер тулуба
                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b(0.0F, yOffset,zOffsetchb);
                GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F);
                model.renderChest(player, 1.0F);
                GlStateManager.func_179121_F();
    
                model.setToPlayerAngles(modelPlayer, player);
    
                // Рендер всього тіла 
                // GlStateManager.pushMatrix(); // HE PYXATU KOD
                GlStateManager.func_179109_b(0.0F, yOffset, zOffset);
                GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F);
                model.renderBody(player, 1.0F);
                // GlStateManager.popMatrix(); // HE PYXATU KOD
    
                // Рендер правої руки 
                // GlStateManager.pushMatrix(); // HE PYXATU KOD
                GlStateManager.func_179109_b(0.0F, yOffset, zOffsetch);
                GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F);
                // model.renderRightArm(player, 1.0F);/ HE PYXATU KOD
                // GlStateManager.popMatrix(); // HE PYXATU KOD
    
                // Рендер лівої руки 
                // GlStateManager.pushMatrix(); // HE PYXATU KOD
                GlStateManager.func_179109_b(0.0F, yOffset, zOffsetch -0.1F);
                GlStateManager.func_179152_a(0.06F, 0.06F, 0.06F);
                // model.renderLeftArm(player, 1.0F);/ HE PYXATU KOD
                // GlStateManager.popMatrix(); // HE PYXATU KOD
    
                GlStateManager.func_179121_F(); // HE PYXATU KOD
            }
    
            GlStateManager.func_179121_F();
        }
    }
    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
    if (player instanceof EntityPlayer) {
        EntityPlayer entityPlayer = (EntityPlayer) player;

        int lightLevel = player.field_70170_p.func_175699_k(player.func_180425_c());

        if (lightLevel < 6) {
            if (!entityPlayer.func_70644_a(MobEffects.field_76441_p)) {
                entityPlayer.func_70690_d(new PotionEffect(MobEffects.field_76441_p, 200, 0, true, false));
            }
        } else {
            if (entityPlayer.func_70644_a(MobEffects.field_76441_p)) {
                entityPlayer.func_184589_d(MobEffects.field_76441_p);
            }
        }
        }
    }    
} 
    
