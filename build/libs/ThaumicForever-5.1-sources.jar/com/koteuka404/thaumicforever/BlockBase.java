package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

public class BlockBase extends Block {

    public BlockBase(Material material, String name) {
        super(material);
        func_149663_c(name);
        setRegistryName(name);
        func_149711_c(5.0F); 
        func_149752_b(10.0F); 
        setHarvestLevel("pickaxe", 2); 
    }

    @Override
    public Item func_180660_a(IBlockState state, Random rand, int fortune) {
        return Item.func_150898_a(this);
    }

    @Override
    public int func_149745_a(Random random) {
        return 1; 
    }
}
