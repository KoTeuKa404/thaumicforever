package com.koteuka404.thaumicforever;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.gen.IChunkGenerator;

public class VoidWorldProvider extends WorldProvider {

    @Override
    public void func_76572_b() {
        this.field_76578_c = new net.minecraft.world.biome.BiomeProviderSingle(net.minecraft.init.Biomes.field_185440_P);
    }

    @Override
    public DimensionType func_186058_p() {
        return ModDimensions.VOID_DIMENSION;
    }

    @Override
    public boolean func_76567_e() {
        return true;
    }

    @Override
    public boolean func_76569_d() {
        return false;
    }

    @Override
    public int func_76557_i() {
        return 64;
    }

    @Override
    public IChunkGenerator func_186060_c() {
        return new VoidChunkGenerator(this.field_76579_a);
    }

    @Override
    public BlockPos getSpawnPoint() {
        return new BlockPos(0, 64, 0); // Точка спавну для виміру (за замовчуванням)
    }
}
