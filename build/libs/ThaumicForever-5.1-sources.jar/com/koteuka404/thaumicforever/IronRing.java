package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class IronRing extends Item implements IBauble {


    public IronRing() {
        this.func_77655_b("iron_ring");
        this.setRegistryName("iron_ring");
        this.func_77625_d(1);
        this.func_77637_a(CreativeTabs.field_78040_i); 
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.RING;
    }

    
}
