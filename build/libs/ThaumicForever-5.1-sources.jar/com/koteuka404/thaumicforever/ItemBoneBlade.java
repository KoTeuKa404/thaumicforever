package com.koteuka404.thaumicforever;

import java.util.List;

import javax.annotation.Nullable;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import net.minecraft.item.Item.ToolMaterial;

public class ItemBoneBlade extends ItemSword {

    private static final float BASE_ATTACK_DAMAGE = 5.5F;
    private static final float ATTACK_SPEED = 1.8F;
    private static final float SKELETON_BONUS_DAMAGE = 5.5F;

    private final Multimap<String, AttributeModifier> attributeModifiers;

    public ItemBoneBlade() {
        super(ToolMaterial.IRON);
        setRegistryName("bone_blade");
        func_77655_b("bone_blade");
        func_77625_d(1);

        // Налаштування атрибутів меча
        ImmutableMultimap.Builder<String, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", BASE_ATTACK_DAMAGE, 0));
        builder.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", ATTACK_SPEED, 0));
        this.attributeModifiers = builder.build();
    }

    @Override
    public boolean func_77644_a(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        String entityName = target.func_70005_c_().toLowerCase(); // Отримуємо назву моба
        if (entityName.contains("skelet")) { // Перевірка на "skelet" у назві
            // Додатковий урон для всіх скелетів
            float totalDamage = BASE_ATTACK_DAMAGE + SKELETON_BONUS_DAMAGE;
            target.func_70097_a(DamageSource.func_76358_a(attacker), totalDamage);
        }
        stack.func_77972_a(1, attacker); // Знос предмета при використанні
        return true;
    }

    @Override
    public String func_77653_i(ItemStack stack) {
        return TextFormatting.GRAY + "Bone Blade";
    }

    @Override
    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack) {
        return slot == EntityEquipmentSlot.MAINHAND ? this.attributeModifiers : super.getAttributeModifiers(slot, stack);
    }

    @Override
    public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
        super.func_77624_a(stack, worldIn, tooltip, flagIn);
        tooltip.add(TextFormatting.DARK_PURPLE + "Gives special damage to any skeleton"); // Додає текст до опису
    }
}
