package com.koteuka404.thaumicforever;

import io.netty.buffer.ByteBuf;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import thaumcraft.api.aspects.AspectList;

public class PacketClickLupa implements IMessage {
    private BlockPos pos;

    public PacketClickLupa() {}

    public PacketClickLupa(BlockPos pos) {
        this.pos = pos;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        this.pos = new BlockPos(buf.readInt(), buf.readInt(), buf.readInt());
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(pos.func_177958_n());
        buf.writeInt(pos.func_177956_o());
        buf.writeInt(pos.func_177952_p());
    }

   public static class Handler implements IMessageHandler<PacketClickLupa, IMessage> {
    @Override
public IMessage onMessage(PacketClickLupa message, MessageContext ctx) {
    ctx.getServerHandler().field_147369_b.func_71121_q().func_152344_a(() -> {
        TileEntity tileEntity = ctx.getServerHandler().field_147369_b.field_70170_p.func_175625_s(message.pos);
        if (tileEntity instanceof DoubleTableTileEntity) {
            DoubleTableTileEntity table = (DoubleTableTileEntity) tileEntity;

            // Оновлюємо аспекти
            table.updateAspectsFromInventory();

            // Відправляємо оновлені аспекти клієнту
            AspectList updatedAspects = table.getStoredAspects();
            ThaumicForever.network.sendTo(
                new PacketSyncAspects(message.pos, updatedAspects),
                ctx.getServerHandler().field_147369_b
            );
        }
    });
    return null;
}

    
}

}
