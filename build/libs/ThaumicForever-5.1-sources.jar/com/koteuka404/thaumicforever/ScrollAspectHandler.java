package com.koteuka404.thaumicforever;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;

public class ScrollAspectHandler {

    /**
     * Метод для отримання аспектів зі скролу.
     * @param scrollItemStack ItemStack скролу.
     * @return AspectList з аспектами, або null, якщо аспекти не знайдено.
     */
    public static AspectList getAspectsFromScroll(ItemStack scrollItemStack) {
        if (scrollItemStack == null || scrollItemStack.func_190926_b()) {
            System.out.println("Скрол порожній.");
            return null;
        }

        if (!scrollItemStack.func_77942_o()) {
            System.out.println("Скрол не має тегів.");
            return null;
        }

        NBTTagCompound tag = scrollItemStack.func_77978_p();
        if (tag != null && tag.func_74764_b("aspects")) {
            AspectList aspects = new AspectList();
            aspects.readFromNBT(tag.func_74775_l("aspects"));

            // Логування отриманих аспектів
            System.out.println("Отримані аспекти зі скролу:");
            for (Aspect aspect : aspects.getAspects()) {
                System.out.println(" - " + aspect.getName() + ": " + aspects.getAmount(aspect));
            }

            return aspects;
        } else {
            System.out.println("Скрол не містить аспектів.");
        }

        return null;
    }

    /**
     * Метод для збереження оновлених аспектів у скрол.
     * @param scrollItemStack ItemStack скролу.
     * @param aspects AspectList, який потрібно зберегти.
     */
    public static void saveAspectsToScroll(ItemStack scrollItemStack, AspectList aspects) {
        if (scrollItemStack == null || scrollItemStack.func_190926_b() || aspects == null) {
            System.out.println("Неможливо зберегти аспекти, оскільки скрол або аспекти порожні.");
            return;
        }

        if (!scrollItemStack.func_77942_o()) {
            scrollItemStack.func_77982_d(new NBTTagCompound());
        }

        NBTTagCompound tag = scrollItemStack.func_77978_p();
        NBTTagCompound aspectCompound = new NBTTagCompound();
        aspects.writeToNBT(aspectCompound);

        tag.func_74782_a("aspects", aspectCompound);

        System.out.println("Аспекти успішно збережено у скрол:");
        for (Aspect aspect : aspects.getAspects()) {
            System.out.println(" - " + aspect.getName() + ": " + aspects.getAmount(aspect));
        }
    }
}
