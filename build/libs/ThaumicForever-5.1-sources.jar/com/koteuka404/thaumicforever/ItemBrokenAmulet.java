package com.koteuka404.thaumicforever;

import net.minecraft.item.Item;

public class ItemBrokenAmulet extends Item {

    public ItemBrokenAmulet() {
        func_77655_b("broken_amulet");
        setRegistryName("broken_amulet");
        func_77625_d(1); 
    }
}
