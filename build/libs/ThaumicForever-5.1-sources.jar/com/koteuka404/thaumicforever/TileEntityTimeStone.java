package com.koteuka404.thaumicforever;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TileEntityTimeStone extends TileEntity implements ITickable {

    private static final int RADIUS = 3;
    private static final int BONUS_TICKS = 3;

    private static final Set<TileEntity> processedTiles = new HashSet<>(); // Відслідковуємо оброблені TileEntity
    private static final List<TileEntityTimeStone> activeTimeStones = new ArrayList<>(); // Відслідковуємо всі TimeStone
    private static final ThreadLocal<Integer> tickDepth = ThreadLocal.withInitial(() -> 0);

    @Override
    public void onLoad() {
        if (!field_145850_b.field_72995_K) {
            activeTimeStones.add(this); // Додаємо блок до списку активних
        }
    }

    @Override
    public void onChunkUnload() {
        if (!field_145850_b.field_72995_K) {
            activeTimeStones.remove(this); // Видаляємо блок зі списку активних
        }
    }

    @Override
    public void func_145843_s() {
        if (!field_145850_b.field_72995_K) {
            activeTimeStones.remove(this); // Видаляємо блок, якщо він зникає
        }
        super.func_145843_s();
    }

    @Override
    public void func_73660_a() {
        if (!field_145850_b.field_72995_K) {
            int depth = tickDepth.get();
            if (depth > 10) { // Ліміт глибини рекурсій
                return;
            }
            tickDepth.set(depth + 1);

            // Дозволяємо вплив тільки першому блоку у списку
            if (activeTimeStones.isEmpty() || activeTimeStones.get(0) != this) {
                tickDepth.set(depth);
                return; // Цей блок не активний
            }

            processedTiles.clear(); // Очищаємо перед початком нового циклу
            AxisAlignedBB area = new AxisAlignedBB(field_174879_c.func_177982_a(-RADIUS, -RADIUS, -RADIUS), field_174879_c.func_177982_a(RADIUS, RADIUS, RADIUS));
            speedUpTileEntities(field_145850_b, BONUS_TICKS, area);

            tickDepth.set(depth);
        }
    }

    private void speedUpTileEntities(World world, int bonusTicks, AxisAlignedBB area) {
        for (BlockPos targetPos : BlockPos.func_177980_a(new BlockPos(area.field_72340_a, area.field_72338_b, area.field_72339_c),
                                                       new BlockPos(area.field_72336_d, area.field_72337_e, area.field_72334_f))) {
            TileEntity tile = world.func_175625_s(targetPos);
            if (tile instanceof ITickable && tile != this && !processedTiles.contains(tile)) {
                processedTiles.add(tile); // Додаємо TileEntity до списку оброблених
                for (int i = 0; i < bonusTicks; i++) {
                    ((ITickable) tile).func_73660_a();
                }
            }
        }
    }
}
