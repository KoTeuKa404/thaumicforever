package com.koteuka404.thaumicforever;

import java.util.Random;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntitySkeletonAngry extends EntityMob {

    private int pathRecalculationTimer = 0; 
    private int dodgeCooldown = 0;
    private final Random random = new Random();

    public EntitySkeletonAngry(World worldIn) {
        super(worldIn);
        func_70105_a(0.6F, 1.99F);

        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(25.0D); 
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.23D); 
        this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(5.0D); 
        this.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(35.0D);
        this.func_70606_j(this.func_110138_aP());

        this.func_184644_a(PathNodeType.WATER, -1.0F); 

        if (this.func_70661_as() instanceof PathNavigateGround) {
            PathNavigateGround navigator = (PathNavigateGround) this.func_70661_as();
            navigator.func_179693_d(true);
            navigator.func_179685_e(false);
        }
    }

    @Override
    protected void func_184651_r() {
        this.field_70714_bg.func_75776_a(0, new EntityAISwimming(this));
        this.field_70714_bg.func_75776_a(1, new EntityAIAttackMelee(this, 1.2D, false)); 
        this.field_70714_bg.func_75776_a(2, new EntityAILeapAtTarget(this, 0.4F)); 
        this.field_70714_bg.func_75776_a(3, new EntityAIWanderAvoidWater(this, 0.8D));
        this.field_70714_bg.func_75776_a(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F)); 
        this.field_70714_bg.func_75776_a(6, new EntityAILookIdle(this)); 

        // Цілі атаки
        this.field_70715_bh.func_75776_a(1, new EntityAINearestAttackableTarget<>(this, EntityPlayer.class, true)); 
        this.field_70715_bh.func_75776_a(2, new EntityAIHurtByTarget(this, false)); 
    }

    @Override
    public void func_70636_d() {
        super.func_70636_d();

        EntityPlayer player = this.field_70170_p.func_72890_a(this, 15.0D); 
        if (player != null) {
            double heightDifference = player.field_70163_u - this.field_70163_u;

            if (heightDifference > 0 && heightDifference <= 2.5 && this.field_70123_F) {
                this.func_70683_ar().func_75660_a(); // Примус стрибка
            }

            if (this.func_70032_d(player) < 10.0D) {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.35D);
            } else {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.23D);
            }

            if (this.func_70032_d(player) < 5.0D && random.nextInt(20) == 0) {
                this.func_70683_ar().func_75660_a();
            }

            if (dodgeCooldown == 0 && player.func_184614_ca().func_77973_b() == Items.field_151031_f) {
                if (this.func_70032_d(player) < 15.0D) {
                    dodge();
                    dodgeCooldown = 60;
                }
            } else if (dodgeCooldown > 0) {
                dodgeCooldown--;
            }

            if (!this.func_70661_as().func_75500_f()) {
                pathRecalculationTimer = 0;
            } else {
                pathRecalculationTimer++;
                if (pathRecalculationTimer >= 40) {
                    this.func_70661_as().func_75497_a(player, 1.2D); // Перерахунок шляху
                    pathRecalculationTimer = 0;
                }
            }
        }
    }

    private void dodge() {
        if (random.nextBoolean()) {
            this.field_70159_w += (random.nextDouble() - 0.5) * 0.5;
        } else {
            this.field_70179_y += (random.nextDouble() - 0.5) * 0.5;
        }
    }

    private void callForHelp() {
        for (int i = 0; i < 2; i++) {
            EntitySkeleton helper = new EntitySkeleton(this.field_70170_p);
            helper.func_70107_b(this.field_70165_t + random.nextInt(5) - 2, this.field_70163_u, this.field_70161_v + random.nextInt(5) - 2);
            this.field_70170_p.func_72838_d(helper);
        }
    }

    @Override
    protected void func_184610_a(boolean wasRecentlyHit, int lootingModifier, DamageSource source) {
        func_70099_a(new ItemStack(Items.field_151103_aS), 1.5f);

        if (field_70170_p.field_73012_v.nextInt(100) < 15 + lootingModifier) {
            func_70099_a(new ItemStack(ModItems.Bone), 1.5f);
        }

        super.func_184610_a(wasRecentlyHit, lootingModifier, source);
    }

    @Override
    public boolean func_70652_k(Entity entityIn) {
        // Потужне відкидання при ударі
        boolean success = super.func_70652_k(entityIn);
        if (success && entityIn instanceof EntityLivingBase) {
            double knockbackStrength = 1.0;
            double dx = entityIn.field_70165_t - this.field_70165_t;
            double dz = entityIn.field_70161_v - this.field_70161_v;
            ((EntityLivingBase) entityIn).func_70653_a(this, (float) knockbackStrength, dx, dz);
        }
        return success;
    }
    @Override
    public EnumCreatureAttribute func_70668_bt() {
        return EnumCreatureAttribute.UNDEAD; // Позначає моба як нежить
    }

}
