package com.koteuka404.thaumicforever;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Set;

import net.minecraft.client.resources.AbstractResourcePack;
import net.minecraft.util.ResourceLocation;

public class CustomResourcePack extends AbstractResourcePack {

    public CustomResourcePack(File resourcePackFile) {
        super(resourcePackFile);
    }

    @Override
    protected InputStream func_110591_a(String name) throws IOException {
        if (name.equals("assets/tg/models/block/gemcutter.json")) {
            return new FileInputStream(new File("src/main/resources/assets/tg/models/block/gemcutter.json"));
        }
        return null;
    }

    @Override
    public boolean func_110589_b(ResourceLocation location) {
        return location.func_110624_b().equals("tg") && location.func_110623_a().equals("models/block/gemcutter.json");
    }

    @Override
    public Set<String> func_110587_b() {
        return Collections.singleton("tg");
    }

    @Override
    protected boolean func_110593_b(String name) {
        return name.equals("assets/tg/models/block/gemcutter.json");
    }
}
