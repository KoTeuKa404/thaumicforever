package com.koteuka404.thaumicforever;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.ResourceLocation;

public class ChestGui extends GuiContainer {
    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation(ThaumicForever.MODID, "textures/gui/abandoned_chest.png");
    private final InventoryPlayer playerInventory;
    private final IInventory tileEntity;

    public ChestGui(InventoryPlayer playerInventory, IInventory tileEntity) {
        super(new ContainerAbandonedChest(playerInventory, tileEntity));
        this.playerInventory = playerInventory;
        this.tileEntity = tileEntity;
        this.field_146999_f = 246;  
        this.field_147000_g = 215;  
    }

    @Override
    protected void func_146979_b(int mouseX, int mouseY) {
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(new ResourceLocation(ThaumicForever.MODID, "textures/gui/abandoned_chest.png"));

        int guiLeft = (this.field_146294_l - this.field_146999_f) / 2 + 52;
        int guiTop = (this.field_146295_m - this.field_147000_g) / 2;

        this.func_73729_b(guiLeft, guiTop + 5, 0, 0, this.field_146999_f, this.field_147000_g);
    }
    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }

}
