package com.koteuka404.thaumicforever;

import org.lwjgl.opengl.GL11;

import baubles.api.BaublesApi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.items.ItemsTC;
import thaumcraft.client.lib.UtilsFX;

public class AuraNodeRenderer extends Render<AuraNodeEntity> {
    private static final ResourceLocation[] NODE_TEXTURES = {
        new ResourceLocation("thaumicforever", "textures/misc/aura_1.png"),
        new ResourceLocation("thaumicforever", "textures/misc/aura_2.png"),
        new ResourceLocation("thaumicforever", "textures/misc/aura_3.png")
    };

    public AuraNodeRenderer(RenderManager renderManager) {
        super(renderManager);
    }

    @Override
    public void func_76986_a(AuraNodeEntity entity, double x, double y, double z, float entityYaw, float partialTicks) {
        EntityPlayer player = Minecraft.func_71410_x().field_71439_g;
        boolean isWearingAquareiaGoggles = player.field_71071_by.field_70460_b.get(3).func_77973_b() instanceof ItemAquareiaGoggles 
                                           || (BaublesApi.getBaublesHandler(player) != null 
                                           && BaublesApi.getBaublesHandler(player).getStackInSlot(4).func_77973_b() instanceof ItemAquareiaGoggles);
    
        if (!isWearingAquareiaGoggles) {
            return;
        }
    
        GlStateManager.func_179094_E();
    
        // Зміщення моделі (змініть значення xOffset, yOffset, zOffset)
        double xOffset = 0.5; // Наприклад, зсуваємо вправо
        double yOffset = 0.0; // Не змінюємо висоту
        double zOffset = 0.0; // Не змінюємо положення вперед/назад
    
        GlStateManager.func_179137_b(x + xOffset, y + yOffset, z + zOffset);
    
        GlStateManager.func_179114_b(-field_76990_c.field_78735_i, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(field_76990_c.field_78732_j, 0.0F, 1.0F, 0.0F);
    
        float scale = 3.0F; 
        GlStateManager.func_179152_a(scale, scale, scale);
    
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        GlStateManager.func_179140_f();
    
        float time = Minecraft.func_71410_x().field_71441_e.func_82737_E() + partialTicks;
        float cycleDuration = 30.0F;
        float blendFactor = (time % cycleDuration) / cycleDuration;
    
        int currentTextureIndex = (int) (time / cycleDuration) % NODE_TEXTURES.length;
        int nextTextureIndex = (currentTextureIndex + 1) % NODE_TEXTURES.length;
    
        ResourceLocation currentTexture = NODE_TEXTURES[currentTextureIndex];
        Minecraft.func_71410_x().func_110434_K().func_110577_a(currentTexture);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F - blendFactor);
        UtilsFX.renderTextureIn3D(0.0F, 0.0F, 1.0F, 1.0F, 16, 16, 0.1F);
    
        ResourceLocation nextTexture = NODE_TEXTURES[nextTextureIndex];
        Minecraft.func_71410_x().func_110434_K().func_110577_a(nextTexture);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, blendFactor);
        UtilsFX.renderTextureIn3D(0.0F, 0.0F, 1.0F, 1.0F, 16, 16, 0.1F);
    
        GlStateManager.func_179145_e();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
    


    private boolean hasAquareiaGoggles(EntityPlayer player) {
        if (player.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() == ItemsTC.goggles) {
            return true;
        }

        if (BaublesApi.isBaubleEquipped(player, ItemsTC.goggles) != -1) {
            return true;
        }
        return false;
    }

    @Override
    protected ResourceLocation func_110775_a(AuraNodeEntity entity) {
        return NODE_TEXTURES[0];
    }
}
