package com.koteuka404.thaumicforever;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;

public class GuiMatteryDuplicator extends GuiContainer {

    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation("thaumicforever", "textures/gui/mattery_duplicator.png");
    private final InventoryPlayer playerInventory;
    private final TileEntityMatteryDuplicator tileEntity;

    public GuiMatteryDuplicator(InventoryPlayer playerInventory, TileEntityMatteryDuplicator tileEntity) {
        super(new ContainerMatteryDuplicator(playerInventory, tileEntity));
        this.playerInventory = playerInventory;
        this.tileEntity = tileEntity;
        this.field_146999_f = 220;
        this.field_147000_g = 220;
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        field_146297_k.func_110434_K().func_110577_a(GUI_TEXTURE);
        int x = (field_146294_l - field_146999_f) / 2;
        int y = (field_146295_m - field_147000_g) / 2;
        func_73729_b(x, y, 0, 0, field_146999_f, field_147000_g);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
}
