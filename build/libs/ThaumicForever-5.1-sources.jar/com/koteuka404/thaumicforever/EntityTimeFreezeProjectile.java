package com.koteuka404.thaumicforever;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityTimeFreezeProjectile extends EntityThrowable {

    public EntityTimeFreezeProjectile(World worldIn) {
        super(worldIn);
    }

    public EntityTimeFreezeProjectile(World worldIn, EntityLivingBase throwerIn) {
        super(worldIn, throwerIn);
    }

    public EntityTimeFreezeProjectile(World worldIn, double x, double y, double z) {
        super(worldIn, x, y, z);
    }

    @Override
    protected void func_70184_a(RayTraceResult result) {
        if (!field_70170_p.field_72995_K) {
            int radius = 3;
            BlockPos hitPos = new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v);

            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        BlockPos pos = hitPos.func_177982_a(x, y, z);
                        if (field_70170_p.func_175623_d(pos) && Math.sqrt(x * x + y * y + z * z) <= radius) {
                            field_70170_p.func_175656_a(pos, ModBlocks.TIME_STOP.func_176223_P());

                            field_70170_p.func_180497_b(pos, ModBlocks.TIME_STOP, 100, 1);
                        }
                    }
                }
            }

            List<EntityLivingBase> entities = field_70170_p.func_72872_a(EntityLivingBase.class, this.func_174813_aQ().func_186662_g(radius));
            for (EntityLivingBase entity : entities) {
                entity.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 100, 100, false, false));
                entity.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 100, 100, false, false));
                entity.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 100, 100, false, false));
            }

            this.func_70106_y();
        }
    }



    @Override
    public void func_70071_h_() {
        super.func_70071_h_();

        if (field_70170_p.field_72995_K) {
            FXDispatcher.INSTANCE.drawAlumentum((float) field_70165_t, (float) field_70163_u, (float) field_70161_v, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.5f, 4.0f);
        }
    }
}
