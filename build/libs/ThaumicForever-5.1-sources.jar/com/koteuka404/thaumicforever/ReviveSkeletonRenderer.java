package com.koteuka404.thaumicforever;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;

public class ReviveSkeletonRenderer extends RenderLiving<ReviveSkeletonEntity> {

    private static final ResourceLocation TEXTURE = new ResourceLocation("thaumicforever", "textures/entity/revive_skeleton.png");

    public ReviveSkeletonRenderer(RenderManager renderManager) {
        super(renderManager, new SkeletonReviveModel(), 0.5F);
        this.func_177094_a(new LayerHeldItemCustom(this));
    }

    @Override
    protected ResourceLocation func_110775_a(ReviveSkeletonEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void func_77041_b(ReviveSkeletonEntity entity, float partialTickTime) {
        super.func_77041_b(entity, partialTickTime);
    }

    private static class LayerHeldItemCustom implements LayerRenderer<ReviveSkeletonEntity> {
        private final ReviveSkeletonRenderer render;

        public LayerHeldItemCustom(ReviveSkeletonRenderer render) {
            this.render = render;
        }

        @Override
        public void func_177141_a(ReviveSkeletonEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            ItemStack mainHandItem = entity.func_184614_ca();
            ItemStack offHandItem = entity.func_184592_cb();

            if (!mainHandItem.func_190926_b() || !offHandItem.func_190926_b()) {
                GlStateManager.func_179094_E();
                if (this.render.func_177087_b().field_78091_s) {
                    float scaleChild = 0.5F;
                    GlStateManager.func_179109_b(0.0F, 0.75F, 0.0F);
                    GlStateManager.func_179152_a(scaleChild, scaleChild, scaleChild);
                }

                renderHeldItem(entity, mainHandItem, EnumHandSide.RIGHT);
                renderHeldItem(entity, offHandItem, EnumHandSide.LEFT);

                GlStateManager.func_179121_F();
            }
        }

        private void renderHeldItem(EntityLivingBase entity, ItemStack stack, EnumHandSide handSide) {
            if (!stack.func_190926_b()) {
                GlStateManager.func_179094_E();
                // Використовуємо стандартний рендеринг предметів Minecraft
                Minecraft.func_71410_x().func_175597_ag().func_187462_a(entity, stack, handSide == EnumHandSide.LEFT ? ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND : ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, handSide == EnumHandSide.LEFT);
                GlStateManager.func_179121_F();
            }
        }

        @Override
        public boolean func_177142_b() {
            return false;
        }
    }
}
