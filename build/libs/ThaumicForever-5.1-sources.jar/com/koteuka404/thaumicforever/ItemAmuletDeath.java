package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public class ItemAmuletDeath extends Item implements IBauble {

    public ItemAmuletDeath() {
        func_77655_b("amulet_death");
        setRegistryName("amulet_death");
        func_77625_d(1); 
        func_77637_a(ThaumicForever.CREATIVE_TAB);
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET; 
    }

    @Override
    public void onUnequipped(ItemStack itemstack, EntityLivingBase player) {
        if (player instanceof EntityPlayer && !player.field_70170_p.field_72995_K) {
            EntityPlayer entityPlayer = (EntityPlayer) player;
            entityPlayer.func_70097_a(DamageSource.field_76380_i, Float.MAX_VALUE);
        }
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
    }

    @Override
    public boolean func_77636_d(ItemStack stack) {
        return true; 
    }
}
