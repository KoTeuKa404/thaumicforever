package com.koteuka404.thaumicforever;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;

public class RenderGuardianMannequin extends RenderLiving<EntityGuardianMannequin> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("thaumicforever:textures/entity/guardian_mannequin.png");

    public RenderGuardianMannequin(RenderManager renderManager) {
        super(renderManager, new CustomModel(), 0.5F);  
        this.func_177094_a(new LayerBipedArmor(this) {
            @Override
            protected void func_177177_a() {
                this.field_177189_c = new ModelBiped(0.5F);
                this.field_177186_d = new ModelBiped(1.0F);
            }
        });

        this.func_177094_a(new LayerHeldItemCustom(this));
    }

    @Override
    protected ResourceLocation func_110775_a(EntityGuardianMannequin entity) {
        return TEXTURE;  
    }

    @Override
    protected void func_77041_b(EntityGuardianMannequin entitylivingbaseIn, float partialTickTime) {
        GlStateManager.func_179152_a(1.0F, 1.0F, 1.0F); 
    }

    private static class LayerHeldItemCustom implements LayerRenderer<EntityGuardianMannequin> {
        private final RenderGuardianMannequin render;

        public LayerHeldItemCustom(RenderGuardianMannequin render) {
            this.render = render;
        }

        @Override
        public void func_177141_a(EntityGuardianMannequin entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            ItemStack itemstack = entity.func_184614_ca();

            if (!itemstack.func_190926_b()) {
                GlStateManager.func_179094_E();

                if (this.render.func_177087_b() instanceof CustomModel) {
                    CustomModel model = (CustomModel) this.render.func_177087_b();
                    model.leftArm.func_78794_c(-0.00F); 
                }

                GlStateManager.func_179109_b(0.35F, 0.73F, 0.0F);  
                GlStateManager.func_179114_b(90F, 1F, 0F, 0F);   
                GlStateManager.func_179114_b(180F, 0F, 0F, 1F);

                renderItem(entity, itemstack, EnumHandSide.LEFT);

                GlStateManager.func_179121_F();
            }
        }

        
        


        private void renderItem(EntityLivingBase entity, ItemStack stack, EnumHandSide handSide) {
            GlStateManager.func_179094_E();
            Minecraft.func_71410_x().func_175597_ag().func_187462_a(entity, stack, handSide == EnumHandSide.LEFT ? ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND : ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, handSide == EnumHandSide.LEFT);
            GlStateManager.func_179121_F();
        }

        @Override
        public boolean func_177142_b() {
            return false;
        }
    }
}
