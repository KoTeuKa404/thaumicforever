package com.koteuka404.thaumicforever;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemRingEnder extends Item implements IBauble {

    private static final int TELEPORT_COOLDOWN_TICKS = 1600; 
    private float lastHealth = -1.0f; 

    public ItemRingEnder() {
        this.func_77655_b("ring_ender");
        this.setRegistryName("ring_ender");
        this.func_77625_d(1);
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.RING;
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;

            if (player.func_184811_cZ().func_185141_a(this)) {
                return;
            }

            if (lastHealth > 0 && player.func_110143_aJ() < lastHealth && player.func_110143_aJ() <= 4.0f) {
                if (teleportRandomly(player)) {
                    player.func_184811_cZ().func_185145_a(this, TELEPORT_COOLDOWN_TICKS);

                    player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 20, 5, false, false));
                }
            }

            lastHealth = player.func_110143_aJ();
        }
    }

    private boolean teleportRandomly(EntityPlayer player) {
        World world = player.field_70170_p;
        double x = player.field_70165_t + (player.func_70681_au().nextDouble() - 0.5D) * 64.0D;
        double y = player.field_70163_u + (double)(player.func_70681_au().nextInt(64) - 32);
        double z = player.field_70161_v + (player.func_70681_au().nextDouble() - 0.5D) * 64.0D;

        return teleportTo(player, x, y, z);
    }

    private boolean teleportTo(EntityPlayer player, double x, double y, double z) {
        World world = player.field_70170_p;
        BlockPos blockpos = new BlockPos(x, y, z);

        while (y > 0.0D && !world.func_180495_p(blockpos).func_185904_a().func_76230_c()) {
            y--;
            blockpos = new BlockPos(x, y, z);
        }

        if (!world.func_180495_p(blockpos).func_185904_a().func_76230_c()) {
            return false;
        }

        player.func_70634_a(x, y, z);
        world.func_184148_a(null, player.field_70169_q, player.field_70167_r, player.field_70166_s, SoundEvents.field_187544_ad, player.func_184176_by(), 1.0F, 1.0F);
        player.func_184185_a(SoundEvents.field_187544_ad, 1.0F, 1.0F);

        return true;
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC; 
    }
}
