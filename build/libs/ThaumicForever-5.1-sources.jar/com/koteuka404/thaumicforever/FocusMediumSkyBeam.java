package com.koteuka404.thaumicforever;

import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.casters.FocusMedium;
import thaumcraft.api.casters.NodeSetting;
import thaumcraft.api.casters.Trajectory;

import thaumcraft.api.casters.FocusNode.EnumSupplyType;

public class FocusMediumSkyBeam extends FocusMedium {

    @Override
    public String getResearch() {
        return "FOCUSSKYBEAM"; 
    }

    @Override
    public String getKey() {
        return "thaumicforever.SKYBEAM"; 
    }

    @Override
    public Aspect getAspect() {
        return Aspect.AIR;
    }

    @Override
    public int getComplexity() {
        return 5 + getSettingValue("power") * 2; 
    }

    @Override
    public EnumSupplyType[] willSupply() {
        return new EnumSupplyType[] { EnumSupplyType.TARGET };
    }

    @Override
    public boolean execute(Trajectory trajectory) {
        Vec3d startVec = trajectory.source;
        Vec3d endVec = trajectory.direction.func_186678_a(20.0).func_178787_e(startVec); 

        AxisAlignedBB boundingBox = new AxisAlignedBB(
            Math.min(startVec.field_72450_a, endVec.field_72450_a), Math.min(startVec.field_72448_b, endVec.field_72448_b), Math.min(startVec.field_72449_c, endVec.field_72449_c),
            Math.max(startVec.field_72450_a, endVec.field_72450_a), Math.max(startVec.field_72448_b, endVec.field_72448_b), Math.max(startVec.field_72449_c, endVec.field_72449_c)
        );

        List<Entity> entitiesInRange = getPackage().getCaster().field_70170_p.func_72872_a(EntityLivingBase.class, boundingBox);

        for (Entity entity : entitiesInRange) {
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase targetEntity = (EntityLivingBase) entity;
                
                scheduleSkyBeam(targetEntity, 2, getSettingValue("power"));
                
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean hasIntermediary() {
        return true;
    }

    @Override
    public NodeSetting[] createSettings() {
        return new NodeSetting[] {
            new NodeSetting("power", "focus.common.power", new NodeSetting.NodeSettingIntRange(1, 5))
        };
    }

    @Override
    public float getPowerMultiplier() {
        return 1.0f;
    }

    private void scheduleSkyBeam(Entity target, int delaySeconds, int power) {
        World world = target.field_70170_p;
        BlockPos targetPos = target.func_180425_c();
        
        if (world instanceof WorldServer) {
            ((WorldServer) world).func_152344_a(() -> {
                castSkyBeam(world, targetPos, power);
            });
        }
    }

    private void castSkyBeam(World world, BlockPos pos, int power) {
        Vec3d skyPos = new Vec3d(pos.func_177958_n(), world.func_72940_L(), pos.func_177952_p());
        Vec3d targetPos = new Vec3d(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());

        createSkyBeamVisual(world, skyPos, targetPos);

        world.func_72872_a(EntityLivingBase.class, new AxisAlignedBB(pos)).forEach(entity -> {
            entity.func_70097_a(DamageSource.field_76376_m, 8.0f * power); 
        });
    }

    private void createSkyBeamVisual(World world, Vec3d start, Vec3d end) {
        for (int i = 0; i < 50; i++) {
            double progress = i / 50.0;
            double x = start.field_72450_a + (end.field_72450_a - start.field_72450_a) * progress;
            double y = start.field_72448_b + (end.field_72448_b - start.field_72448_b) * progress;
            double z = start.field_72449_c + (end.field_72449_c - start.field_72449_c) * progress;
            
            world.func_175688_a(EnumParticleTypes.CRIT_MAGIC, x, y, z, 0, 0, 0);
            world.func_175688_a(EnumParticleTypes.ENCHANTMENT_TABLE, x, y, z, 0, 0, 0);
        }
    }
}
