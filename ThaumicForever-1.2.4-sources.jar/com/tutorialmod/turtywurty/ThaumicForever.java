package com.tutorialmod.turtywurty;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = ThaumicForever.MODID, name = ThaumicForever.NAME, version = ThaumicForever.VERSION)
public class ThaumicForever {
    public static final String MODID = "thaumicforever";
    public static final String NAME = "Thaumic Forever";
    public static final String VERSION = "1.0";
    
    public static ThaumicForever instance;
    @SidedProxy(clientSide = "com.tutorialmod.turtywurty.ClientProxy", serverSide = "com.tutorialmod.turtywurty.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ResearchHandler.init();
        RemoveRecipes.init();
        RecipeCrucible.init();
        instance = this;
        GameRegistry.registerTileEntity(DeconstructionTableTileEntity.class, MODID + ":deconstruction_table");
        proxy.preInit(event);
        new OreGeneration(); // Реєстрація генератора руд

    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(ModItems.class);
        new ModGuiHandler();

        ModRecipes.init();
        FurnaceRecipes.init();  // Ініціалізація рецептів переплавки
        CraftingRecipes.init();

        OreDictionaryRegistration.registerOreDictionary();  // Реєстрація руд у OreDictionary

    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {

    

        }
    

} 