package com.tutorialmod.turtywurty;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityGuardianMannequin extends EntityCreature {

    private final EntityPlayer owner;

    // Constructor with EntityPlayer
    public EntityGuardianMannequin(World worldIn, EntityPlayer owner) {
        super(worldIn);
        this.owner = owner;
        this.func_70105_a(0.6F, 1.6F);
        this.field_70728_aV = 5;
        this.func_184651_r();
    }

    // Constructor without EntityPlayer
    public EntityGuardianMannequin(World worldIn) {
        super(worldIn);
        this.owner = null;  // If no owner
        this.func_70105_a(0.6F, 1.6F);
        this.field_70728_aV = 5;
        this.func_184651_r();
    }

    // Initialize AI
    protected void func_184651_r() {
        this.field_70714_bg.func_75776_a(0, new EntityAIWanderAvoidWater(this, 0.6D)); // Wander and avoid water
        this.field_70714_bg.func_75776_a(1, new EntityAIAttackMelee(this, 1.0D, true)); // Melee attack
        this.field_70715_bh.func_75776_a(1, new EntityAIHurtByTarget(this, true) {
            @Override
            public boolean func_75250_a() {
                // Check if the attacker is not the owner before retaliating
                if (EntityGuardianMannequin.this.func_70643_av() == owner) {
                    return false;
                }
                return super.func_75250_a();
            }
        }); // Retaliate when attacked, but not by the owner
        this.field_70715_bh.func_75776_a(2, new EntityAINearestAttackableTarget<>(this, EntityLivingBase.class, 10, true, false, entity -> entity instanceof IMob)); // Attack hostile mobs (IMob)
    }

    @Override
    public void func_70071_h_() {
        super.func_70071_h_();
        applyArmorAttributes();
    }

    // Apply armor attributes
    private void applyArmorAttributes() {
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            ItemStack stack = this.func_184582_a(slot);
            if (!stack.func_190926_b()) {
                // Logic for armor attributes
            }
        }
    }

    @Override
    protected void func_110147_ax() {
        super.func_110147_ax();
        
        // Здоров'я (10 HP)
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0D);
        
        // Швидкість (2.5)
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.25D); // 0.25D відповідає 2.5 швидкості
    }

    @Override
    public boolean func_70652_k(Entity entityIn) {
        // Base attack damage
        float attackDamage = 2.0F;

        // Adjust damage based on weapon (sword or other modded items)
        ItemStack heldItem = this.func_184614_ca();
        if (!heldItem.func_190926_b()) {
            Item item = heldItem.func_77973_b();
            if (item instanceof ItemSword) {
                attackDamage = ((ItemSword) item).func_150931_i() + 2.0F; // Add base damage to sword damage
            } else {
                attackDamage = 4.0F; // Default damage for non-sword items
            }
        }

        boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a(this), attackDamage);
        return flag;
    }

    // Enable interaction with the player to give the mob a weapon and retrieve the old one
@Override
public EnumActionResult func_184199_a(EntityPlayer player, Vec3d vec, EnumHand hand) {
    ItemStack stack = player.func_184586_b(hand);
    
    // Get the item currently in the mob's main hand
    ItemStack currentItem = this.func_184582_a(EntityEquipmentSlot.MAINHAND);

    if (!this.field_70170_p.field_72995_K && !stack.func_190926_b()) {
        // Give the player the current item in the main hand (if it exists)
        if (!currentItem.func_190926_b()) {
            player.func_191521_c(currentItem);
        }

        // Set the player's held item to the mob's main hand slot
        this.func_184201_a(EntityEquipmentSlot.MAINHAND, stack.func_77946_l());
        player.func_184611_a(hand, ItemStack.field_190927_a); // Clear the player's hand
        
        return EnumActionResult.SUCCESS;
    } else if (!this.field_70170_p.field_72995_K && stack.func_190926_b() && !currentItem.func_190926_b()) {
        // If the player's hand is empty and the mob is holding an item, give it to the player
        player.func_184611_a(hand, currentItem.func_77946_l());
        this.func_184201_a(EntityEquipmentSlot.MAINHAND, ItemStack.field_190927_a); // Clear the mob's hand
        
        return EnumActionResult.SUCCESS;
    }
    
    return EnumActionResult.PASS;
}


    // Immunity to poison and drowning
    @Override
    public boolean func_70687_e(PotionEffect potioneffectIn) {
        // Immunity to poison
        if (potioneffectIn.func_188419_a() == MobEffects.field_76436_u) {
            return false;
        }
        return super.func_70687_e(potioneffectIn);
    }

    @Override
    public void func_70636_d() {
        // Set air supply to maximum to prevent drowning
        this.func_70050_g(300);
        super.func_70636_d();
    }

    @Override
    public void func_70014_b(NBTTagCompound compound) {
        super.func_70014_b(compound);
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            ItemStack itemstack = this.func_184582_a(slot);
            if (!itemstack.func_190926_b()) {
                compound.func_74782_a(slot.func_188450_d(), itemstack.func_77955_b(new NBTTagCompound()));
            }
        }
    }

    @Override
    public void func_70037_a(NBTTagCompound compound) {
        super.func_70037_a(compound);
        for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
            NBTTagCompound tag = compound.func_74775_l(slot.func_188450_d());
            if (!tag.func_82582_d()) {
                this.func_184201_a(slot, new ItemStack(tag));
            }
        }
    }
}
