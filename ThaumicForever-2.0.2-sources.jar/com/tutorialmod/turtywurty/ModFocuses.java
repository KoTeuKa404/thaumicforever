package com.tutorialmod.turtywurty;

import net.minecraft.util.ResourceLocation;
import thaumcraft.api.casters.FocusEngine;

public class ModFocuses {

    public static void registerFocuses() {
        // Реєстрація фокуса Calm
        FocusEngine.registerElement(FocusEffectCalm.class, new ResourceLocation("thaumicforever", "textures/foci/calm_focus.png"), 0);
        FocusEngine.registerElement(FocusEffectCleanse.class, new ResourceLocation("thaumicforever", "textures/foci/calm_focus.png"), 0);

    }
}
