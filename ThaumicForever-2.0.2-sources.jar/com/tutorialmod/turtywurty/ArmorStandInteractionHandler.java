package com.tutorialmod.turtywurty;

import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import thaumcraft.api.items.ItemsTC;

public class ArmorStandInteractionHandler {

    @SubscribeEvent
    public void onRightClickEntity(PlayerInteractEvent.EntityInteractSpecific event) {
        if (event.getTarget() instanceof EntityArmorStand) {
            EntityPlayer player = event.getEntityPlayer();
            EntityArmorStand armorStand = (EntityArmorStand) event.getTarget();
            ItemStack heldItem = player.func_184586_b(event.getHand());

            if (heldItem.func_77973_b() == ItemsTC.salisMundus) {
                World world = event.getWorld();
                BlockPos pos = armorStand.func_180425_c();

                if (!world.field_72995_K) {
                    EntityGuardianMannequin guardian = new EntityGuardianMannequin(world, player);  
                    guardian.func_70107_b(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());

                    guardian.func_184201_a(EntityEquipmentSlot.HEAD, armorStand.func_184582_a(EntityEquipmentSlot.HEAD));
                    guardian.func_184201_a(EntityEquipmentSlot.CHEST, armorStand.func_184582_a(EntityEquipmentSlot.CHEST));
                    guardian.func_184201_a(EntityEquipmentSlot.LEGS, armorStand.func_184582_a(EntityEquipmentSlot.LEGS));
                    guardian.func_184201_a(EntityEquipmentSlot.FEET, armorStand.func_184582_a(EntityEquipmentSlot.FEET));


                    armorStand.func_70106_y();
                    world.func_72838_d(guardian);

                    if (!player.func_184812_l_()) {
                        heldItem.func_190918_g(1);
                    }

                    event.setCanceled(true);
                }
            }
        }
    }
}
