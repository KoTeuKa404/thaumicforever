package com.tutorialmod.turtywurty;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;

public class ItemPrimalCharm extends Item implements IBauble {

    public ItemPrimalCharm() {
        this.func_77655_b("primal_charm");
        this.setRegistryName("primal_charm");
        this.func_77625_d(1);
        this.func_77637_a(CreativeTabs.field_78040_i); // або інший таб
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.BODY;
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
        if (player instanceof EntityPlayer) {
            EntityPlayer entityPlayer = (EntityPlayer) player;
            entityPlayer.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 200, 0, true, true));
        }
    }
    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.UNCOMMON; // Встановлення рідкості на EPIC
    }
}
