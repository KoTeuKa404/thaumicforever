package com.tutorialmod.turtywurty;

import baubles.api.BaubleType;
import baubles.api.IBauble;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.SoundCategory;

public class ItemRingVerdant extends Item implements IBauble {

    private static final int COOLDOWN_TICKS = 800; // 40 секунд

    public ItemRingVerdant() {
        this.func_77655_b("ring_verdant");
        this.setRegistryName("ring_verdant");
        this.func_77625_d(1);
        this.func_77637_a(CreativeTabs.field_78040_i); // або інший таб
    }

    @Override
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.RING;
    }

    @Override
    public void onWornTick(ItemStack itemstack, EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            if (player.func_184811_cZ().func_185141_a(this)) {
                return; // Якщо кільце на перезарядці, нічого не робимо
            }

            boolean hadBadEffects = false;
            for (PotionEffect effect : player.func_70651_bq()) {
                if (effect.func_188419_a().func_76398_f()) {
                    player.func_184589_d(effect.func_188419_a());
                    hadBadEffects = true;
                }
            }

            if (hadBadEffects) {
                player.func_184811_cZ().func_185145_a(this, COOLDOWN_TICKS); // Запускаємо перезарядку
                player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187604_bf, SoundCategory.PLAYERS, 0.5F, 1.0F); // Відтворюємо звук з меншою гучністю
            }
        }
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC; // Встановлення рідкості на EPIC
    }
}
