package com.tutorialmod.turtywurty;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.registries.IForgeRegistry;
@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ModItems {

    public static final Item LEAD_INGOT = new Item().func_77655_b("lead_ingot").setRegistryName("lead_ingot");
    public static final Item SILVER_INGOT = new Item().func_77655_b("silver_ingot").setRegistryName("silver_ingot");
    public static final Item TIN_INGOT = new Item().func_77655_b("tin_ingot").setRegistryName("tin_ingot");
    public static final Item COPPER_INGOT = new Item().func_77655_b("copper_ingot").setRegistryName("copper_ingot");

    public static final Item LEAD_NUGGET = new Item().func_77655_b("lead_nugget").setRegistryName("lead_nugget");
    public static final Item SILVER_NUGGET = new Item().func_77655_b("silver_nugget").setRegistryName("silver_nugget");
    public static final Item TIN_NUGGET = new Item().func_77655_b("tin_nugget").setRegistryName("tin_nugget");
    public static final Item COPPER_NUGGET = new Item().func_77655_b("copper_nugget").setRegistryName("copper_nugget");

    public static final Item AQUAREIA_GEM = new Item().func_77655_b("aquareia_gem").setRegistryName("aquareia_gem");
    public static final Item CLUSTER = new ItemCluster().func_77655_b("cluster").setRegistryName("cluster");

    public static final Item PRIMAL_CHARM = new ItemPrimalCharm(); // Тут вже не потрібно викликати setRegistryName
    public static final Item RING_VERDANT = new ItemRingVerdant();
    public static final Item RING_RUNIC_CHARGE = new ItemRingRunicCharge();

    
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        IForgeRegistry<Item> registry = event.getRegistry();
        registry.registerAll(
            LEAD_INGOT,
            SILVER_INGOT,
            TIN_INGOT,
            COPPER_INGOT,
            LEAD_NUGGET,
            SILVER_NUGGET,
            TIN_NUGGET,
            COPPER_NUGGET,
            AQUAREIA_GEM,
            CLUSTER,
            PRIMAL_CHARM,
            RING_VERDANT,
            RING_RUNIC_CHARGE

            
            

        );
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ModItems.LEAD_INGOT, 0, new ModelResourceLocation(ModItems.LEAD_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.SILVER_INGOT, 0, new ModelResourceLocation(ModItems.SILVER_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.TIN_INGOT, 0, new ModelResourceLocation(ModItems.TIN_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.COPPER_INGOT, 0, new ModelResourceLocation(ModItems.COPPER_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.LEAD_NUGGET, 0, new ModelResourceLocation(ModItems.LEAD_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.SILVER_NUGGET, 0, new ModelResourceLocation(ModItems.SILVER_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.TIN_NUGGET, 0, new ModelResourceLocation(ModItems.TIN_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.COPPER_NUGGET, 0, new ModelResourceLocation(ModItems.COPPER_NUGGET.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.AQUAREIA_GEM, 0, new ModelResourceLocation(ModItems.AQUAREIA_GEM.getRegistryName(), "inventory"));
        // Нові предмети - кластери
        ModelLoader.setCustomModelResourceLocation(ModItems.CLUSTER, 0, new ModelResourceLocation(ModItems.CLUSTER.getRegistryName() + "_chromium", "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.CLUSTER, 1, new ModelResourceLocation(ModItems.CLUSTER.getRegistryName() + "_iridium", "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.CLUSTER, 2, new ModelResourceLocation(ModItems.CLUSTER.getRegistryName() + "_quartz", "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.CLUSTER, 3, new ModelResourceLocation(ModItems.CLUSTER.getRegistryName() + "_charged_quartz", "inventory"));
        
        ModelLoader.setCustomModelResourceLocation(ModItems.PRIMAL_CHARM, 0, new ModelResourceLocation(ModItems.PRIMAL_CHARM.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.RING_VERDANT, 0, new ModelResourceLocation(ModItems.RING_VERDANT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.RING_RUNIC_CHARGE, 0, new ModelResourceLocation(ModItems.RING_RUNIC_CHARGE.getRegistryName(), "inventory"));

    }

}

