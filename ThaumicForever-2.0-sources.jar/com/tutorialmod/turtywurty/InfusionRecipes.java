package com.tutorialmod.turtywurty;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.ThaumcraftApi;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.crafting.InfusionRecipe;
import thaumcraft.api.items.ItemsTC;

public class InfusionRecipes {

    public static void init() {
        ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("thaumicforever:ring_runic_charge"), new InfusionRecipe(
            "NEWRUNICS",  // Назва дослідження
            new ItemStack(ModItems.RING_RUNIC_CHARGE),  // Вихідний предмет
            3,  // Рівень нестабільності
            new AspectList()
                .add(Aspect.EXCHANGE, 40)
                .add(Aspect.FIRE, 40)
                .add(Aspect.MAGIC, 60)
                .add(Aspect.AVERSION, 60),
            new ItemStack(thaumcraft.api.items.ItemsTC.baubles, 1, 1),  // Центральний інгредієнт (Amulet of Vis)
            new Object[] {
                new ItemStack(Items.field_151065_br),
                new ItemStack(thaumcraft.api.items.ItemsTC.amber),
                new ItemStack(Items.field_151065_br),
                new ItemStack(thaumcraft.api.items.ItemsTC.salisMundus)
            }
        ));

        ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("thaumicforever:ring_verdant"), new InfusionRecipe(
            "NEWRUNICS",  // Назва дослідження
            new ItemStack(ModItems.RING_VERDANT),
            3,  // Рівень нестабільності
            new AspectList()
                .add(Aspect.EXCHANGE, 40)
                .add(Aspect.PROTECT, 40)
                .add(Aspect.MAGIC, 60)
                .add(Aspect.SENSES, 60),
            new ItemStack(thaumcraft.api.items.ItemsTC.baubles, 1, 1), // Central item
            new ItemStack[]{
                new ItemStack(ItemsTC.charmVerdant), // Assuming charmVerdant exists within ItemsTC
                new ItemStack(Items.field_151117_aB),
                new ItemStack(thaumcraft.api.items.ItemsTC.salisMundus),
                new ItemStack(thaumcraft.api.items.ItemsTC.amber)
            }
        ));

    }
}
