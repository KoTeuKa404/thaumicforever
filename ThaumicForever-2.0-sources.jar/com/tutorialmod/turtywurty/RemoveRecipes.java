package com.tutorialmod.turtywurty;

import java.util.Map;

import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.ThaumcraftApi;
import thaumcraft.api.crafting.CrucibleRecipe;
import thaumcraft.api.crafting.IThaumcraftRecipe;

public class RemoveRecipes {

    public static void removeVoidMetalIngotRecipe() {
        ResourceLocation recipeKeyToRemove = null;

        // Ітерація по entrySet() мапи
        for (Map.Entry<ResourceLocation, IThaumcraftRecipe> entry : ThaumcraftApi.getCraftingRecipes().entrySet()) {
            IThaumcraftRecipe recipe = entry.getValue();
            if (recipe instanceof CrucibleRecipe) {
                CrucibleRecipe crucibleRecipe = (CrucibleRecipe) recipe;
                if (crucibleRecipe.getRecipeOutput().func_77973_b() == Item.func_111206_d("thaumcraft:ingot") && crucibleRecipe.getRecipeOutput().func_77960_j() == 1) {
                    recipeKeyToRemove = entry.getKey();
                    break;
                }
            }
        }

        if (recipeKeyToRemove != null) {
            ThaumcraftApi.getCraftingRecipes().remove(recipeKeyToRemove);
            System.out.println("Void Metal Ingot recipe removed successfully.");
        } else {
            System.out.println("Void Metal Ingot recipe not found.");
        }
    }

    // Метод init для виклику видалення рецепта
    public static void init() {
        removeVoidMetalIngotRecipe();
    }
}
