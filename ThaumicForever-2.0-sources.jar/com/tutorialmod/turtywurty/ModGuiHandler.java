package com.tutorialmod.turtywurty;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.network.IGuiHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;

@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ModGuiHandler implements IGuiHandler {
    public static final int DECONSTRUCTION_TABLE_GUI = 0;

    public ModGuiHandler() {
        NetworkRegistry.INSTANCE.registerGuiHandler(ThaumicForever.instance, this);
    }

    @Override
    public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        TileEntity tileEntity = world.func_175625_s(new BlockPos(x, y, z));
        if (tileEntity instanceof DeconstructionTableTileEntity) {
            return new DeconstructionTableContainer(player.field_71071_by, (IInventory) tileEntity);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        TileEntity tileEntity = world.func_175625_s(new BlockPos(x, y, z));
        if (tileEntity instanceof DeconstructionTableTileEntity) {
            return new DeconstructionTableGui(player.field_71071_by, (IInventory) tileEntity);
        }
        return null;
    }
}
