package com.tutorialmod.turtywurty;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemCluster extends Item {
    // Масив з іменами варіантів кластерів
    public static final String[] CLUSTER_TYPES = new String[]{"chromium", "iridium", "quartz", "charged_quartz"};

    public ItemCluster() {
        this.func_77627_a(true); // Вказує, що предмет має кілька варіантів
        this.func_77656_e(0); // Предмет не має міцності
    }

    @Override
    public String func_77667_c(ItemStack stack) {
        int metadata = stack.func_77960_j();
        if (metadata < 0 || metadata >= CLUSTER_TYPES.length) {
            metadata = 0;
        }
        return super.func_77658_a() + "." + CLUSTER_TYPES[metadata];
    }
}
