package com.tutorialmod.turtywurty;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.item.Item;

@Mod.EventBusSubscriber(modid = ThaumicForever.MODID)
public class ModBlocks {

    @ObjectHolder(ThaumicForever.MODID + ":deconstruction_table")
    public static final Block DECONSTRUCTION_TABLE = null;

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().register(
            new DeconstructionTableBlock().setRegistryName(ThaumicForever.MODID, "deconstruction_table")
        );
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ThaumicForever.proxy.registerItemRenderer(Item.func_150898_a(DECONSTRUCTION_TABLE), 0, "inventory");
    }
}
