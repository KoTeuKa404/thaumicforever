package com.tutorialmod.turtywurty;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import thaumcraft.api.ThaumcraftApi;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.crafting.ShapelessArcaneRecipe;
public class ModRecipes {
    
    public static void init() {
        // Створення безформленного арканного рецепту для створення скляної пляшки з блоку скла
        ShapelessArcaneRecipe glassBottleRecipe = new ShapelessArcaneRecipe(
            new ResourceLocation("thaumicforever", "glass_bottle_from_glass"), // Ідентифікатор рецепту
            "NEWALKIMIA", // Ключ для ресерчу
            0, // Вартість Vis
            new AspectList(), // Потрібні аспекти (в даному випадку 0 аспектів)
            new ItemStack(Items.field_151069_bo), // Результат рецепту
            new Object[] {new ItemStack(Blocks.field_150359_w)} // Інгредієнт для крафту (блок скла)
        );

        // Реєстрація рецепту для скляної пляшки
        ThaumcraftApi.addArcaneCraftingRecipe(
            new ResourceLocation("thaumicforever", "glass_bottle_from_glass"), // Ідентифікатор рецепту
            glassBottleRecipe // Сам рецепт
        );

        
    }
}